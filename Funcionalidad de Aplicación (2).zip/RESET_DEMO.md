# 🔄 Reset del Modo Demo

## ¿Sigues viendo errores de conflicto?

Si sigues viendo el error **"Ya existe una reserva en ese horario"**, es posible que tengas **reservas viejas** guardadas en tu navegador del modo demo anterior.

---

## ✅ Solución Rápida: Reset Completo

Abre la **consola del navegador (F12)** y ejecuta uno de estos comandos:

### Opción 1: Reset Completo (Recomendado)
```javascript
// Borrar TODOS los datos del modo demo y empezar desde cero
localStorage.clear();
location.reload();

// Luego reactiva el modo demo
localStorage.setItem('sisugrb_demo_mode', 'true');
location.reload();
```

### Opción 2: Solo Borrar Reservas (Mantener usuarios)
```javascript
// Borrar solo las reservas
localStorage.removeItem('sisugrb_demo_reservations');
location.reload();
```

### Opción 3: Borrar Solo Mantenimiento
```javascript
// Si una sala está "trabada" en mantenimiento
localStorage.removeItem('sisugrb_demo_maintenance');
location.reload();
```

---

## 🔍 Verificar Qué Reservas Tienes

Para ver qué reservas existen actualmente en tu navegador:

```javascript
// Ver todas las reservas
const reservas = JSON.parse(localStorage.getItem('sisugrb_demo_reservations') || '[]');
console.table(reservas.map(r => ({
  ID: r.id,
  Sala: r.roomId,
  Usuario: r.user?.displayName,
  Inicio: new Date(r.startTime).toLocaleString('es-ES'),
  Fin: new Date(r.endTime).toLocaleString('es-ES'),
  Estado: r.status
})));
```

---

## 🧹 Ver Qué Está Guardado

```javascript
// Ver todo lo que hay en localStorage
console.log('Modo Demo:', localStorage.getItem('sisugrb_demo_mode'));
console.log('Usuario Actual:', JSON.parse(localStorage.getItem('sisugrb_demo_current_user') || 'null'));
console.log('Total Reservas:', JSON.parse(localStorage.getItem('sisugrb_demo_reservations') || '[]').length);
console.log('Salas en Mantenimiento:', JSON.parse(localStorage.getItem('sisugrb_demo_maintenance') || '[]'));
```

---

## 📋 Logs de Debugging Mejorados

Ahora cuando intentes crear una reserva, verás en la consola:

```
🔍 Validando nueva reserva: 
  - sala: 1
  - inicio: 15/2/2026, 10:00:00
  - fin: 15/2/2026, 11:00:00
  - totalReservas: 2

📋 Reservas activas en sala 1:
  [
    {
      id: 1,
      usuario: "María González",
      inicio: "15/2/2026, 9:00:00",
      fin: "15/2/2026, 10:00:00",
      status: "Active"
    }
  ]

✅ Reserva creada exitosamente en modo demo:
  - id: 3
  - sala: Sala Piso 1
  - usuario: Juan Pérez
  - horario: 10:00 - 11:00
```

Si hay conflicto, verás:

```
❌ Conflicto detectado con reserva:
  - id: 1
  - usuario: María González
  - inicio: 15/2/2026, 9:00:00
  - fin: 15/2/2026, 10:00:00
```

---

## 🎯 Pasos para Probar Sin Errores

1. **Reset completo:**
   ```javascript
   localStorage.clear();
   localStorage.setItem('sisugrb_demo_mode', 'true');
   location.reload();
   ```

2. **Selecciona un usuario** (María, Juan, Ana o José Luis)

3. **Abre la consola del navegador (F12)** para ver los logs detallados

4. **Verifica las reservas existentes:**
   - Sala Piso 1: 9:00-10:00 (María González)
   - Sala Piso 3: 15:00-16:00 (José Luis Pimienta)
   - Sala Piso 2: **COMPLETAMENTE LIBRE**

5. **Intenta crear una reserva en un horario libre:**
   - ✅ Sala Piso 1: 10:00 AM en adelante
   - ✅ Sala Piso 2: TODO EL DÍA
   - ✅ Sala Piso 3: 8:30-15:00 o después de 16:00

---

## 🐛 Problemas Comunes

### "Siguen apareciendo reservas viejas"
**Solución:** Haz un reset completo con `localStorage.clear()`

### "La sala dice que está en mantenimiento pero no debería"
**Solución:**
```javascript
localStorage.removeItem('sisugrb_demo_maintenance');
location.reload();
```

### "No puedo crear ninguna reserva"
**Solución:** Verifica que:
1. Estés en modo demo (banner morado en la parte superior)
2. Hayas seleccionado un usuario
3. El horario sea de 8:30 AM - 6:00 PM
4. El día sea entre Lunes y Viernes

### "Veo reservas de días anteriores"
**Solución:** Las reservas de ejemplo siempre se generan para "hoy". Si cambiaste de fecha en el calendario, cámbiale de vuelta a hoy.

---

## 📊 Estados de las Salas

Después del reset, deberías ver:

| Sala | Capacidad | Estado Inicial | Reservas |
|------|-----------|----------------|----------|
| **Piso 1** | 10 personas | Libre | 1 reserva (9:00-10:00) |
| **Piso 2** | 10 personas | Libre | 0 reservas |
| **Piso 3** | 30 personas | Libre | 1 reserva (15:00-16:00) |

---

## 💡 Comandos Útiles

### Crear Reserva Manual (Para Pruebas)
```javascript
const reservas = JSON.parse(localStorage.getItem('sisugrb_demo_reservations') || '[]');
const hoy = new Date();
hoy.setHours(0, 0, 0, 0);

const inicio = new Date(hoy);
inicio.setHours(11, 0, 0, 0);

const fin = new Date(hoy);
fin.setHours(12, 0, 0, 0);

reservas.push({
  id: reservas.length + 1,
  roomId: 2,
  userId: 2,
  user: { id: 2, displayName: 'Juan Pérez' },
  startTime: inicio.toISOString(),
  endTime: fin.toISOString(),
  purpose: 'Prueba manual',
  status: 'Active',
  createdAt: new Date().toISOString()
});

localStorage.setItem('sisugrb_demo_reservations', JSON.stringify(reservas));
location.reload();
```

### Cancelar Todas las Reservas
```javascript
localStorage.setItem('sisugrb_demo_reservations', '[]');
location.reload();
```

### Ver Usuario Actual
```javascript
const usuario = JSON.parse(localStorage.getItem('sisugrb_demo_current_user'));
console.log('Usuario actual:', usuario?.displayName);
console.log('Puede gestionar mantenimiento:', usuario?.canManageMaintenance);
```

---

## ✅ Confirmación

Después del reset, deberías poder:

- ✅ Crear reservas sin errores de conflicto
- ✅ Ver solo 2 reservas de ejemplo
- ✅ Cancelar reservas que tú creaste
- ✅ Ver logs detallados en la consola
- ✅ Probar todos los escenarios sin problemas

---

**¿Sigue sin funcionar? Abre la consola (F12), haz una captura de los logs y compártelos para ayudarte mejor.** 📸
