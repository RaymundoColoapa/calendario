import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors({ origin: '*', credentials: true }));
app.use('*', logger(console.log));

// ==================== TIPOS ====================
interface User {
  id: number;
  username: string;
  displayName: string;
  email: string;
  teamId: number;
  team: {
    id: number;
    name: string;
    color: string;
  };
  role: string;
  canManageMaintenance?: boolean; // Permiso para gestionar mantenimiento
  createdAt: string;
}

interface Room {
  id: number;
  name: string;
  floor: number;
  capacity: number;
  status: 'Libre' | 'Ocupado' | 'Mantenimiento';
}

interface Reservation {
  id: number;
  roomId: number;
  userId: number;
  startTime: string;
  endTime: string;
  purpose: string;
  status: 'Active' | 'Completed' | 'Cancelled';
  createdAt: string;
}

interface Team {
  id: number;
  name: string;
  color: string;
}

// ==================== EQUIPOS/DEPARTAMENTOS ====================
const TEAMS: Team[] = [
  { id: 1, name: 'Suscripción', color: '#3B82F6' },
  { id: 2, name: 'Reclamaciones', color: '#EF4444' },
  { id: 3, name: 'Financiero', color: '#10B981' },
  { id: 4, name: 'Comercial', color: '#F59E0B' },
  { id: 5, name: 'Operaciones', color: '#8B5CF6' },
  { id: 6, name: 'Legal', color: '#EC4899' },
  { id: 7, name: 'Tecnología', color: '#6366F1' }
];

// ==================== DATOS INICIALES ====================
const INITIAL_USERS: User[] = [
  {
    id: 1,
    username: 'azuread\\rcoloapa',
    displayName: 'Raymundo Coloapa Frago',
    email: 'rcoloapa@sisugrb.com',
    teamId: 7,
    team: { id: 7, name: 'Tecnología', color: '#6366F1' },
    role: 'Jr. Desarrollador',
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    username: 'azuread\\mblanco',
    displayName: 'Mario Blanco',
    email: 'mblanco@sisugrb.com',
    teamId: 7,
    team: { id: 7, name: 'Tecnología', color: '#6366F1' },
    role: 'Subgerente de TI',
    createdAt: new Date().toISOString()
  },
  {
    id: 3,
    username: 'azuread\\mmeza',
    displayName: 'Margarita Meza',
    email: 'mmeza@sisugrb.com',
    teamId: 7,
    team: { id: 7, name: 'Tecnología', color: '#6366F1' },
    role: 'Sr. Analista',
    createdAt: new Date().toISOString()
  },
  {
    id: 4,
    username: 'azuread\\jlpimienta',
    displayName: 'José Luis Pimienta',
    email: 'jlpimienta@sisugrb.com',
    teamId: 5,
    team: { id: 5, name: 'Operaciones', color: '#8B5CF6' },
    role: 'Supervisor de Mantenimiento',
    canManageMaintenance: true,
    createdAt: new Date().toISOString()
  }
];

const INITIAL_ROOMS: Room[] = [
  { id: 1, name: 'Sala Piso 1', capacity: 10, floor: 1, status: 'Libre' },
  { id: 2, name: 'Sala Piso 2', capacity: 10, floor: 2, status: 'Libre' },
  { id: 3, name: 'Sala Piso 3 - Capacitación', capacity: 30, floor: 3, status: 'Libre' }
];

// ==================== INICIALIZACIÓN ====================
async function initializeData() {
  try {
    // Verificar si ya hay datos inicializados
    const existingUsers = await kv.getByPrefix('user:');
    
    if (existingUsers.length === 0) {
      console.log('🔧 Inicializando datos en Supabase...');
      
      // Inicializar usuarios
      for (const user of INITIAL_USERS) {
        await kv.set(`user:${user.id}`, user);
      }
      
      // Inicializar salas
      for (const room of INITIAL_ROOMS) {
        await kv.set(`room:${room.id}`, room);
      }
      
      console.log('✅ Datos inicializados correctamente');
    } else {
      console.log('✅ Datos ya inicializados');
    }
  } catch (error) {
    console.error('❌ Error inicializando datos:', error);
  }
}

// Inicializar al arrancar
initializeData();

// ==================== RUTAS ====================

// Health check
app.get('/make-server-f5c6167b/health', (c) => {
  return c.json({ status: 'ok', message: 'SISU GRB API funcionando' });
});

// ==================== USUARIOS ====================

// Obtener todos los usuarios
app.get('/make-server-f5c6167b/api/users', async (c) => {
  try {
    const users = await kv.getByPrefix('user:');
    return c.json(users);
  } catch (error) {
    console.error('Error obteniendo usuarios:', error);
    return c.json({ error: 'Error al obtener usuarios' }, 500);
  }
});

// Auto-login con Windows/Azure AD
app.post('/make-server-f5c6167b/api/users/auto-login', async (c) => {
  try {
    const { windowsUsername, displayName, email } = await c.req.json();
    
    if (!windowsUsername || !displayName) {
      return c.json({ error: 'Datos incompletos' }, 400);
    }

    // Buscar usuario existente por username
    const allUsers = await kv.getByPrefix('user:');
    let user = allUsers.find((u: User) => 
      u.username.toLowerCase() === windowsUsername.toLowerCase()
    );

    // Si el usuario no existe, crear uno nuevo
    if (!user) {
      console.log(`🆕 Creando nuevo usuario: ${windowsUsername}`);
      
      // Generar nuevo ID
      const maxId = allUsers.length > 0 
        ? Math.max(...allUsers.map((u: User) => u.id)) 
        : 0;
      const newId = maxId + 1;

      // Asignar equipo por defecto (Operaciones)
      const defaultTeam = TEAMS[4]; // Operaciones

      user = {
        id: newId,
        username: windowsUsername,
        displayName: displayName,
        email: email || `${windowsUsername.split('\\')[1]}@sisugrb.com`,
        teamId: defaultTeam.id,
        team: defaultTeam,
        role: 'Usuario',
        createdAt: new Date().toISOString()
      };

      await kv.set(`user:${newId}`, user);
      console.log(`✅ Usuario creado: ${user.displayName} (ID: ${newId})`);
    } else {
      console.log(`✅ Usuario encontrado: ${user.displayName} (ID: ${user.id})`);
    }

    return c.json(user);
  } catch (error) {
    console.error('Error en auto-login:', error);
    return c.json({ error: 'Error al iniciar sesión' }, 500);
  }
});

// Actualizar equipo de un usuario
app.put('/make-server-f5c6167b/api/users/:id/team', async (c) => {
  try {
    const id = c.req.param('id');
    const { teamId } = await c.req.json();
    
    const user = await kv.get(`user:${id}`);
    if (!user) {
      return c.json({ error: 'Usuario no encontrado' }, 404);
    }

    const team = TEAMS.find(t => t.id === teamId);
    if (!team) {
      return c.json({ error: 'Equipo no encontrado' }, 404);
    }

    const updatedUser = {
      ...user,
      teamId: team.id,
      team: team
    };

    await kv.set(`user:${id}`, updatedUser);
    return c.json(updatedUser);
  } catch (error) {
    console.error('Error actualizando equipo:', error);
    return c.json({ error: 'Error al actualizar equipo' }, 500);
  }
});

// Obtener equipos
app.get('/make-server-f5c6167b/api/teams', async (c) => {
  return c.json(TEAMS);
});

// ==================== SALAS ====================

// Obtener todas las salas
app.get('/make-server-f5c6167b/api/rooms', async (c) => {
  try {
    const rooms = await kv.getByPrefix('room:');
    return c.json(rooms);
  } catch (error) {
    console.error('Error obteniendo salas:', error);
    return c.json({ error: 'Error al obtener salas' }, 500);
  }
});

// Obtener sala por ID
app.get('/make-server-f5c6167b/api/rooms/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const room = await kv.get(`room:${id}`);
    
    if (!room) {
      return c.json({ error: 'Sala no encontrada' }, 404);
    }
    
    return c.json(room);
  } catch (error) {
    console.error('Error obteniendo sala:', error);
    return c.json({ error: 'Error al obtener sala' }, 500);
  }
});

// Actualizar estado de sala (mantenimiento)
app.put('/make-server-f5c6167b/api/rooms/:id/status', async (c) => {
  try {
    const id = c.req.param('id');
    const { status } = await c.req.json();
    
    const room = await kv.get(`room:${id}`);
    if (!room) {
      return c.json({ error: 'Sala no encontrada' }, 404);
    }
    
    const updatedRoom = { ...room, status };
    await kv.set(`room:${id}`, updatedRoom);
    
    return c.json(updatedRoom);
  } catch (error) {
    console.error('Error actualizando estado de sala:', error);
    return c.json({ error: 'Error al actualizar estado de sala' }, 500);
  }
});

// ==================== RESERVAS ====================

// Obtener todas las reservas (con filtro opcional por fecha)
app.get('/make-server-f5c6167b/api/reservations', async (c) => {
  try {
    const date = c.req.query('date');
    let reservations = await kv.getByPrefix('reservation:');
    
    // Filtrar solo reservas activas
    reservations = reservations.filter((r: Reservation) => r.status === 'Active');
    
    // Si hay filtro de fecha, aplicarlo
    if (date) {
      reservations = reservations.filter((r: Reservation) => {
        const reservationDate = new Date(r.startTime).toISOString().split('T')[0];
        return reservationDate === date;
      });
    }
    
    // Enriquecer con información de usuario y sala
    const enrichedReservations = await Promise.all(
      reservations.map(async (reservation: Reservation) => {
        const user = await kv.get(`user:${reservation.userId}`);
        const room = await kv.get(`room:${reservation.roomId}`);
        return { ...reservation, user, room };
      })
    );
    
    return c.json(enrichedReservations);
  } catch (error) {
    console.error('Error obteniendo reservas:', error);
    return c.json({ error: 'Error al obtener reservas' }, 500);
  }
});

// Obtener reservas de un usuario
app.get('/make-server-f5c6167b/api/reservations/user/:userId', async (c) => {
  try {
    const userId = parseInt(c.req.param('userId'));
    const allReservations = await kv.getByPrefix('reservation:');
    
    const userReservations = allReservations.filter(
      (r: Reservation) => r.userId === userId
    );
    
    // Enriquecer con información de sala
    const enrichedReservations = await Promise.all(
      userReservations.map(async (reservation: Reservation) => {
        const room = await kv.get(`room:${reservation.roomId}`);
        return { ...reservation, room };
      })
    );
    
    return c.json(enrichedReservations);
  } catch (error) {
    console.error('Error obteniendo reservas del usuario:', error);
    return c.json({ error: 'Error al obtener reservas del usuario' }, 500);
  }
});

// Crear reserva
app.post('/make-server-f5c6167b/api/reservations', async (c) => {
  try {
    const requestData = await c.req.json();
    console.log('📥 Datos de reserva recibidos:', requestData);
    
    const { roomId, userId, startTime, endTime, purpose } = requestData;
    
    // Validar datos con logging detallado
    if (!roomId || !userId || !startTime || !endTime || !purpose) {
      console.error('❌ Datos incompletos:', {
        roomId: !!roomId,
        userId: !!userId,
        startTime: !!startTime,
        endTime: !!endTime,
        purpose: !!purpose
      });
      return c.json({ 
        error: 'Datos incompletos',
        details: {
          roomId: !!roomId,
          userId: !!userId,
          startTime: !!startTime,
          endTime: !!endTime,
          purpose: !!purpose
        }
      }, 400);
    }
    
    // Verificar que la sala existe
    const room = await kv.get(`room:${roomId}`);
    if (!room) {
      console.error('❌ Sala no encontrada:', roomId);
      return c.json({ error: 'Sala no encontrada' }, 404);
    }
    
    // Verificar que el usuario existe
    const user = await kv.get(`user:${userId}`);
    if (!user) {
      console.error('❌ Usuario no encontrado:', userId);
      return c.json({ error: 'Usuario no encontrado' }, 404);
    }
    
    console.log('✅ Validaciones pasadas - Room:', room.name, '- User:', user.displayName);
    
    // Verificar conflictos de horario - SOLO DEL MISMO DÍA
    const newStartDate = new Date(startTime);
    const newEndDate = new Date(endTime);
    const newDateOnly = newStartDate.toISOString().split('T')[0]; // YYYY-MM-DD
    
    console.log('🔍 Buscando conflictos para fecha:', newDateOnly);
    
    const allReservations = await kv.getByPrefix('reservation:');
    
    // Filtrar solo reservas activas del mismo día y misma sala
    const relevantReservations = allReservations.filter((r: Reservation) => {
      if (r.roomId !== roomId || r.status !== 'Active') return false;
      
      const reservationDate = new Date(r.startTime).toISOString().split('T')[0];
      return reservationDate === newDateOnly;
    });
    
    console.log(`📋 Reservas existentes para ${newDateOnly}:`, relevantReservations.length);
    
    const conflict = relevantReservations.some((r: Reservation) => {
      const existingStart = new Date(r.startTime).getTime();
      const existingEnd = new Date(r.endTime).getTime();
      const newStart = newStartDate.getTime();
      const newEnd = newEndDate.getTime();
      
      const hasConflict = (newStart < existingEnd && newEnd > existingStart);
      
      if (hasConflict) {
        console.log('⚠️ Conflicto detectado con reserva:', {
          existing: `${new Date(existingStart).toLocaleTimeString()} - ${new Date(existingEnd).toLocaleTimeString()}`,
          new: `${newStartDate.toLocaleTimeString()} - ${newEndDate.toLocaleTimeString()}`
        });
      }
      
      return hasConflict;
    });
    
    if (conflict) {
      console.error('❌ Conflicto de horario detectado');
      return c.json({ error: 'Ya existe una reserva en ese horario' }, 409);
    }
    
    // Crear reserva
    const id = Date.now();
    const newReservation: Reservation = {
      id,
      roomId,
      userId,
      startTime,
      endTime,
      purpose,
      status: 'Active',
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`reservation:${id}`, newReservation);
    console.log('✅ Reserva creada exitosamente:', id);
    
    // Enriquecer respuesta
    const enrichedReservation = {
      ...newReservation,
      user,
      room
    };
    
    return c.json(enrichedReservation, 201);
  } catch (error) {
    console.error('❌ Error creando reserva:', error);
    return c.json({ error: 'Error al crear reserva', details: String(error) }, 500);
  }
});

// Cancelar reserva
app.delete('/make-server-f5c6167b/api/reservations/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const { userId } = await c.req.json();
    
    console.log('🗑️ Solicitud de cancelación recibida:', { reservationId: id, userId, userIdType: typeof userId });
    
    const reservation = await kv.get(`reservation:${id}`);
    
    if (!reservation) {
      console.error('❌ Reserva no encontrada:', id);
      return c.json({ error: 'Reserva no encontrada' }, 404);
    }
    
    console.log('📋 Reserva encontrada:', { 
      reservationId: reservation.id, 
      reservationUserId: reservation.userId, 
      reservationUserIdType: typeof reservation.userId,
      requestUserId: userId,
      requestUserIdType: typeof userId,
      match: reservation.userId === userId,
      strictMatch: reservation.userId === Number(userId)
    });
    
    // Verificar que el usuario es el dueño de la reserva - Convertir a número para comparar
    if (Number(reservation.userId) !== Number(userId)) {
      console.error('❌ Usuario no autorizado para cancelar:', { 
        reservationUserId: reservation.userId, 
        requestUserId: userId 
      });
      return c.json({ error: 'No tienes permiso para cancelar esta reserva' }, 403);
    }
    
    console.log('✅ Autorización verificada - cancelando reserva...');
    
    // Actualizar estado a cancelado
    const updatedReservation = { ...reservation, status: 'Cancelled' as const };
    await kv.set(`reservation:${id}`, updatedReservation);
    
    console.log('✅ Reserva cancelada exitosamente:', id);
    
    return c.json({ message: 'Reserva cancelada exitosamente' });
  } catch (error) {
    console.error('❌ Error cancelando reserva:', error);
    return c.json({ error: 'Error al cancelar reserva' }, 500);
  }
});

// Limpiar todas las reservas (útil para debugging/testing)
app.delete('/make-server-f5c6167b/api/reservations/admin/clear-all', async (c) => {
  try {
    const { adminKey } = await c.req.json();
    
    // Validación simple de seguridad
    if (adminKey !== 'sisugrb-admin-2026') {
      return c.json({ error: 'No autorizado' }, 403);
    }
    
    console.log('🗑️ Limpiando todas las reservas...');
    
    const allReservations = await kv.getByPrefix('reservation:');
    
    for (const reservation of allReservations) {
      await kv.del(`reservation:${reservation.id}`);
    }
    
    console.log(`✅ ${allReservations.length} reservas eliminadas`);
    
    return c.json({ 
      message: 'Todas las reservas han sido eliminadas',
      count: allReservations.length
    });
  } catch (error) {
    console.error('Error limpiando reservas:', error);
    return c.json({ error: 'Error al limpiar reservas' }, 500);
  }
});

// Ver todas las reservas crudas (para debugging)
app.get('/make-server-f5c6167b/api/debug/reservations', async (c) => {
  try {
    console.log('🔍 Obteniendo todas las reservas crudas...');
    
    const allReservations = await kv.getByPrefix('reservation:');
    
    console.log(`📊 Total de reservas en la base de datos: ${allReservations.length}`);
    
    // Log de cada reserva
    allReservations.forEach((r: Reservation, index: number) => {
      const startDate = new Date(r.startTime);
      const endDate = new Date(r.endTime);
      console.log(`  ${index + 1}. ID: ${r.id} | Room: ${r.roomId} | Status: ${r.status} | Date: ${startDate.toISOString().split('T')[0]} | Time: ${startDate.toLocaleTimeString()} - ${endDate.toLocaleTimeString()}`);
    });
    
    return c.json({
      total: allReservations.length,
      reservations: allReservations.map((r: Reservation) => ({
        id: r.id,
        roomId: r.roomId,
        userId: r.userId,
        startTime: r.startTime,
        endTime: r.endTime,
        purpose: r.purpose,
        status: r.status,
        createdAt: r.createdAt,
        dateOnly: new Date(r.startTime).toISOString().split('T')[0],
        timeRange: `${new Date(r.startTime).toLocaleTimeString()} - ${new Date(r.endTime).toLocaleTimeString()}`
      }))
    });
  } catch (error) {
    console.error('Error obteniendo reservas debug:', error);
    return c.json({ error: 'Error al obtener reservas' }, 500);
  }
});

// ==================== MANTENIMIENTO ====================

// Obtener salas en mantenimiento
app.get('/make-server-f5c6167b/api/maintenance', async (c) => {
  try {
    const maintenanceRooms = await kv.getByPrefix('maintenance:');
    const roomIds = maintenanceRooms.map((m: any) => m.roomId);
    return c.json(roomIds);
  } catch (error) {
    console.error('Error obteniendo mantenimiento:', error);
    return c.json({ error: 'Error al obtener mantenimiento' }, 500);
  }
});

// Toggle mantenimiento
app.post('/make-server-f5c6167b/api/maintenance/toggle', async (c) => {
  try {
    const { roomId, inMaintenance, userId } = await c.req.json();
    
    // Verificar que el usuario tiene permiso para gestionar mantenimiento
    const user = await kv.get(`user:${userId}`);
    if (!user || !user.canManageMaintenance) {
      return c.json({ error: 'No tienes permiso para gestionar mantenimiento' }, 403);
    }
    
    const room = await kv.get(`room:${roomId}`);
    if (!room) {
      return c.json({ error: 'Sala no encontrada' }, 404);
    }
    
    if (inMaintenance) {
      // Poner en mantenimiento
      await kv.set(`maintenance:${roomId}`, { roomId, timestamp: new Date().toISOString() });
      const updatedRoom = { ...room, status: 'Mantenimiento' as const };
      await kv.set(`room:${roomId}`, updatedRoom);
    } else {
      // Quitar de mantenimiento
      await kv.del(`maintenance:${roomId}`);
      const updatedRoom = { ...room, status: 'Libre' as const };
      await kv.set(`room:${roomId}`, updatedRoom);
    }
    
    return c.json({ message: 'Estado de mantenimiento actualizado' });
  } catch (error) {
    console.error('Error actualizando mantenimiento:', error);
    return c.json({ error: 'Error al actualizar mantenimiento' }, 500);
  }
});

// Iniciar servidor
Deno.serve(app.fetch);