# 🚀 Inicio Rápido - Sistema de Reservas SISU GRB

## ⚡ Empieza a Usar en 3 Pasos

### 1️⃣ Activa el Modo Demo

Abre la **consola del navegador** (presiona `F12`) y ejecuta:

```javascript
localStorage.setItem('sisugrb_demo_mode', 'true');
location.reload();
```

### 2️⃣ Selecciona un Usuario

Elige uno de los 4 usuarios de demostración:
- **María González** (Operaciones)
- **Juan Pérez** (Ventas)
- **Ana López** (Tecnología)
- **José Luis Pimienta** (Administración) ⭐ Admin

### 3️⃣ ¡Listo! Crea tu Primera Reserva

Ve a cualquier sala, elige un horario y crea una reserva.

---

## 📅 Horarios Disponibles (HOY)

| Sala | Estado | Horarios LIBRES |
|------|--------|-----------------|
| **Piso 1** (10 personas) | Ocupada 9:00-10:00 | ✅ 10:00 AM - 6:00 PM |
| **Piso 2** (10 personas) | Libre | ✅ **TODO EL DÍA** |
| **Piso 3** (30 personas) | Ocupada 15:00-16:00 | ✅ 8:30 AM - 3:00 PM, 4:00 PM - 6:00 PM |

---

## 🎯 Pruébalo Ahora - Escenarios Rápidos

### Escenario 1: Crear una Reserva (2 minutos)
1. Activa modo demo (comando de arriba)
2. Login como **Juan Pérez**
3. Selecciona **Sala Piso 2**
4. Click en "Nueva Reserva"
5. Elige horario: **10:00 - 11:00**
6. Propósito: "Reunión con cliente"
7. Click "Crear Reserva"
8. ✅ ¡Listo! Verás tu reserva creada

### Escenario 2: Ver y Cancelar Reserva (1 minuto)
1. Ve a la sección "Mis Reservas"
2. Verás la reserva que acabas de crear
3. Click en "Cancelar"
4. Confirma
5. ✅ Reserva cancelada exitosamente

### Escenario 3: Probar Panel de Admin (3 minutos)
1. Logout (botón arriba a la derecha)
2. Login como **José Luis Pimienta** (Admin)
3. Verás el panel de "Gestión de Mantenimiento"
4. Pon **Sala Piso 2** en mantenimiento
5. Intenta crear una reserva en esa sala
6. ✅ Verás el error "La sala está en mantenimiento"
7. Quita el mantenimiento para liberar la sala

---

## 🔧 Herramientas de Debugging

### Consola Siempre Abierta
Mantén la consola del navegador abierta (`F12`) para ver:
- 🔍 Validación de reservas
- 📋 Reservas activas en cada sala
- ✅ Confirmaciones de operaciones
- ❌ Errores detallados con contexto

### Botón de Reset en la UI
Si ves el banner morado en la parte superior:
- Click en **"Reset Datos"** para empezar desde cero
- Click en **"Salir del Modo Demo"** para volver al modo normal

### Comandos de Emergencia
Si algo sale mal, ejecuta en la consola:

```javascript
// Reset completo - Borra todo y empieza de cero
localStorage.clear();
localStorage.setItem('sisugrb_demo_mode', 'true');
location.reload();
```

---

## 📊 ¿Qué Puedes Probar?

### ✅ Funcionalidades Completas

| Función | Disponible | Notas |
|---------|------------|-------|
| Crear reservas | ✅ | Todas las salas |
| Cancelar reservas | ✅ | Solo las tuyas |
| Ver reservas por fecha | ✅ | Cambia la fecha en el calendario |
| Estado de salas | ✅ | Libre, Ocupado, Mantenimiento |
| Panel de mantenimiento | ✅ | Solo para admin |
| Cambiar de usuario | ✅ | Logout y login |
| Validación de conflictos | ✅ | No puedes reservar horarios ocupados |
| Validación de horarios | ✅ | Solo 8:30 AM - 6:00 PM, Lun-Vie |

### ⚠️ Limitaciones del Modo Demo

| Limitación | Explicación |
|------------|-------------|
| Datos locales | Solo en este navegador |
| Sin sincronización | No se comparte entre dispositivos |
| Se pierde con caché | Si borras caché, pierdes los datos |
| No es multi-usuario real | Solo simula usuarios |

---

## 🎓 Tips para una Mejor Experiencia

### 1. Siempre Abre la Consola (F12)
Los logs te dirán exactamente qué está pasando:
```
🔍 Validando nueva reserva: ...
📋 Reservas activas en sala 1: ...
✅ Reserva creada exitosamente en modo demo: ...
```

### 2. Usa Sala Piso 2 para Pruebas
Está completamente libre, así no tendrás conflictos.

### 3. Si Ves Errores de Conflicto
- Abre la consola
- Lee qué reserva está causando el conflicto
- Verifica quién la hizo y a qué hora
- Elige otro horario o cancela la reserva (si es tuya)

### 4. Resetea Si Algo se Traba
Click en "Reset Datos" en el banner morado.

### 5. Prueba con Diferentes Usuarios
- Logout
- Login con otro usuario
- Intenta cancelar una reserva de otro usuario (debería fallar)

---

## 🐛 Solución Rápida de Problemas

| Problema | Solución |
|----------|----------|
| "Ya existe una reserva en ese horario" | Verifica los logs en consola, usa otro horario, o usa Sala Piso 2 que está libre |
| "La sala está en mantenimiento" | Ve al panel de admin y quita el mantenimiento |
| No veo el banner morado | Ejecuta el comando de activación de modo demo |
| Las reservas desaparecieron | Probablemente se borró el caché. Ejecuta un reset completo |
| No puedo crear ninguna reserva | Verifica que el horario sea 8:30 AM - 6:00 PM, Lun-Vie |

---

## 📖 Documentación Completa

- **[MODO_DEMO.md](./MODO_DEMO.md)** - Guía completa del modo demo
- **[RESET_DEMO.md](./RESET_DEMO.md)** - Cómo resetear datos
- **[SOLUCION_CONFLICTOS.md](./SOLUCION_CONFLICTOS.md)** - Solución de errores de conflictos
- **[README.md](./README.md)** - Documentación general
- **[INSTRUCCIONES_DESPLIEGUE.md](./INSTRUCCIONES_DESPLIEGUE.md)** - Para producción

---

## 🎯 Siguiente Paso: Producción

Cuando quieras usar la aplicación en producción:

1. **Sal del modo demo**
   ```javascript
   localStorage.removeItem('sisugrb_demo_mode');
   location.reload();
   ```

2. **Despliega el backend en Supabase**
   ```bash
   supabase login
   supabase link --project-ref daowqmfdusubyicuuowy
   supabase functions deploy make-server-f5c6167b --no-verify-jwt
   ```

3. **Configura Azure AD** para auto-login

4. **¡A producción!** 🚀

---

## 💬 ¿Necesitas Ayuda?

Si tienes problemas:

1. Abre la consola (F12)
2. Intenta la operación que falla
3. Copia los logs de la consola
4. Revisa la documentación relevante
5. Ejecuta un reset completo si es necesario

---

## ✅ Checklist de Inicio

- [ ] Activar modo demo (comando en consola)
- [ ] Seleccionar un usuario
- [ ] Ver el banner morado en la parte superior
- [ ] Abrir la consola del navegador (F12)
- [ ] Crear una reserva de prueba en Sala Piso 2
- [ ] Ver la reserva en "Mis Reservas"
- [ ] Cancelar la reserva
- [ ] Probar con otro usuario
- [ ] Explorar panel de admin (con José Luis Pimienta)
- [ ] Familiarizarse con los logs en consola

---

**¡Listo! Ahora puedes probar la aplicación completa sin necesidad de desplegar el backend. 🎉**

**Tiempo estimado para completar:** 10-15 minutos
