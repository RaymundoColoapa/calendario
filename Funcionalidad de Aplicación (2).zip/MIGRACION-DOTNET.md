# 📋 Guía de Migración a .NET Core + SQL Server Express

## Sistema de Reservas de Salas - SISU GRB

Esta aplicación React actualmente funciona con datos mockeados y **autenticación Windows simulada**. Esta guía te ayudará a migrarla a una aplicación completa con backend .NET Core, base de datos SQL Server Express, y **Windows Authentication real**.

---

## 🔒 Implementación de Windows Authentication en .NET

### Configuración en Program.cs

```csharp
using Microsoft.AspNetCore.Server.HttpSys;
using Microsoft.AspNetCore.Authentication.Negotiate;

var builder = WebApplication.CreateBuilder(args);

// Configurar Windows Authentication
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
    .AddNegotiate();

// Configurar autorización
builder.Services.AddAuthorization();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Usar autenticación y autorización
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.Run();
```

### Obtener Usuario Actual en Controllers

```csharp
[Authorize] // Requiere autenticación
[Route("api/[controller]")]
[ApiController]
public class ReservationsController : ControllerBase
{
    private readonly IReservationService _reservationService;
    private readonly IUserService _userService;

    public ReservationsController(
        IReservationService reservationService,
        IUserService userService)
    {
        _reservationService = reservationService;
        _userService = userService;
    }

    // GET: api/users/current
    [HttpGet("current")]
    public async Task<ActionResult<UserDto>> GetCurrentUser()
    {
        // Obtener el usuario de Windows automáticamente
        var windowsUsername = User.Identity?.Name; // Ejemplo: "SISUGRB\\mgonzalez"
        
        if (string.IsNullOrEmpty(windowsUsername))
            return Unauthorized();

        var user = await _userService.GetUserByWindowsUsernameAsync(windowsUsername);
        
        if (user == null)
            return NotFound("Usuario no encontrado en el sistema");

        return Ok(user);
    }

    // POST: api/reservations
    [HttpPost]
    public async Task<ActionResult<ReservationDto>> CreateReservation(
        ReservationCreateDto createDto)
    {
        // Obtener usuario automáticamente desde Windows
        var windowsUsername = User.Identity?.Name;
        
        if (string.IsNullOrEmpty(windowsUsername))
            return Unauthorized();

        var currentUser = await _userService.GetUserByWindowsUsernameAsync(windowsUsername);
        
        if (currentUser == null)
            return NotFound("Usuario no encontrado");

        // El usuario del sistema es el que hace la reserva
        createDto.OrganizerId = currentUser.UserId;
        createDto.WindowsUsername = windowsUsername;

        try
        {
            var reservation = await _reservationService.CreateReservationAsync(createDto);
            return CreatedAtAction(nameof(GetReservation), 
                new { id = reservation.ReservationId }, reservation);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    // DELETE: api/reservations/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> CancelReservation(int id)
    {
        // Obtener usuario automáticamente
        var windowsUsername = User.Identity?.Name;
        
        if (string.IsNullOrEmpty(windowsUsername))
            return Unauthorized();

        var currentUser = await _userService.GetUserByWindowsUsernameAsync(windowsUsername);
        
        if (currentUser == null)
            return NotFound("Usuario no encontrado");

        try
        {
            // Validar que sea el organizador
            var result = await _reservationService.CancelReservationAsync(
                id, currentUser.UserId, windowsUsername);
            
            if (!result)
                return NotFound();

            return NoContent();
        }
        catch (UnauthorizedAccessException ex)
        {
            return Forbid(ex.Message);
        }
    }
}
```

### Agregar WindowsUsername a la tabla Users

```sql
-- Modificar tabla Users para incluir WindowsUsername
ALTER TABLE Users
ADD WindowsUsername NVARCHAR(200) NOT NULL;

-- Crear índice único para WindowsUsername
CREATE UNIQUE INDEX IX_Users_WindowsUsername ON Users(WindowsUsername);

-- Actualizar usuarios existentes con WindowsUsername
UPDATE Users SET WindowsUsername = 'SISUGRB\mgonzalez' WHERE Email = 'maria.gonzalez@sisugrp.com';
UPDATE Users SET WindowsUsername = 'SISUGRB\jperez' WHERE Email = 'juan.perez@sisugrp.com';
-- ... etc
```

### Actualizar Modelo User.cs

```csharp
[Table("Users")]
public class User
{
    [Key]
    public int UserId { get; set; }

    [Required]
    [StringLength(200)]
    public string FullName { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    [StringLength(200)]
    public string Email { get; set; } = string.Empty;

    [Required]
    [StringLength(200)]
    public string WindowsUsername { get; set; } = string.Empty; // NUEVO

    [Required]
    public int TeamId { get; set; }

    [ForeignKey("TeamId")]
    public virtual Team Team { get; set; } = null!;

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    // Navegación
    public virtual ICollection<Reservation> OrganizedReservations { get; set; } = new List<Reservation>();
}
```

### Service con Validación Windows

```csharp
public async Task<bool> CancelReservationAsync(
    int reservationId, 
    int userId, 
    string windowsUsername)
{
    var reservation = await _context.Reservations
        .Include(r => r.Organizer)
        .FirstOrDefaultAsync(r => r.ReservationId == reservationId);

    if (reservation == null)
        return false;

    // VALIDACIÓN DOBLE: Usuario ID y Windows Username
    if (reservation.OrganizerId != userId || 
        !reservation.Organizer.WindowsUsername.Equals(windowsUsername, StringComparison.OrdinalIgnoreCase))
    {
        throw new UnauthorizedAccessException(
            "Solo el organizador de la reserva puede cancelarla.");
    }

    reservation.IsCancelled = true;
    reservation.CancelledAt = DateTime.Now;
    reservation.CancelledBy = userId;

    await _context.SaveChangesAsync();
    return true;
}
```

### Configurar IIS/IIS Express para Windows Authentication

1. Abrir `launchSettings.json` en el proyecto API:

```json
{
  "profiles": {
    "SisuGrp.RoomReservations.API": {
      "commandName": "Project",
      "launchBrowser": true,
      "launchUrl": "swagger",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      },
      "applicationUrl": "http://localhost:5000",
      "windowsAuthentication": true,
      "anonymousAuthentication": false
    }
  }
}
```

2. Modificar `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=SisuGrpRoomReservations;Integrated Security=true;TrustServerCertificate=True;"
  },
  "Authentication": {
    "WindowsAuthentication": {
      "Enabled": true
    }
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

### Frontend: Eliminar Login Simulado

Una vez implementada la autenticación Windows en .NET, el frontend ya NO necesita el componente `WindowsLogin`. El usuario será detectado automáticamente:

```typescript
// services/api.ts
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const api = {
  // Obtener usuario actual automáticamente desde Windows
  getCurrentUser: async () => {
    const response = await fetch(`${API_BASE_URL}/users/current`, {
      credentials: 'include', // IMPORTANTE: enviar credenciales de Windows
    });
    
    if (!response.ok) {
      throw new Error('No autenticado');
    }
    
    return response.json();
  },

  // Todas las peticiones deben incluir credentials: 'include'
  createReservation: async (reservation: any) => {
    const response = await fetch(`${API_BASE_URL}/reservations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(reservation),
      credentials: 'include', // IMPORTANTE
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Error al crear reserva');
    }
    
    return response.json();
  },
};
```

```typescript
// App.tsx - Versión Final con Windows Auth Real
export default function App() {
  const [currentUser, setCurrentUser] = useState<TeamMember | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadCurrentUser = async () => {
      try {
        // El backend detecta automáticamente el usuario de Windows
        const user = await api.getCurrentUser();
        setCurrentUser(user);
      } catch (error) {
        console.error('Error de autenticación:', error);
        toast.error('No se pudo autenticar. Verifica tu conexión.');
      } finally {
        setIsLoading(false);
      }
    };

    loadCurrentUser();
  }, []);

  if (isLoading) {
    return <div>Autenticando...</div>;
  }

  if (!currentUser) {
    return (
      <div>
        <h1>Error de Autenticación</h1>
        <p>No se pudo detectar tu usuario de Windows.</p>
      </div>
    );
  }

  // ... resto del componente
}
```

---

## 🏗️ Arquitectura Propuesta

```
┌─────────────────────────────────────────┐
│   Frontend (React + Vite)               │
│   - UI existente                        │
│   - Comunicación vía API REST           │
└──────────────┬──────────────────────────┘
               │ HTTP/HTTPS
┌──────────────▼──────────────────────────┐
│   Backend (.NET 8 Web API)              │
│   - Controllers                         │
│   - Services (Lógica de negocio)        │
│   - Entity Framework Core               │
└──────────────┬──────────────────────────┘
               │ ADO.NET / EF Core
┌──────────────▼──────────────────────────┐
│   SQL Server Express                    │
│   - Tablas normalizadas                 │
│   - Stored Procedures (opcional)        │
│   - Triggers para auditoría             │
└─────────────────────────────────────────┘
```

---

## 📦 Estructura de la Base de Datos

### Tablas Principales

#### 1. **Teams** (Equipos/Departamentos)
```sql
CREATE TABLE Teams (
    TeamId INT IDENTITY(1,1) PRIMARY KEY,
    TeamName NVARCHAR(100) NOT NULL UNIQUE,
    Description NVARCHAR(500),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    IsActive BIT DEFAULT 1
);
```

#### 2. **Users** (Usuarios/Miembros del Equipo)
```sql
CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200) NOT NULL,
    Email NVARCHAR(200) NOT NULL UNIQUE,
    TeamId INT NOT NULL,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    WindowsUsername NVARCHAR(200) NOT NULL, -- NUEVO
    CONSTRAINT FK_Users_Teams FOREIGN KEY (TeamId) REFERENCES Teams(TeamId)
);

-- Índices para búsqueda rápida
CREATE INDEX IX_Users_Email ON Users(Email);
CREATE INDEX IX_Users_TeamId ON Users(TeamId);
CREATE UNIQUE INDEX IX_Users_WindowsUsername ON Users(WindowsUsername);
```

#### 3. **Rooms** (Salas de Juntas)
```sql
CREATE TABLE Rooms (
    RoomId INT IDENTITY(1,1) PRIMARY KEY,
    RoomName NVARCHAR(100) NOT NULL,
    Location NVARCHAR(100) NOT NULL,
    Capacity INT NOT NULL,
    Floor INT NOT NULL,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE()
);
```

#### 4. **RoomAmenities** (Servicios de las Salas)
```sql
CREATE TABLE RoomAmenities (
    AmenityId INT IDENTITY(1,1) PRIMARY KEY,
    RoomId INT NOT NULL,
    AmenityName NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_RoomAmenities_Rooms FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId)
);
```

#### 5. **RoomStatus** (Estados de las Salas)
```sql
CREATE TABLE RoomStatus (
    StatusId INT IDENTITY(1,1) PRIMARY KEY,
    StatusName NVARCHAR(50) NOT NULL UNIQUE -- 'Available', 'Occupied', 'Maintenance'
);

-- Insertar estados predefinidos
INSERT INTO RoomStatus (StatusName) VALUES 
    ('Available'), 
    ('Occupied'), 
    ('Maintenance');
```

#### 6. **RoomCurrentStatus** (Estado Actual de cada Sala)
```sql
CREATE TABLE RoomCurrentStatus (
    RoomId INT PRIMARY KEY,
    StatusId INT NOT NULL,
    LastUpdated DATETIME2 DEFAULT GETDATE(),
    UpdatedBy INT, -- UserId que cambió el estado
    MaintenanceStartTime TIME,
    MaintenanceEndTime TIME,
    CONSTRAINT FK_RoomCurrentStatus_Rooms FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId),
    CONSTRAINT FK_RoomCurrentStatus_Status FOREIGN KEY (StatusId) REFERENCES RoomStatus(StatusId),
    CONSTRAINT FK_RoomCurrentStatus_User FOREIGN KEY (UpdatedBy) REFERENCES Users(UserId)
);
```

#### 7. **Reservations** (Reservas)
```sql
CREATE TABLE Reservations (
    ReservationId INT IDENTITY(1,1) PRIMARY KEY,
    RoomId INT NOT NULL,
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000),
    ReservationDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    OrganizerId INT NOT NULL, -- Usuario que organiza
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    CreatedBy INT NOT NULL, -- Usuario que creó la reserva
    IsCancelled BIT DEFAULT 0,
    CancelledAt DATETIME2,
    CancelledBy INT,
    CONSTRAINT FK_Reservations_Rooms FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId),
    CONSTRAINT FK_Reservations_Organizer FOREIGN KEY (OrganizerId) REFERENCES Users(UserId),
    CONSTRAINT FK_Reservations_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
    CONSTRAINT FK_Reservations_CancelledBy FOREIGN KEY (CancelledBy) REFERENCES Users(UserId),
    CONSTRAINT CHK_Reservations_Time CHECK (StartTime < EndTime)
);

-- Índices para mejorar consultas
CREATE INDEX IX_Reservations_RoomDate ON Reservations(RoomId, ReservationDate);
CREATE INDEX IX_Reservations_Organizer ON Reservations(OrganizerId);
```

#### 8. **ReservationAttendees** (Asistentes a las Reuniones)
```sql
CREATE TABLE ReservationAttendees (
    AttendeeId INT IDENTITY(1,1) PRIMARY KEY,
    ReservationId INT NOT NULL,
    UserId INT NOT NULL,
    CONSTRAINT FK_ReservationAttendees_Reservation FOREIGN KEY (ReservationId) REFERENCES Reservations(ReservationId),
    CONSTRAINT FK_ReservationAttendees_User FOREIGN KEY (UserId) REFERENCES Users(UserId),
    CONSTRAINT UQ_ReservationAttendees UNIQUE(ReservationId, UserId)
);
```

#### 9. **ServiceTypes** (Tipos de Servicios)
```sql
CREATE TABLE ServiceTypes (
    ServiceTypeId INT IDENTITY(1,1) PRIMARY KEY,
    ServiceName NVARCHAR(100) NOT NULL UNIQUE
);

-- Insertar servicios predefinidos
INSERT INTO ServiceTypes (ServiceName) VALUES 
    ('Cafés'), 
    ('Aguas'), 
    ('Galletas'), 
    ('Refrescos'), 
    ('IdeaShare');
```

#### 10. **ReservationServices** (Servicios solicitados por Reserva)
```sql
CREATE TABLE ReservationServices (
    ReservationServiceId INT IDENTITY(1,1) PRIMARY KEY,
    ReservationId INT NOT NULL,
    ServiceTypeId INT NOT NULL,
    CONSTRAINT FK_ReservationServices_Reservation FOREIGN KEY (ReservationId) REFERENCES Reservations(ReservationId),
    CONSTRAINT FK_ReservationServices_ServiceType FOREIGN KEY (ServiceTypeId) REFERENCES ServiceTypes(ServiceTypeId),
    CONSTRAINT UQ_ReservationServices UNIQUE(ReservationId, ServiceTypeId)
);
```

---

## 🔐 Validaciones y Reglas de Negocio

### 1. **Validación de Conflictos de Horario**
```sql
CREATE PROCEDURE sp_ValidateReservationConflict
    @RoomId INT,
    @ReservationDate DATE,
    @StartTime TIME,
    @EndTime TIME,
    @ExcludeReservationId INT = NULL
AS
BEGIN
    SELECT COUNT(*) AS ConflictCount
    FROM Reservations
    WHERE RoomId = @RoomId
      AND ReservationDate = @ReservationDate
      AND IsCancelled = 0
      AND (@ExcludeReservationId IS NULL OR ReservationId != @ExcludeReservationId)
      AND (
          -- Nueva reserva inicia durante reserva existente
          (@StartTime >= StartTime AND @StartTime < EndTime)
          OR
          -- Nueva reserva termina durante reserva existente
          (@EndTime > StartTime AND @EndTime <= EndTime)
          OR
          -- Nueva reserva engloba reserva existente
          (@StartTime <= StartTime AND @EndTime >= EndTime)
      );
END;
```

### 2. **Validación de Horario Laboral (8:30 AM - 6:00 PM)**
```sql
CREATE FUNCTION fn_ValidateBusinessHours
(
    @StartTime TIME,
    @EndTime TIME
)
RETURNS BIT
AS
BEGIN
    DECLARE @IsValid BIT = 0;
    
    IF (@StartTime >= '08:30:00' 
        AND @EndTime <= '18:00:00' 
        AND @StartTime < @EndTime)
    BEGIN
        SET @IsValid = 1;
    END
    
    RETURN @IsValid;
END;
```

### 3. **Validación de Días Laborales (Lunes-Viernes)**
```sql
CREATE FUNCTION fn_ValidateWeekday
(
    @ReservationDate DATE
)
RETURNS BIT
AS
BEGIN
    DECLARE @IsValid BIT = 0;
    DECLARE @DayOfWeek INT = DATEPART(WEEKDAY, @ReservationDate);
    
    -- 2=Lunes, 3=Martes, 4=Miércoles, 5=Jueves, 6=Viernes
    IF (@DayOfWeek BETWEEN 2 AND 6)
    BEGIN
        SET @IsValid = 1;
    END
    
    RETURN @IsValid;
END;
```

### 4. **Trigger para Auditoría**
```sql
CREATE TABLE AuditLog (
    AuditId INT IDENTITY(1,1) PRIMARY KEY,
    TableName NVARCHAR(100),
    Action NVARCHAR(50),
    RecordId INT,
    UserId INT,
    ChangeDetails NVARCHAR(MAX),
    ChangedAt DATETIME2 DEFAULT GETDATE()
);

CREATE TRIGGER tr_Reservations_Audit
ON Reservations
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    
    IF EXISTS(SELECT * FROM inserted)
    BEGIN
        IF EXISTS(SELECT * FROM deleted)
        BEGIN
            -- UPDATE
            INSERT INTO AuditLog (TableName, Action, RecordId, UserId, ChangeDetails)
            SELECT 'Reservations', 'UPDATE', i.ReservationId, i.CreatedBy,
                   'Reserva actualizada'
            FROM inserted i;
        END
        ELSE
        BEGIN
            -- INSERT
            INSERT INTO AuditLog (TableName, Action, RecordId, UserId, ChangeDetails)
            SELECT 'Reservations', 'INSERT', i.ReservationId, i.CreatedBy,
                   'Nueva reserva: ' + i.Title
            FROM inserted i;
        END
    END
    ELSE
    BEGIN
        -- DELETE
        INSERT INTO AuditLog (TableName, Action, RecordId, UserId, ChangeDetails)
        SELECT 'Reservations', 'DELETE', d.ReservationId, d.CreatedBy,
               'Reserva eliminada: ' + d.Title
        FROM deleted d;
    END
END;
```

---

## 🎯 Backend .NET Core - Estructura del Proyecto

### Estructura de Carpetas
```
SisuGrp.RoomReservations/
├── SisuGrp.RoomReservations.API/          # Web API
│   ├── Controllers/
│   │   ├── RoomsController.cs
│   │   ├── ReservationsController.cs
│   │   ├── UsersController.cs
│   │   └── TeamsController.cs
│   ├── Program.cs
│   └── appsettings.json
│
├── SisuGrp.RoomReservations.Core/         # Lógica de negocio
│   ├── Models/
│   │   ├── Room.cs
│   │   ├── Reservation.cs
│   │   ├── User.cs
│   │   └── Team.cs
│   ├── DTOs/
│   │   ├── ReservationCreateDto.cs
│   │   ├── ReservationDto.cs
│   │   └── ...
│   ├── Interfaces/
│   │   ├── IReservationService.cs
│   │   └── IRoomService.cs
│   └── Services/
│       ├── ReservationService.cs
│       └── RoomService.cs
│
└── SisuGrp.RoomReservations.Data/         # Acceso a datos
    ├── AppDbContext.cs
    ├── Repositories/
    │   ├── ReservationRepository.cs
    │   └── RoomRepository.cs
    └── Migrations/
```

### Modelos C# (Ejemplos)

#### **User.cs**
```csharp
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisuGrp.RoomReservations.Core.Models
{
    [Table("Users")]
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        [StringLength(200)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(200)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [StringLength(200)]
        public string WindowsUsername { get; set; } = string.Empty; // NUEVO

        [Required]
        public int TeamId { get; set; }

        [ForeignKey("TeamId")]
        public virtual Team Team { get; set; } = null!;

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // Navegación
        public virtual ICollection<Reservation> OrganizedReservations { get; set; } = new List<Reservation>();
    }
}
```

#### **Reservation.cs**
```csharp
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisuGrp.RoomReservations.Core.Models
{
    [Table("Reservations")]
    public class Reservation
    {
        [Key]
        public int ReservationId { get; set; }

        [Required]
        public int RoomId { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; } = null!;

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [StringLength(1000)]
        public string? Description { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime ReservationDate { get; set; }

        [Required]
        [Column(TypeName = "time")]
        public TimeSpan StartTime { get; set; }

        [Required]
        [Column(TypeName = "time")]
        public TimeSpan EndTime { get; set; }

        [Required]
        public int OrganizerId { get; set; }

        [ForeignKey("OrganizerId")]
        public virtual User Organizer { get; set; } = null!;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Required]
        public int CreatedBy { get; set; }

        [ForeignKey("CreatedBy")]
        public virtual User Creator { get; set; } = null!;

        public bool IsCancelled { get; set; } = false;

        public DateTime? CancelledAt { get; set; }

        public int? CancelledBy { get; set; }

        // Navegación
        public virtual ICollection<ReservationAttendee> Attendees { get; set; } = new List<ReservationAttendee>();
        public virtual ICollection<ReservationService> Services { get; set; } = new List<ReservationService>();
    }
}
```

### Controller Ejemplo: **ReservationsController.cs**

```csharp
using Microsoft.AspNetCore.Mvc;
using SisuGrp.RoomReservations.Core.DTOs;
using SisuGrp.RoomReservations.Core.Interfaces;

namespace SisuGrp.RoomReservations.API.Controllers
{
    [Authorize] // Requiere autenticación
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationsController : ControllerBase
    {
        private readonly IReservationService _reservationService;
        private readonly IUserService _userService;

        public ReservationsController(
            IReservationService reservationService,
            IUserService userService)
        {
            _reservationService = reservationService;
            _userService = userService;
        }

        // GET: api/reservations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReservationDto>>> GetReservations(
            [FromQuery] DateTime? date = null)
        {
            var reservations = await _reservationService.GetReservationsAsync(date);
            return Ok(reservations);
        }

        // GET: api/reservations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ReservationDto>> GetReservation(int id)
        {
            var reservation = await _reservationService.GetReservationByIdAsync(id);
            
            if (reservation == null)
                return NotFound();

            return Ok(reservation);
        }

        // POST: api/reservations
        [HttpPost]
        public async Task<ActionResult<ReservationDto>> CreateReservation(
            ReservationCreateDto createDto)
        {
            // Obtener usuario automáticamente desde Windows
            var windowsUsername = User.Identity?.Name;
            
            if (string.IsNullOrEmpty(windowsUsername))
                return Unauthorized();

            var currentUser = await _userService.GetUserByWindowsUsernameAsync(windowsUsername);
            
            if (currentUser == null)
                return NotFound("Usuario no encontrado");

            // El usuario del sistema es el que hace la reserva
            createDto.OrganizerId = currentUser.UserId;
            createDto.WindowsUsername = windowsUsername;

            try
            {
                var reservation = await _reservationService.CreateReservationAsync(createDto);
                return CreatedAtAction(nameof(GetReservation), 
                    new { id = reservation.ReservationId }, reservation);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // DELETE: api/reservations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> CancelReservation(int id)
        {
            // Obtener usuario automáticamente
            var windowsUsername = User.Identity?.Name;
            
            if (string.IsNullOrEmpty(windowsUsername))
                return Unauthorized();

            var currentUser = await _userService.GetUserByWindowsUsernameAsync(windowsUsername);
            
            if (currentUser == null)
                return NotFound("Usuario no encontrado");

            try
            {
                // Validar que sea el organizador
                var result = await _reservationService.CancelReservationAsync(
                    id, currentUser.UserId, windowsUsername);
                
                if (!result)
                    return NotFound();

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Forbid(ex.Message);
            }
        }

        // GET: api/reservations/validate-conflict
        [HttpGet("validate-conflict")]
        public async Task<ActionResult<bool>> ValidateConflict(
            [FromQuery] int roomId,
            [FromQuery] DateTime date,
            [FromQuery] TimeSpan startTime,
            [FromQuery] TimeSpan endTime,
            [FromQuery] int? excludeReservationId = null)
        {
            var hasConflict = await _reservationService.HasConflictAsync(
                roomId, date, startTime, endTime, excludeReservationId);

            return Ok(new { hasConflict });
        }
    }
}
```

### Service Ejemplo: **ReservationService.cs**

```csharp
using SisuGrp.RoomReservations.Core.DTOs;
using SisuGrp.RoomReservations.Core.Interfaces;
using SisuGrp.RoomReservations.Core.Models;
using SisuGrp.RoomReservations.Data;

namespace SisuGrp.RoomReservations.Core.Services
{
    public class ReservationService : IReservationService
    {
        private readonly AppDbContext _context;

        public ReservationService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ReservationDto> CreateReservationAsync(ReservationCreateDto createDto)
        {
            // Validar día laboral
            if (createDto.ReservationDate.DayOfWeek == DayOfWeek.Saturday || 
                createDto.ReservationDate.DayOfWeek == DayOfWeek.Sunday)
            {
                throw new InvalidOperationException(
                    "Las salas solo están disponibles de Lunes a Viernes.");
            }

            // Validar horario laboral
            var openingTime = new TimeSpan(8, 30, 0);
            var closingTime = new TimeSpan(18, 0, 0);

            if (createDto.StartTime < openingTime || createDto.EndTime > closingTime)
            {
                throw new InvalidOperationException(
                    "El horario de operación es de 8:30 AM a 6:00 PM.");
            }

            // Validar conflictos
            var hasConflict = await HasConflictAsync(
                createDto.RoomId, 
                createDto.ReservationDate, 
                createDto.StartTime, 
                createDto.EndTime);

            if (hasConflict)
            {
                throw new InvalidOperationException(
                    "Ya existe una reserva en esta sala para el horario seleccionado.");
            }

            // Crear reserva
            var reservation = new Reservation
            {
                RoomId = createDto.RoomId,
                Title = createDto.Title,
                Description = createDto.Description,
                ReservationDate = createDto.ReservationDate,
                StartTime = createDto.StartTime,
                EndTime = createDto.EndTime,
                OrganizerId = createDto.OrganizerId,
                CreatedBy = createDto.OrganizerId // En un sistema real, esto vendría del usuario autenticado
            };

            _context.Reservations.Add(reservation);
            await _context.SaveChangesAsync();

            // Agregar asistentes si los hay
            if (createDto.AttendeeIds != null && createDto.AttendeeIds.Any())
            {
                foreach (var attendeeId in createDto.AttendeeIds)
                {
                    _context.ReservationAttendees.Add(new ReservationAttendee
                    {
                        ReservationId = reservation.ReservationId,
                        UserId = attendeeId
                    });
                }
                await _context.SaveChangesAsync();
            }

            // Agregar servicios si los hay
            if (createDto.ServiceTypeIds != null && createDto.ServiceTypeIds.Any())
            {
                foreach (var serviceId in createDto.ServiceTypeIds)
                {
                    _context.ReservationServices.Add(new ReservationService
                    {
                        ReservationId = reservation.ReservationId,
                        ServiceTypeId = serviceId
                    });
                }
                await _context.SaveChangesAsync();
            }

            return await GetReservationByIdAsync(reservation.ReservationId);
        }

        public async Task<bool> CancelReservationAsync(int reservationId, int userId, string windowsUsername)
        {
            var reservation = await _context.Reservations
                .Include(r => r.Organizer)
                .FirstOrDefaultAsync(r => r.ReservationId == reservationId);

            if (reservation == null)
                return false;

            // VALIDACIÓN DOBLE: Usuario ID y Windows Username
            if (reservation.OrganizerId != userId || 
                !reservation.Organizer.WindowsUsername.Equals(windowsUsername, StringComparison.OrdinalIgnoreCase))
            {
                throw new UnauthorizedAccessException(
                    "Solo el organizador de la reserva puede cancelarla.");
            }

            reservation.IsCancelled = true;
            reservation.CancelledAt = DateTime.Now;
            reservation.CancelledBy = userId;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> HasConflictAsync(
            int roomId, 
            DateTime date, 
            TimeSpan startTime, 
            TimeSpan endTime, 
            int? excludeReservationId = null)
        {
            var conflicts = await _context.Reservations
                .Where(r => r.RoomId == roomId
                    && r.ReservationDate == date
                    && !r.IsCancelled
                    && (excludeReservationId == null || r.ReservationId != excludeReservationId)
                    && ((startTime >= r.StartTime && startTime < r.EndTime)
                        || (endTime > r.StartTime && endTime <= r.EndTime)
                        || (startTime <= r.StartTime && endTime >= r.EndTime)))
                .AnyAsync();

            return conflicts;
        }
    }
}
```

---

## 🔧 Configuración del Frontend

### 1. Crear archivo de configuración de API

**`/src/services/api.ts`**
```typescript
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const api = {
  // Rooms
  getRooms: async () => {
    const response = await fetch(`${API_BASE_URL}/rooms`);
    return response.json();
  },

  // Reservations
  getReservations: async (date?: string) => {
    const url = date 
      ? `${API_BASE_URL}/reservations?date=${date}` 
      : `${API_BASE_URL}/reservations`;
    const response = await fetch(url);
    return response.json();
  },

  createReservation: async (reservation: any) => {
    const response = await fetch(`${API_BASE_URL}/reservations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(reservation),
      credentials: 'include', // IMPORTANTE
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Error al crear reserva');
    }
    return response.json();
  },

  cancelReservation: async (id: number) => {
    const response = await fetch(`${API_BASE_URL}/reservations/${id}`, {
      method: 'DELETE',
      credentials: 'include', // IMPORTANTE
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Error al cancelar reserva');
    }
    return true;
  },

  // Users
  getUsers: async () => {
    const response = await fetch(`${API_BASE_URL}/users`);
    return response.json();
  },

  getCurrentUser: async () => {
    // En producción, esto vendría de la autenticación
    const response = await fetch(`${API_BASE_URL}/users/current`, {
      credentials: 'include', // IMPORTANTE: enviar credenciales de Windows
    });
    
    if (!response.ok) {
      throw new Error('No autenticado');
    }
    
    return response.json();
  }
};
```

### 2. Modificar App.tsx para usar la API real

```typescript
// Reemplazar los datos mockeados con llamadas a la API
useEffect(() => {
  const loadData = async () => {
    try {
      const [roomsData, reservationsData, usersData, currentUserData] = await Promise.all([
        api.getRooms(),
        api.getReservations(),
        api.getUsers(),
        api.getCurrentUser()
      ]);

      setRooms(roomsData);
      setReservations(reservationsData);
      setTeamMembers(usersData);
      setCurrentUser(currentUserData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Error al cargar los datos');
    }
  };

  loadData();
}, []);
```

---

## 🚀 Pasos para la Migración

### Paso 1: Instalar SQL Server Express
1. Descargar SQL Server Express desde [Microsoft](https://www.microsoft.com/es-es/sql-server/sql-server-downloads)
2. Instalar SQL Server Management Studio (SSMS)
3. Crear una nueva base de datos llamada `SisuGrpRoomReservations`

### Paso 2: Ejecutar Scripts SQL
1. Abrir SSMS y conectarse a tu instancia local
2. Crear las tablas en el orden especificado en este documento
3. Ejecutar los scripts de inserción de datos iniciales
4. Crear los stored procedures y funciones

### Paso 3: Crear Proyecto .NET
```bash
# Crear solución
dotnet new sln -n SisuGrp.RoomReservations

# Crear proyectos
dotnet new webapi -n SisuGrp.RoomReservations.API
dotnet new classlib -n SisuGrp.RoomReservations.Core
dotnet new classlib -n SisuGrp.RoomReservations.Data

# Agregar proyectos a la solución
dotnet sln add SisuGrp.RoomReservations.API
dotnet sln add SisuGrp.RoomReservations.Core
dotnet sln add SisuGrp.RoomReservations.Data

# Instalar paquetes NuGet
cd SisuGrp.RoomReservations.Data
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools

cd ../SisuGrp.RoomReservations.API
dotnet add package Microsoft.EntityFrameworkCore.Design
```

### Paso 4: Configurar Connection String
En `appsettings.json` del proyecto API:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=SisuGrpRoomReservations;Integrated Security=true;TrustServerCertificate=True;"
  },
  "Authentication": {
    "WindowsAuthentication": {
      "Enabled": true
    }
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

### Paso 5: Configurar CORS en .NET
```csharp
// Program.cs
builder.Services.AddCors(options =>
{
    options.AddPolicy("ReactApp",
        policy =>
        {
            policy.WithOrigins("http://localhost:5173") // Puerto de Vite
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});

// Después de var app = builder.Build();
app.UseCors("ReactApp");
```

### Paso 6: Modificar Frontend
1. Crear archivo `.env` en la raíz del proyecto React:
```
VITE_API_URL=http://localhost:5000/api
```

2. Instalar axios (opcional, pero recomendado):
```bash
npm install axios
```

3. Reemplazar los mock data con llamadas a la API

---

## 📝 Datos de Ejemplo para Poblar la Base de Datos

```sql
-- Insertar Equipos
INSERT INTO Teams (TeamName, Description) VALUES
('Desarrollo', 'Equipo de desarrollo de software'),
('Marketing', 'Equipo de marketing y comunicación'),
('Ventas', 'Equipo comercial y ventas'),
('Recursos Humanos', 'Gestión de talento humano'),
('TI', 'Tecnologías de la información'),
('Finanzas', 'Gestión financiera y contable'),
('Operaciones', 'Operaciones y logística'),
('Diseño', 'Diseño gráfico y UX/UI');

-- Insertar Usuarios (usar los mismos del mockdata)
INSERT INTO Users (FullName, Email, TeamId, WindowsUsername) VALUES
('María González', 'maria.gonzalez@sisugrp.com', 1, 'SISUGRB\mgonzalez'),
('Juan Pérez', 'juan.perez@sisugrp.com', 1, 'SISUGRB\jperez'),
('Ana Rodríguez', 'ana.rodriguez@sisugrp.com', 2, 'SISUGRB\arodriguez'),
-- ... más usuarios

-- Insertar Salas
INSERT INTO Rooms (RoomName, Location, Capacity, Floor) VALUES
('Sala de Juntas Piso 1', 'Piso 1', 10, 1),
('Sala de Juntas Piso 2', 'Piso 2', 10, 2),
('Sala de Juntas Piso 3', 'Piso 3 - Capacitación', 30, 3);

-- Insertar Amenities
DECLARE @Room1 INT = (SELECT RoomId FROM Rooms WHERE RoomName = 'Sala de Juntas Piso 1');
INSERT INTO RoomAmenities (RoomId, AmenityName) VALUES
(@Room1, 'Cafés'),
(@Room1, 'Aguas'),
(@Room1, 'Galletas'),
(@Room1, 'Refrescos'),
(@Room1, 'IdeaShare');

-- Repetir para las otras salas...

-- Establecer estados iniciales
INSERT INTO RoomCurrentStatus (RoomId, StatusId) VALUES
(1, 1), -- Disponible
(2, 1), -- Disponible
(3, 1); -- Disponible
```

---

## ✅ Checklist de Migración

- [ ] SQL Server Express instalado
- [ ] Base de datos creada
- [ ] Tablas creadas
- [ ] Stored procedures y funciones creadas
- [ ] Datos de ejemplo insertados
- [ ] Proyecto .NET creado
- [ ] Entity Framework configurado
- [ ] Controllers implementados
- [ ] Services implementados
- [ ] CORS configurado
- [ ] Frontend configurado para usar API
- [ ] Pruebas de integración realizadas

---

## 🔒 Consideraciones de Seguridad

1. **Autenticación**: Implementar Windows Authentication o JWT tokens
2. **Autorización**: Validar permisos en cada endpoint
3. **SQL Injection**: Usar siempre parámetros en las consultas
4. **CORS**: Configurar solo dominios permitidos
5. **HTTPS**: Usar certificados SSL en producción
6. **Validación**: Validar todos los inputs en backend

---

## 📚 Recursos Adicionales

- [Documentación Entity Framework Core](https://docs.microsoft.com/ef/core/)
- [ASP.NET Core Web API](https://docs.microsoft.com/aspnet/core/web-api/)
- [SQL Server Express](https://www.microsoft.com/sql-server/sql-server-downloads)
- [React + .NET Integration](https://docs.microsoft.com/aspnet/core/client-side/spa/react)

---

## 🆘 Soporte

Para preguntas o problemas durante la migración, contactar al equipo de desarrollo de SISU GRP.