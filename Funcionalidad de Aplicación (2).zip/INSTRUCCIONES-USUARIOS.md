# 👥 GUÍA PARA USUARIOS - SISU GRB

## 🚀 PRIMERA VEZ EN EL SISTEMA (SUPER FÁCIL)

### **Solo necesitas 2 cosas:**

1. **Tu nombre completo** (Ej: María González López)
2. **Tu email corporativo** (Ej: mgonzalez@sisugrb.com)

**¡Eso es todo! El sistema hace el resto automáticamente.**

---

## 📋 PASO A PASO - PRIMERA VEZ

### **1. Abre la aplicación**
```
https://sisu-grb.vercel.app
```

### **2. Verás esta pantalla:**
- Logo de SISU GRB
- Formulario con 2 campos

### **3. Llena los datos:**

**Nombre Completo:**
- Escribe: Tu nombre como aparece en tu correo
- Ejemplo: "María González López"

**Email Corporativo:**
- Escribe: Tu correo de SISU GRB
- Ejemplo: "mgonzalez@sisugrb.com"

### **4. Click en "Ingresar al Sistema"**

### **5. ¡Listo! ✅**
- Tu usuario se crea automáticamente
- Entras directo al sistema
- Ya puedes reservar salas

---

## 🔄 SEGUNDA VEZ Y SIEMPRE

### **Es AUTOMÁTICO:**

1. Abres la app
2. **Login automático** (te reconoce)
3. Entras directo

**NO tienes que ingresar nada de nuevo**

---

## ❓ PREGUNTAS FRECUENTES

### **P: ¿Y mi usuario de Windows?**
**R:** No necesitas saberlo. El sistema lo genera automáticamente desde tu email.

**Ejemplo:**
- Tu email: `jperez@sisugrb.com`
- Tu usuario generado: `azuread\jperez`

### **P: ¿Qué pasa si no tengo email corporativo?**
**R:** Habla con TI para que te lo asignen. Todos los empleados de SISU GRB tienen email corporativo.

### **P: ¿Puedo usar mi email personal?**
**R:** No es recomendable. Usa tu email corporativo (@sisugrb.com) para que el sistema funcione correctamente.

### **P: ¿A qué equipo me asignan?**
**R:** Por defecto a "Operaciones". Un administrador puede cambiar tu equipo después si es necesario.

### **P: ¿Tengo que registrarme cada vez?**
**R:** NO. Solo la primera vez. Después es automático.

---

## 📱 USAR DESDE CELULAR

### **Es exactamente igual:**

1. Abre el navegador (Chrome, Safari)
2. Ve a: `https://sisu-grb.vercel.app`
3. Primera vez: Ingresa nombre y email
4. Siguientes veces: Login automático

### **TIP: Crear acceso directo**

**En iPhone:**
1. Safari → Menú → "Agregar a pantalla de inicio"
2. Ahora tienes un ícono como app

**En Android:**
1. Chrome → Menú → "Agregar a pantalla de inicio"
2. Ahora tienes un ícono como app

---

## 🏢 CÓMO RESERVAR UNA SALA

### **Paso 1: Ver disponibilidad**
- En el dashboard verás las 3 salas:
  - 🟢 Verde = Libre
  - 🔴 Rojo = Ocupado
  - 🔵 Azul = Mantenimiento

### **Paso 2: Seleccionar fecha**
- Usa el calendario
- Solo días de semana (lunes a viernes)

### **Paso 3: Reservar**
1. Click en la sala que quieres
2. Click en "Reservar"
3. Llena:
   - Hora de inicio (Ej: 10:00 AM)
   - Hora de fin (Ej: 11:00 AM)
   - Motivo (Ej: "Reunión con cliente")
4. Click "Crear Reserva"
5. ¡Listo! ✅

### **Paso 4: Ver tu reserva**
- Ve a "Mis Reservas"
- Ahí están todas tus reservas

---

## ❌ CANCELAR UNA RESERVA

### **Solo puedes cancelar TUS propias reservas:**

1. Ve a "Mis Reservas"
2. Encuentra la reserva que quieres cancelar
3. Click en "Cancelar"
4. Confirma
5. ¡Listo! La sala queda libre

**Importante:**
- ❌ NO puedes cancelar reservas de otros
- ✅ Solo cancelas las tuyas

---

## 🔍 VER QUIÉN RESERVÓ

### **En el dashboard:**
- Si una sala está ocupada (rojo)
- Verás el nombre de quien la reservó
- Y el horario

**Ejemplo:**
```
Sala Piso 2 - OCUPADO
Reservado por: Juan Pérez
Horario: 2:00 PM - 3:00 PM
Motivo: Reunión de ventas
```

---

## 💡 TIPS Y CONSEJOS

### **✅ Buenas prácticas:**

1. **Reserva con anticipación**
   - No esperes al último minuto
   - Reserva 1 día antes mínimo

2. **Sé específico en el motivo**
   - Mal: "Reunión"
   - Bien: "Reunión con cliente XYZ - Presentación de propuesta"

3. **Cancela si no vas a usar**
   - Libera la sala para otros
   - Hazlo con anticipación

4. **Respeta el horario**
   - Si reservaste 1 hora, usa 1 hora
   - No te pases del tiempo

5. **Deja la sala limpia**
   - Recoge tus cosas
   - Apaga equipos

### **❌ Evita:**

1. **Reservar "por si acaso"**
   - No reserves si no estás seguro
   - Bloqueas la sala para otros

2. **Reservas duplicadas**
   - No reserves la misma sala varias veces

3. **Cancelar a última hora**
   - Avisa con tiempo si cancelas

---

## 🆘 PROBLEMAS COMUNES

### **Problema: "Ya existe una reserva en ese horario"**
**Solución:**
- Alguien más reservó primero
- Selecciona otro horario u otra sala

### **Problema: "No puedo cancelar una reserva"**
**Solución:**
- Solo puedes cancelar TUS reservas
- ¿Es tu reserva? Verifica que hayas iniciado sesión con tu usuario

### **Problema: "La sala está en mantenimiento"**
**Solución:**
- José Luis (Mantenimiento) la puso en mantenimiento
- No se puede reservar hasta que la libere
- Selecciona otra sala

### **Problema: "No me deja reservar fin de semana"**
**Solución:**
- Las salas solo están disponibles lunes a viernes
- Horario: 8:30 AM - 6:00 PM

### **Problema: "Olvidé mi contraseña"**
**Solución:**
- No hay contraseñas en este sistema
- Solo usas tu nombre y email la primera vez
- Después es automático

---

## 📞 SOPORTE

### **¿Necesitas ayuda?**

**Opción 1: Pregunta a TI**
- Contacta al equipo de Tecnología
- Ellos conocen el sistema

**Opción 2: Pregunta a un compañero**
- El sistema es muy simple
- Cualquiera puede ayudarte

**Opción 3: Revisa este documento**
- Aquí están todas las respuestas

---

## 🎉 RESUMEN

### **Primera Vez:**
1. Abre la app
2. Ingresa: Nombre + Email
3. Click "Ingresar"
4. ¡Ya estás dentro!

### **Siempre:**
1. Abre la app
2. Login automático
3. Reserva salas
4. ¡Listo!

---

## 📱 COMPARTE CON TU EQUIPO

**Envía este mensaje:**

---

Hola equipo,

Ya está disponible el nuevo **Sistema de Reservas de Salas** de SISU GRB.

**URL:** https://sisu-grb.vercel.app

**Primera vez:**
1. Ingresa tu nombre completo
2. Ingresa tu email corporativo (@sisugrb.com)
3. Click "Ingresar al Sistema"

**Siguiente veces:**
- Login automático

**¿Preguntas?**
Lee la guía completa o pregunta a TI.

Saludos,
[Tu nombre]

---

¡Disfruta el sistema! 🚀
