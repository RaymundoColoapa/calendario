# ✅ Checklist de Despliegue - Sistema SISU GRB

## 📋 Estado del Despliegue

**Fecha de inicio:** _______________  
**Responsable:** _______________  
**Versión:** v1.0

---

## 🎯 PRE-REQUISITOS

### Software Necesario

- [ ] **Node.js** instalado (v18 o superior)
  ```bash
  node --version  # Debe mostrar v18.x.x o superior
  npm --version
  ```

- [ ] **Git** instalado
  ```bash
  git --version
  ```

- [ ] **Supabase CLI** instalado
  ```bash
  npm install -g supabase
  supabase --version
  ```

### Cuentas y Accesos

- [ ] **Cuenta de Supabase** creada y activa
- [ ] **Acceso al proyecto** Supabase: `daowqmfdusubyicuuowy`
- [ ] **Cuenta de Vercel/Netlify** (para frontend)
- [ ] **Repositorio Git** configurado (opcional)

### Información Requerida

- [ ] **Service Role Key** obtenida de Supabase Dashboard
- [ ] **Database URL** obtenida de Supabase Dashboard
- [ ] **Anon Key** confirmada (ya está en el código)

**Dónde encontrar:**
- Service Role Key: Dashboard → Settings → API → `service_role` (secret)
- Database URL: Dashboard → Settings → Database → Connection String → URI

---

## 🔧 FASE 1: DESPLIEGUE DEL BACKEND

### Paso 1.1: Login en Supabase

- [ ] Ejecutar: `supabase login`
- [ ] Navegador abrió para autenticación
- [ ] Autenticación exitosa
- [ ] Terminal muestra confirmación

**Comando:**
```bash
supabase login
```

### Paso 1.2: Vincular Proyecto

- [ ] Ejecutar comando de vinculación
- [ ] Ingresar password de base de datos (si se solicita)
- [ ] Vinculación exitosa

**Comando:**
```bash
supabase link --project-ref daowqmfdusubyicuuowy
```

### Paso 1.3: Configurar Secrets

- [ ] SUPABASE_URL configurado
  ```bash
  supabase secrets set SUPABASE_URL="https://daowqmfdusubyicuuowy.supabase.co"
  ```

- [ ] SUPABASE_ANON_KEY configurado
  ```bash
  supabase secrets set SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRhb3dxbWZkdXN1YnlpY3V1b3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg3MTM5OTMsImV4cCI6MjA1NDI4OTk5M30.oGsN88CQKfGTKWPzCemCRWgvuPSukNRZe_K31YSy7_c"
  ```

- [ ] SUPABASE_SERVICE_ROLE_KEY configurado
  ```bash
  supabase secrets set SUPABASE_SERVICE_ROLE_KEY="TU_SERVICE_ROLE_KEY"
  ```

- [ ] SUPABASE_DB_URL configurado
  ```bash
  supabase secrets set SUPABASE_DB_URL="TU_DATABASE_URL"
  ```

### Paso 1.4: Desplegar Edge Function

- [ ] Ejecutar comando de despliegue
- [ ] Esperar 1-2 minutos
- [ ] Despliegue completado sin errores
- [ ] Función aparece en Dashboard de Supabase

**Comando:**
```bash
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

### Paso 1.5: Verificar Backend

- [ ] Health check responde OK
  - URL: `https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/health`
  - Respuesta esperada: `{"status":"ok","message":"SISU GRB API funcionando"}`

- [ ] Endpoint de salas responde
  - URL: `https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/api/rooms`
  - Debe mostrar 3 salas

- [ ] Endpoint de usuarios responde
  - URL: `https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/api/users`
  - Debe mostrar usuarios iniciales

- [ ] Sin errores en los logs
  ```bash
  supabase functions logs make-server-f5c6167b
  ```

**Script automático de verificación:**
```bash
# En Windows:
verificar-despliegue.bat
```

---

## 🌐 FASE 2: DESPLIEGUE DEL FRONTEND

### Opción A: Vercel (Recomendado)

#### Paso 2A.1: Preparar Repositorio

- [ ] Código en repositorio Git (GitHub, GitLab, Bitbucket)
- [ ] Todos los cambios committed
- [ ] Push al repositorio remoto

#### Paso 2A.2: Configurar Vercel

- [ ] Ir a [vercel.com](https://vercel.com)
- [ ] Click en "New Project"
- [ ] Importar repositorio
- [ ] Verificar configuración:
  - Build Command: `npm run build`
  - Output Directory: `dist`
  - Install Command: `npm install`
- [ ] Click en "Deploy"

#### Paso 2A.3: Verificar Despliegue

- [ ] Despliegue completado (2-3 minutos)
- [ ] URL asignada (ej: `https://sisugrb.vercel.app`)
- [ ] Aplicación carga sin errores
- [ ] Conexión a backend funciona (ícono WiFi verde)

**URL del frontend:** _______________________________________________

---

### Opción B: Netlify

#### Paso 2B.1: Build Local

- [ ] Ejecutar: `npm run build`
- [ ] Carpeta `dist` creada exitosamente
- [ ] Sin errores en el build

#### Paso 2B.2: Desplegar en Netlify

- [ ] Ir a [netlify.com](https://netlify.com)
- [ ] Opción 1: Arrastrar carpeta `dist`
  - [ ] Carpeta subida
  - [ ] Despliegue completado
  
- [ ] Opción 2: Conectar repositorio Git
  - [ ] Repositorio conectado
  - [ ] Build configurado
  - [ ] Despliegue automático

#### Paso 2B.3: Verificar Despliegue

- [ ] URL asignada (ej: `https://sisugrb.netlify.app`)
- [ ] Aplicación carga sin errores
- [ ] Conexión a backend funciona

**URL del frontend:** _______________________________________________

---

### Opción C: Servidor Propio

#### Paso 2C.1: Build

- [ ] Ejecutar: `npm run build`
- [ ] Carpeta `dist` creada
- [ ] Copiar contenido de `dist` al servidor

#### Paso 2C.2: Configurar Servidor

- [ ] Servidor web instalado (IIS, Apache, Nginx)
- [ ] Carpeta configurada como sitio web
- [ ] Redireccionamiento a `index.html` configurado

#### Paso 2C.3: Verificar

- [ ] URL accesible
- [ ] Aplicación carga
- [ ] Conexión a backend funciona

**URL del frontend:** _______________________________________________

---

## ✅ FASE 3: VERIFICACIÓN FUNCIONAL

### Pruebas Básicas

- [ ] **Cargar la aplicación**
  - Abrir URL del frontend
  - Sin errores en consola (F12)
  - UI se muestra correctamente

- [ ] **Indicador de conexión**
  - Ícono WiFi visible en esquina superior derecha
  - Color verde (conectado)
  - Si es rojo, revisar backend

- [ ] **Login/Auto-login**
  - Formulario de login aparece
  - Ingresar nombre y email
  - Usuario se crea automáticamente
  - Nombre aparece en header

- [ ] **Ver salas**
  - 3 salas se muestran:
    - Sala Piso 1 (10 personas)
    - Sala Piso 2 (10 personas)
    - Sala Piso 3 - Capacitación (30 personas)
  - Todas en estado "Libre"

### Pruebas de Funcionalidad

- [ ] **Crear reserva**
  - Click en una sala
  - Seleccionar fecha (hoy o mañana)
  - Seleccionar horario (dentro de 8:30 AM - 6:00 PM)
  - Ingresar propósito
  - Click en "Reservar"
  - Confirmación de creación exitosa
  - Sala muestra estado "Ocupado" en el horario reservado

- [ ] **Ver "Mis Reservas"**
  - Click en ícono de calendario (header)
  - Se muestra la reserva creada
  - Información correcta:
    - Sala
    - Fecha y horario
    - Propósito

- [ ] **Cancelar reserva**
  - En "Mis Reservas", click en "Cancelar"
  - Confirmar cancelación
  - Reserva desaparece de la lista
  - Sala vuelve a estado "Libre"

### Pruebas de Validación

- [ ] **Validación de horarios**
  - Intentar crear reserva fuera de horario (antes 8:30 AM o después 6:00 PM)
  - Debe mostrar error

- [ ] **Validación de conflictos**
  - Crear una reserva
  - Intentar crear otra en el mismo horario
  - Debe mostrar error de conflicto

- [ ] **Validación de días**
  - Intentar reservar en fin de semana
  - Debe mostrar error o no permitir

### Pruebas de Permisos

- [ ] **Cancelación de reservas propias**
  - Solo puedes cancelar tus propias reservas
  - No puedes cancelar reservas de otros

- [ ] **Mantenimiento (usuarios autorizados)**
  - Login como José Luis Pimienta (si aplica)
  - Panel de mantenimiento visible
  - Puede cambiar estado de salas

### Pruebas Responsivas

- [ ] **Desktop/Laptop**
  - Layout correcto en pantalla grande
  - Todos los elementos visibles
  - Navegación fluida

- [ ] **Tablet**
  - Diseño adaptado
  - Elementos accesibles
  - Funcionalidad completa

- [ ] **Móvil (Smartphone)**
  - Abrir en celular
  - UI responsive
  - Crear reserva funciona
  - Cancelar reserva funciona

### Pruebas de Rendimiento

- [ ] **Tiempo de carga inicial**
  - Aplicación carga en < 3 segundos

- [ ] **Tiempo de respuesta**
  - Operaciones completadas en < 1 segundo
  - Sin lag notable

- [ ] **Usuarios simultáneos**
  - Abrir en múltiples navegadores/dispositivos
  - Sistema responde correctamente

---

## 🔒 FASE 4: SEGURIDAD Y CONFIGURACIÓN DE PRODUCCIÓN

### Seguridad Básica

- [ ] **Cambiar clave de admin**
  - Editar `/supabase/functions/server/index.tsx`
  - Cambiar `sisugrb-admin-2026` por clave segura
  - Re-desplegar backend

- [ ] **Verificar Service Role Key**
  - NO está expuesta en frontend
  - Solo en backend (Supabase Secrets)

- [ ] **CORS configurado**
  - Solo dominios autorizados (producción)
  - O `*` si es necesario (desarrollo)

### Configuración Avanzada (Opcional)

- [ ] **Habilitar RLS en Supabase**
  - Row Level Security en tabla `kv_store_f5c6167b`
  - Políticas de acceso configuradas

- [ ] **Configurar dominio personalizado**
  - En Vercel/Netlify
  - DNS configurado
  - SSL/HTTPS habilitado

- [ ] **Configurar Azure AD** (Auto-login empresarial)
  - Integración con Windows
  - Auto-login sin formulario

---

## 📊 FASE 5: MONITOREO Y MANTENIMIENTO

### Configurar Monitoreo

- [ ] **Logs del backend**
  - Acceso a logs en Supabase Dashboard
  - Comando para logs en tiempo real:
    ```bash
    supabase functions logs make-server-f5c6167b --follow
    ```

- [ ] **Alertas configuradas**
  - Notificaciones de errores (Supabase Dashboard)
  - Monitoreo de uptime

### Backups y Recuperación

- [ ] **Backup de base de datos**
  - Configurado en Supabase (automático)
  - Verificar política de backups

- [ ] **Plan de recuperación**
  - Documentado cómo restaurar
  - Contactos de emergencia definidos

### Documentación

- [ ] **URLs documentadas**
  - Frontend: _______________________________________________
  - Backend: `https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b`
  - Dashboard: `https://supabase.com/dashboard/project/daowqmfdusubyicuuowy`

- [ ] **Credenciales guardadas**
  - En gestor de contraseñas seguro
  - Compartidas con equipo autorizado

- [ ] **Guías compartidas con el equipo**
  - Manual de usuario
  - Contacto de soporte técnico

---

## 📞 FASE 6: LANZAMIENTO

### Pre-lanzamiento

- [ ] **Capacitación del equipo**
  - Demostración del sistema
  - Preguntas respondidas
  - Guía de usuario compartida

- [ ] **Prueba piloto**
  - 5-10 usuarios iniciales
  - Feedback recopilado
  - Ajustes realizados

### Lanzamiento

- [ ] **Anuncio al equipo**
  - Email enviado con:
    - URL de la aplicación
    - Instrucciones básicas
    - Contacto de soporte

- [ ] **Monitoreo activo**
  - Primera semana: revisar logs diariamente
  - Atender problemas rápidamente

- [ ] **Feedback inicial**
  - Encuesta de satisfacción
  - Mejoras identificadas

---

## 🎯 CHECKLIST FINAL

### Verificación Completa

**Backend:**
- [ ] Desplegado en Supabase
- [ ] Health check OK
- [ ] Todos los endpoints funcionan
- [ ] Logs sin errores críticos

**Frontend:**
- [ ] Desplegado (Vercel/Netlify/Servidor)
- [ ] URL accesible públicamente
- [ ] Conexión a backend exitosa
- [ ] UI funciona correctamente

**Funcionalidad:**
- [ ] Login funciona
- [ ] Ver salas funciona
- [ ] Crear reservas funciona
- [ ] Ver reservas funciona
- [ ] Cancelar reservas funciona
- [ ] Panel de mantenimiento funciona (usuarios autorizados)

**Calidad:**
- [ ] Sin errores en consola
- [ ] Responsive (desktop, tablet, móvil)
- [ ] Rendimiento aceptable (< 3s carga)
- [ ] 50 usuarios simultáneos soportados

**Seguridad:**
- [ ] Clave de admin cambiada
- [ ] Service Role Key no expuesta
- [ ] CORS configurado
- [ ] RLS habilitado (opcional)

**Documentación:**
- [ ] URLs documentadas
- [ ] Credenciales guardadas
- [ ] Equipo capacitado
- [ ] Plan de mantenimiento definido

---

## ✅ FIRMA DE APROBACIÓN

**Sistema probado y listo para producción:**

| Rol | Nombre | Firma | Fecha |
|-----|--------|-------|-------|
| Desarrollador | _____________ | _____________ | ____/____/____ |
| QA/Tester | _____________ | _____________ | ____/____/____ |
| Project Manager | _____________ | _____________ | ____/____/____ |
| Usuario Final | _____________ | _____________ | ____/____/____ |

---

## 📝 NOTAS ADICIONALES

**Problemas encontrados durante el despliegue:**

_____________________________________________________________________________

_____________________________________________________________________________

_____________________________________________________________________________

**Mejoras sugeridas para futuro:**

_____________________________________________________________________________

_____________________________________________________________________________

_____________________________________________________________________________

**Observaciones:**

_____________________________________________________________________________

_____________________________________________________________________________

_____________________________________________________________________________

---

## 🎉 ¡DESPLIEGUE COMPLETADO!

**Fecha de finalización:** ____/____/____

**Tiempo total de despliegue:** __________ minutos

**Estado:** 
- [ ] ✅ Exitoso - En producción
- [ ] ⚠️ Con observaciones menores
- [ ] ❌ Requiere correcciones

---

**Sistema SISU GRB v1.0**  
*Gestión de Salas de Juntas*  
*Desarrollado para 50+ usuarios simultáneos*

📚 **Documentación completa:** `GUIA-DESPLIEGUE-COMPLETA.md`  
⚡ **Inicio rápido:** `INICIO-RAPIDO-DESPLIEGUE.md`  
🔧 **Soporte:** Ver logs y troubleshooting en documentación
