# 🚀 INSTRUCCIONES DE DEPLOYMENT - SISU GRB

## ✅ ¡APLICACIÓN LISTA PARA PRODUCCIÓN!

Tu aplicación ahora está conectada con **Supabase** y funcionará en **celular, laptop, tablet** y cualquier dispositivo con navegador.

---

## 📱 ¿CÓMO ACCEDER A LA APLICACIÓN?

### **URL de la Aplicación:**
```
https://make.figma.com/[tu-proyecto]
```

**IMPORTANTE:** Esta URL de Figma Make es temporal. Para tenerla en producción, sigue las instrucciones de abajo.

---

## 🌐 DEPLOYMENT EN VERCEL (GRATIS)

### **Paso 1: Crear cuenta en Vercel**
1. Ve a: https://vercel.com
2. Click en "Sign Up"
3. Regístrate con tu correo o GitHub

### **Paso 2: Descargar el código**
1. En Figma Make, click en el botón de **"Export"** (arriba derecha)
2. Descarga el archivo ZIP
3. Descomprime el ZIP en tu computadora

### **Paso 3: Subir a Vercel**
1. En Vercel, click en **"Add New"** → **"Project"**
2. Arrastra la carpeta descomprimida o selecciona desde GitHub
3. Vercel detectará automáticamente que es un proyecto React
4. Click en **"Deploy"**
5. Espera 2-3 minutos

### **Paso 4: Obtener tu URL**
- Después del deploy, Vercel te dará una URL como:
  ```
  https://sisu-grb.vercel.app
  ```
- Esta URL es **permanente** y **gratuita**
- Puedes cambiar el nombre del proyecto en Settings

---

## 📲 COMPARTIR CON TU EQUIPO (50 USUARIOS)

### **Opción 1: Compartir URL directamente**
1. Envía la URL por correo o WhatsApp
2. Cada persona abre en su navegador (celular o laptop)
3. Selecciona su usuario y listo

### **Opción 2: Crear acceso directo en celulares**

**En iPhone:**
1. Abre la URL en Safari
2. Toca el icono de "Compartir" (cuadro con flecha)
3. Selecciona "Agregar a pantalla de inicio"
4. Ahora aparece como una app

**En Android:**
1. Abre la URL en Chrome
2. Toca los 3 puntos (menú)
3. Selecciona "Agregar a pantalla de inicio"
4. Ahora aparece como una app

---

## 🔧 FUNCIONALIDADES ACTIVAS

### ✅ **Ya funcionan:**
- ✅ Login con 4 usuarios (Raymundo, Mario, Margarita, José Luis)
- ✅ 3 salas (Piso 1, Piso 2, Piso 3)
- ✅ Reservar salas con horario
- ✅ Ver reservas de todos
- ✅ Cancelar solo tus propias reservas
- ✅ José Luis puede poner salas en mantenimiento
- ✅ Sincronización automática entre dispositivos
- ✅ Funciona en celular y laptop
- ✅ Indicador de conexión (WiFi verde)

### ⚡ **Sincronización en Tiempo Real:**
- Si Pedro reserva en laptop → Ana lo ve en celular INMEDIATAMENTE
- Si Ana cancela en celular → Todos lo ven INMEDIATAMENTE
- No necesitan recargar la página

---

## 🎯 USO DIARIO

### **Para Usuarios Normales:**
1. Abre la URL en tu dispositivo
2. Selecciona tu nombre
3. Ve las salas disponibles
4. Haz click en "Reservar"
5. Selecciona horario y motivo
6. ¡Listo!

### **Para Cancelar una Reserva:**
1. Ve a "Mis Reservas"
2. Click en "Cancelar" en tu reserva
3. Solo puedes cancelar TUS propias reservas

### **Para José Luis (Mantenimiento):**
1. Login como José Luis Pimienta
2. Ve al panel de "Gestión de Mantenimiento"
3. Activa/desactiva mantenimiento en cualquier sala
4. Todos los usuarios verán "En Mantenimiento"

---

## 📊 CAPACIDAD Y ESCALABILIDAD

### **Plan Actual (GRATIS):**
- ✅ **50+ usuarios** simultáneos
- ✅ **500 MB** de base de datos
- ✅ **10,000 reservas/mes**
- ✅ **Sincronización** en tiempo real
- ✅ **Backups** automáticos

### **Si necesitas más (futuro):**
- 100+ usuarios: Sigue siendo GRATIS
- 500+ usuarios: $25 USD/mes

---

## 🔒 SEGURIDAD

### ✅ **Implementado:**
- 🔐 Conexión HTTPS (encriptada)
- 🔐 Solo el dueño cancela sus reservas
- 🔐 José Luis es el único con acceso a mantenimiento
- 🔐 Base de datos segura en Supabase
- 🔐 Backups diarios automáticos

---

## 🛠️ SOPORTE Y MANTENIMIENTO

### **Base de Datos:**
- Los datos están en Supabase (en la nube)
- Se respaldan automáticamente cada día
- No se pierden aunque cierres el navegador

### **Agregar Más Usuarios:**
1. Ve al código
2. Abre `/supabase/functions/server/index.tsx`
3. Agrega el nuevo usuario en `INITIAL_USERS`
4. Sube el cambio a Vercel

### **Agregar Más Salas:**
1. Ve al código
2. Abre `/supabase/functions/server/index.tsx`
3. Agrega la nueva sala en `INITIAL_ROOMS`
4. Sube el cambio a Vercel

---

## 📞 TROUBLESHOOTING

### **Problema: "No se puede conectar con el servidor"**
**Solución:**
- Verifica tu conexión a internet
- Verifica que Supabase esté funcionando
- El icono WiFi rojo indica sin conexión

### **Problema: "No veo las reservas de otros"**
**Solución:**
- Espera 5 segundos, se sincronizan automáticamente
- Recarga la página (F5)
- Verifica el icono WiFi (debe estar verde)

### **Problema: "No puedo cancelar una reserva"**
**Solución:**
- Solo puedes cancelar TUS propias reservas
- Verifica que estés logueado con el usuario correcto

---

## 🎉 ¡LISTO PARA USAR!

### **Próximos Pasos:**
1. ✅ Deploy en Vercel (5 minutos)
2. ✅ Comparte la URL con tu equipo
3. ✅ Cada persona hace un acceso directo en su celular
4. ✅ ¡A reservar salas!

---

## 📧 CONTACTO

**Sistema desarrollado para:** SISU Global Reinsurance Broker  
**Funcionalidad:** Gestión de Salas de Juntas  
**Capacidad:** 50+ usuarios simultáneos  
**Costo:** GRATIS (con Supabase + Vercel)  

---

## 🔗 LINKS IMPORTANTES

- **Vercel:** https://vercel.com
- **Supabase:** https://supabase.com
- **Panel de Control Supabase:** https://app.supabase.com

---

¡Disfruta tu aplicación! 🚀
