# 🏠 Guía: Instalar Sistema Completo en Local

## Sistema de Reservas de Salas SISU GRB - Instalación Local

Esta guía te ayudará a instalar TODO el sistema en tu computadora local, conectando tu diseño de Figma Make con SQL Server Express.

---

## 📋 Requisitos Previos

### Software Necesario:

1. **Node.js 18+** 
   - Descargar: https://nodejs.org/
   - Verificar: `node --version` en terminal

2. **SQL Server Express** (Gratuito)
   - Descargar: https://www.microsoft.com/es-es/sql-server/sql-server-downloads
   - Elegir: **Express Edition**

3. **SQL Server Management Studio** (SSMS)
   - Descargar: https://aka.ms/ssmsfullsetup

4. **Visual Studio 2022 Community** (Gratuito)
   - Descargar: https://visualstudio.microsoft.com/es/downloads/
   - Durante instalación, seleccionar: **"ASP.NET and web development"**

5. **Git** (Opcional pero recomendado)
   - Descargar: https://git-scm.com/downloads

---

## 🗂️ Estructura del Proyecto Local

Crea esta estructura de carpetas en tu PC:

```
C:\SisuGRB\
├── frontend\              ← Código React (Figma Make)
│   ├── src\
│   ├── public\
│   ├── package.json
│   └── ...
│
└── backend\               ← Backend .NET
    ├── SisuGrb.RoomReservations.API\
    ├── SisuGrb.RoomReservations.Core\
    └── SisuGrb.RoomReservations.Data\
```

---

## 🎨 PARTE 1: Descargar Frontend (Figma Make)

### Opción A: Descargar Todo el Código desde Figma Make

1. En Figma Make, busca la opción de **exportar** o **descargar** el proyecto
2. Guárdalo en: `C:\SisuGRB\frontend\`

### Opción B: Copiar Archivos Manualmente

Si no hay opción de descarga, copia todos estos archivos desde Figma Make:

#### Crear carpeta frontend:
```powershell
# Abre PowerShell
mkdir C:\SisuGRB\frontend
cd C:\SisuGRB\frontend
```

#### Inicializar proyecto Node.js:
```bash
npm init -y
```

#### Instalar Vite y React:
```bash
npm create vite@latest . -- --template react-ts
npm install
```

#### Copiar archivos desde Figma Make:

Necesitas copiar manualmente (o descargar) estos archivos:

```
frontend/
├── src/
│   ├── app/
│   │   ├── components/      ← Todos tus componentes
│   │   ├── data/            ← mock-data.ts
│   │   ├── types/           ← types.ts
│   │   ├── services/        ← AQUÍ crearemos api.ts
│   │   └── App.tsx
│   ├── styles/
│   │   ├── theme.css
│   │   └── fonts.css
│   ├── imports/             ← Logo SISU GRB
│   └── main.tsx
├── public/
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 🗄️ PARTE 2: Instalar SQL Server Express

### 2.1 Instalar SQL Server Express

1. Ejecutar el instalador descargado
2. Elegir: **Basic** o **Custom**
3. Aceptar términos
4. Ruta de instalación: dejar por defecto
5. **Anotar el nombre de la instancia:** `localhost\SQLEXPRESS`
6. Esperar a que termine (5-10 minutos)

✅ **Confirmación:** Deberías ver "Installation completed successfully"

### 2.2 Instalar SQL Server Management Studio (SSMS)

1. Ejecutar instalador de SSMS
2. Instalar con opciones por defecto
3. Reiniciar PC si lo solicita

### 2.3 Crear la Base de Datos

1. Abrir **SQL Server Management Studio (SSMS)**
2. Conectarse:
   - **Server name:** `localhost\SQLEXPRESS`
   - **Authentication:** Windows Authentication
   - Click **Connect**

3. Copiar el contenido de `/backend-dotnet/SQL/01-create-database.sql`
4. En SSMS: **File → New → Query**
5. Pegar el script SQL
6. Presionar **F5** o click en **Execute**

✅ **Confirmación:** Deberías ver:
```
Base de datos SisuGrbRoomReservations creada exitosamente.
Todas las tablas creadas exitosamente.
✅ ¡Base de datos creada exitosamente!
```

### 2.4 Verificar que tu Usuario Windows esté en la BD

```sql
-- Ejecuta esto en SSMS para ver tu usuario Windows:
SELECT SYSTEM_USER;

-- Luego verifica si estás en la tabla Users:
SELECT * FROM Users WHERE WindowsUsername LIKE '%' + SYSTEM_USER + '%';
```

❌ **Si NO apareces:** Necesitas agregarte manualmente:

```sql
-- Reemplaza con tu información:
INSERT INTO Users (FullName, Email, WindowsUsername, TeamId) 
VALUES ('TU NOMBRE', 'tu.email@sisugrb.com', 'SISUGRB\tu_usuario', 1);
```

**Nota:** Para obtener tu WindowsUsername exacto:
```sql
SELECT SYSTEM_USER;  -- Ejemplo: SISUGRB\jperez
```

---

## ⚙️ PARTE 3: Crear Backend .NET

### 3.1 Crear Proyecto en Visual Studio

1. Abrir **Visual Studio 2022**
2. Click en **Create a new project**
3. Buscar: **ASP.NET Core Web API**
4. Click **Next**
5. Configurar:
   - **Project name:** `SisuGrb.RoomReservations.API`
   - **Location:** `C:\SisuGRB\backend\`
   - Click **Next**
6. Framework: **.NET 8.0**
7. Authentication: **None** (lo configuraremos manualmente)
8. ✅ **Enable OpenAPI support** (Swagger)
9. Click **Create**

### 3.2 Agregar Class Libraries

1. En Visual Studio, click derecho en la **Solution**
2. **Add → New Project**
3. Elegir: **Class Library**
4. Nombre: `SisuGrb.RoomReservations.Core`
5. Framework: **.NET 8.0**
6. Click **Create**

Repetir para crear:
- `SisuGrb.RoomReservations.Data`

### 3.3 Agregar Referencias entre Proyectos

1. Click derecho en `SisuGrb.RoomReservations.API`
2. **Add → Project Reference**
3. Marcar: `Core` y `Data`
4. Click **OK**

Repetir para `SisuGrb.RoomReservations.Core`:
1. Click derecho → **Add → Project Reference**
2. Marcar: `Data`

### 3.4 Instalar Paquetes NuGet

**En el proyecto API:**
1. Click derecho en `SisuGrb.RoomReservations.API`
2. **Manage NuGet Packages**
3. Buscar e instalar:
   - `Microsoft.EntityFrameworkCore.SqlServer`
   - `Microsoft.EntityFrameworkCore.Tools`
   - `Microsoft.AspNetCore.Authentication.Negotiate`

**En el proyecto Data:**
1. Click derecho en `SisuGrb.RoomReservations.Data`
2. **Manage NuGet Packages**
3. Buscar e instalar:
   - `Microsoft.EntityFrameworkCore.SqlServer`
   - `Microsoft.EntityFrameworkCore.Tools`

### 3.5 Copiar Archivos del Backend

Desde tu proyecto actual de Figma Make, copia los archivos de `/backend-dotnet/`:

| Copiar desde | Pegar en |
|--------------|----------|
| `/backend-dotnet/Models/*.cs` | `SisuGrb.RoomReservations.Core/Models/` |
| `/backend-dotnet/Data/AppDbContext.cs` | `SisuGrb.RoomReservations.Data/` |
| `/backend-dotnet/Controllers/*.cs` | `SisuGrb.RoomReservations.API/Controllers/` |
| `/backend-dotnet/Program.cs` | `SisuGrb.RoomReservations.API/Program.cs` (reemplazar) |
| `/backend-dotnet/appsettings.json` | `SisuGrb.RoomReservations.API/appsettings.json` (reemplazar) |

### 3.6 Configurar launchSettings.json

En `SisuGrb.RoomReservations.API/Properties/launchSettings.json`, reemplaza con:

```json
{
  "profiles": {
    "SisuGrb.RoomReservations.API": {
      "commandName": "Project",
      "launchBrowser": true,
      "launchUrl": "swagger",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      },
      "applicationUrl": "http://localhost:5000",
      "windowsAuthentication": true,
      "anonymousAuthentication": false
    }
  }
}
```

### 3.7 Probar el Backend

1. En Visual Studio, presiona **F5**
2. Se abrirá el navegador en: `http://localhost:5000/swagger`
3. Prueba el endpoint: `GET /api/users/current`
4. Click **Try it out → Execute**

✅ **Debe mostrar tu información de usuario Windows**

---

## 🔗 PARTE 4: Conectar Frontend con Backend

### 4.1 Crear Servicio API en React

En tu proyecto frontend, crea: `src/app/services/api.ts`

```typescript
const API_BASE_URL = 'http://localhost:5000/api';

export const api = {
  // ============================================
  // USUARIOS
  // ============================================
  getCurrentUser: async () => {
    const response = await fetch(`${API_BASE_URL}/users/current`, {
      credentials: 'include', // IMPORTANTE para Windows Auth
    });
    
    if (!response.ok) {
      throw new Error('No autenticado');
    }
    
    return response.json();
  },

  getUsers: async () => {
    const response = await fetch(`${API_BASE_URL}/users`, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener usuarios');
    }
    
    return response.json();
  },

  // ============================================
  // SALAS
  // ============================================
  getRooms: async () => {
    const response = await fetch(`${API_BASE_URL}/rooms`, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener salas');
    }
    
    return response.json();
  },

  updateRoomStatus: async (roomId: string, status: 'available' | 'occupied' | 'maintenance') => {
    const response = await fetch(`${API_BASE_URL}/rooms/${roomId}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ status }),
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al actualizar estado de sala');
    }
  },

  // ============================================
  // RESERVAS (Para implementar después)
  // ============================================
  getReservations: async (date?: Date) => {
    const url = date 
      ? `${API_BASE_URL}/reservations?date=${date.toISOString()}`
      : `${API_BASE_URL}/reservations`;
      
    const response = await fetch(url, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener reservas');
    }
    
    return response.json();
  },

  createReservation: async (reservation: any) => {
    const response = await fetch(`${API_BASE_URL}/reservations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(reservation),
      credentials: 'include',
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Error al crear reserva');
    }
    
    return response.json();
  },

  cancelReservation: async (reservationId: string) => {
    const response = await fetch(`${API_BASE_URL}/reservations/${reservationId}`, {
      method: 'DELETE',
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al cancelar reserva');
    }
  },
};
```

### 4.2 Actualizar App.tsx para usar API

Encuentra en tu `App.tsx` donde se cargan los datos mockeados y reemplaza con:

```typescript
import { api } from '@/app/services/api';

// ... dentro del componente App ...

const [currentUser, setCurrentUser] = useState<TeamMember | null>(null);
const [isAuthenticated, setIsAuthenticated] = useState(false);
const [isLoading, setIsLoading] = useState(true);
const [rooms, setRooms] = useState<Room[]>([]);
const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);

// Cargar datos del backend al iniciar
useEffect(() => {
  const loadData = async () => {
    try {
      setIsLoading(true);
      
      // 1. Obtener usuario actual (Windows Auth automática)
      const user = await api.getCurrentUser();
      setCurrentUser(user);
      setIsAuthenticated(true);
      
      // Guardar en localStorage para persistencia
      localStorage.setItem('sisugrb_windows_user', JSON.stringify(user));

      // 2. Cargar salas
      const roomsData = await api.getRooms();
      setRooms(roomsData);

      // 3. Cargar usuarios para autocompletado
      const usersData = await api.getUsers();
      setTeamMembers(usersData);

      toast.success(`Bienvenido, ${user.name}!`);
    } catch (error) {
      console.error('Error al cargar datos:', error);
      toast.error('Error al conectar con el servidor. Verifica que el backend esté corriendo.');
    } finally {
      setIsLoading(false);
    }
  };

  loadData();
}, []);

// Pantalla de carga
if (isLoading) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Cargando sistema...</p>
      </div>
    </div>
  );
}

// Si no hay usuario autenticado
if (!isAuthenticated || !currentUser) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center p-8 bg-white rounded-lg shadow-md">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Error de Autenticación</h1>
        <p className="text-gray-700 mb-2">No se pudo autenticar tu usuario de Windows.</p>
        <p className="text-sm text-gray-500">Verifica que estés en la red de SISU GRB.</p>
      </div>
    </div>
  );
}

// ... resto del componente con los datos cargados ...
```

### 4.3 Eliminar Componente de Login

Ya no necesitas el componente `WindowsLogin` porque la autenticación es automática.

En tu `App.tsx`, **elimina** o **comenta**:
```typescript
// ❌ Ya no necesitas esto:
// const [showLogin, setShowLogin] = useState(true);

// ❌ Ya no necesitas esto:
// if (showLogin) {
//   return <WindowsLogin onLogin={handleLogin} />;
// }
```

---

## 🚀 PARTE 5: Ejecutar Todo el Sistema

### 5.1 Ejecutar Backend
1. Abrir Visual Studio
2. Presionar **F5**
3. Verificar que se abra Swagger en `http://localhost:5000/swagger`

### 5.2 Ejecutar Frontend
1. Abrir terminal en `C:\SisuGRB\frontend\`
2. Ejecutar:
```bash
npm run dev
```
3. Abrir navegador en: `http://localhost:5173`

### 5.3 Verificar que Funciona

✅ Deberías ver:
1. Tu usuario Windows detectado automáticamente
2. Las 3 salas cargadas desde SQL Server
3. La lista de usuarios cargada desde SQL Server
4. Puedes cambiar estados de salas
5. Todo sin necesidad de hacer login manual

---

## 🎯 Configuración de Red Local (Opcional)

Si quieres que **otros usuarios en tu red** accedan al sistema:

### Backend - Permitir acceso desde red:

En `Program.cs`, cambia:
```csharp
builder.WebHost.UseUrls("http://0.0.0.0:5000"); // Escuchar en todas las interfaces
```

### Frontend - Apuntar a IP del servidor:

En `src/app/services/api.ts`:
```typescript
// Reemplaza localhost con la IP de la PC que tiene el backend
const API_BASE_URL = 'http://192.168.1.100:5000/api';
```

### Firewall - Permitir puerto 5000:
```powershell
# Ejecutar como Administrador en PowerShell:
New-NetFirewallRule -DisplayName "SISU GRB Backend" -Direction Inbound -Protocol TCP -LocalPort 5000 -Action Allow
```

---

## ✅ Verificación Final

Checklist completo:

- [ ] SQL Server Express instalado y corriendo
- [ ] Base de datos `SisuGrbRoomReservations` creada
- [ ] Tu usuario Windows está en la tabla `Users`
- [ ] Backend .NET corriendo en `http://localhost:5000`
- [ ] Frontend React corriendo en `http://localhost:5173`
- [ ] Puedes ver tu información de usuario automáticamente
- [ ] Las salas se cargan desde SQL Server
- [ ] Los usuarios se cargan desde SQL Server

---

## 🐛 Problemas Comunes

### "Cannot connect to SQL Server"
```sql
-- Verifica que SQL Server esté corriendo:
-- Servicios → SQL Server (SQLEXPRESS) → Estado: Ejecutándose
```

### "Windows Authentication failed"
```
Solución: Asegúrate de que tu usuario Windows esté en la tabla Users
con el formato correcto: SISUGRB\tu_usuario
```

### "CORS policy error"
```
Verifica que en Program.cs esté configurado CORS correctamente
y que incluya el puerto del frontend (5173)
```

### "Port 5000 already in use"
```powershell
# Encuentra qué proceso usa el puerto:
netstat -ano | findstr :5000

# Detén el proceso:
taskkill /PID [numero_pid] /F
```

---

## 🎉 ¡Listo!

Ahora tienes un sistema **100% local** con:
- ✅ Frontend React (tu diseño de Figma)
- ✅ Backend .NET Web API
- ✅ SQL Server Express
- ✅ Windows Authentication
- ✅ Todo corriendo en tu PC

**¡Sin necesidad de internet, completamente local!** 🚀
