# 🚨 INSTRUCCIONES URGENTES - LIMPIAR BASE DE DATOS

## ❌ PROBLEMA:
Sigues viendo "Conflicto de horario detectado" porque hay reservas viejas en la base de datos.

---

## ✅ SOLUCIÓN EN 5 PASOS:

### **PASO 1: Recarga la página**
Presiona **F5** o **Ctrl+R**

---

### **PASO 2: Busca el botón morado**
- Está en la esquina **inferior izquierda**
- Dice: **"Admin Debug"** con icono 🗄️
- Es color **MORADO**

---

### **PASO 3: Click en el botón morado**
Se abre un panel que muestra todas las reservas

---

### **PASO 4: Click en "Eliminar Todas"**
- Botón **ROJO** que dice: **"🗑️ Eliminar Todas (X)"**
- Click en el botón
- Confirma cuando te pregunte

---

### **PASO 5: Prueba crear una reserva**
- Cierra el panel
- Selecciona una sala
- Click "RESERVAR SALA"
- Llena los datos
- Click "Confirmar Reserva"

**¡Debería funcionar!** ✅

---

## 📸 GUÍA VISUAL:

```
┌─────────────────────────────────────┐
│                                     │
│    SISU GRB - Sistema Reservas      │
│                                     │
│   [Sala Piso 1]  [Sala Piso 2]    │
│                                     │
│                                     │
│                                     │
│                                     │
│                                     │
│                                     │
│                                     │
│  🗄️ Admin Debug  ← CLICK AQUÍ      │
│   (botón morado)                    │
└─────────────────────────────────────┘
```

---

## 🔍 SI NO VES EL BOTÓN:

1. **Verifica que recargaste la página** (F5)
2. **Mira la esquina inferior izquierda**
3. **Busca un botón morado pequeño**
4. **Puede estar parcialmente oculto** - mueve la ventana

---

## 📝 ALTERNATIVA: USAR LA CONSOLA

Si no ves el botón, usa esto:

1. **Presiona F12** (abre consola)
2. **Ve a la pestaña "Console"**
3. **Pega este código:**

```javascript
fetch('https://czbdjnjywggqkxsbmnmc.supabase.co/functions/v1/make-server-f5c6167b/api/reservations/admin/clear-all', {
  method: 'DELETE',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6YmRqbmp5d2dncWt4c2Jtbm1jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkyMjE4MzQsImV4cCI6MjA1NDc5NzgzNH0.Fpp3XPZh0_1wZr8mQ6KVKUpzqvqC7omewW5gPd1VVYI',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ adminKey: 'sisugrb-admin-2026' })
})
.then(res => res.json())
.then(data => {
  console.log('✅ Resultado:', data);
  alert(`Eliminadas ${data.count} reservas`);
  window.location.reload();
});
```

4. **Presiona Enter**
5. **Verás un alert** con cuántas reservas se eliminaron
6. **La página se recarga automáticamente**

---

## 🎯 DESPUÉS DE LIMPIAR:

### **Intenta crear una reserva:**

1. **Click en "RESERVAR SALA"**
2. **Llena:**
   - Motivo: "Prueba limpia"
   - Hora inicio: 10:00
   - Hora fin: 11:00
3. **Click "Confirmar Reserva"**

### **Resultado esperado:**
✅ Toast verde: "Reserva creada exitosamente"

---

## ❌ SI SIGUE FALLANDO:

Copia y envía esto:

1. **Abre consola (F12)**
2. **Ve a pestaña "Console"**
3. **Copia TODO el texto de error**
4. **Envíamelo**

También envía:

1. **¿Cuántas reservas se eliminaron?** (lo dice el alert)
2. **¿Qué sala estás intentando reservar?**
3. **¿Qué fecha y hora estás intentando?**

---

## 📊 VERIFICAR QUE LA BD ESTÁ LIMPIA:

Usa la consola:

```javascript
fetch('https://czbdjnjywggqkxsbmnmc.supabase.co/functions/v1/make-server-f5c6167b/api/debug/reservations', {
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6YmRqbmp5d2dncWt4c2Jtbm1jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkyMjE4MzQsImV4cCI6MjA1NDc5NzgzNH0.Fpp3XPZh0_1wZr8mQ6KVKUpzqvqC7omewW5gPd1VVYI'
  }
})
.then(res => res.json())
.then(data => {
  console.log('📊 Total de reservas:', data.total);
  console.log('📋 Detalle:', data.reservations);
});
```

Deberías ver: **"Total de reservas: 0"**

---

## ✅ RESUMEN:

1. ✅ **Recarga página** (F5)
2. ✅ **Click botón morado** (inferior izquierda)
3. ✅ **Click "Eliminar Todas"**
4. ✅ **Confirmar**
5. ✅ **Probar reserva**

---

## 🆘 SOPORTE RÁPIDO:

Si después de limpiar SIGUE fallando, el problema es otro.

Envíame:
- Screenshot del error
- Logs de la consola
- Cuántas reservas se eliminaron

---

¡Prueba ahora! 🚀
