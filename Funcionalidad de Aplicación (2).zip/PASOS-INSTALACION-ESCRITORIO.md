# 🖥️ INSTALACIÓN COMPLETA - APLICACIÓN DE ESCRITORIO SISU GRB

## 📋 Requisitos Previos

### Software necesario:
1. ✅ **Visual Studio 2022** (Community Edition es suficiente)
   - Descarga: https://visualstudio.microsoft.com/es/downloads/
   - Durante la instalación, seleccionar: **"ASP.NET and web development"**

2. ✅ **SQL Server Express 2022**
   - Descarga: https://www.microsoft.com/es-es/sql-server/sql-server-downloads
   - Elegir **Express Edition** (gratuita)

3. ✅ **SQL Server Management Studio (SSMS)**
   - Descarga: https://aka.ms/ssmsfullsetup

4. ✅ **Node.js** (versión 18 o superior)
   - Descarga: https://nodejs.org/
   - Elegir la versión **LTS**

---

## 🚀 FASE 1: Configurar SQL Server

### Paso 1.1: Instalar SQL Server Express

1. Ejecutar el instalador descargado
2. Elegir tipo de instalación: **"Basic"**
3. Aceptar la licencia
4. Elegir carpeta de instalación (dejar por defecto)
5. **¡IMPORTANTE!** Anotar el nombre de la instancia que aparece al final:
   ```
   Ejemplo: DESKTOP-ABC123\SQLEXPRESS
   ```
   ⚠️ **Guarda este nombre, lo necesitarás más adelante**

### Paso 1.2: Verificar que SQL Server esté corriendo

1. Presiona `Windows + R`
2. Escribe: `services.msc`
3. Busca el servicio: **SQL Server (SQLEXPRESS)**
4. Verifica que el estado sea: **"En ejecución"** (Running)
5. Si no está corriendo:
   - Click derecho → **Iniciar**
   - Click derecho → **Propiedades** → Tipo de inicio: **Automático**

### Paso 1.3: Instalar SQL Server Management Studio

1. Ejecutar el instalador de SSMS
2. Instalación con opciones por defecto
3. Reiniciar la computadora si lo solicita

### Paso 1.4: Crear la Base de Datos

1. Abrir **SQL Server Management Studio (SSMS)**
2. En la ventana de conexión:
   - **Nombre del servidor:** `localhost\SQLEXPRESS` (o el nombre que anotaste)
   - **Autenticación:** `Autenticación de Windows`
   - Click en **Conectar**

3. Una vez conectado:
   - Ir a **File → Open → File...**
   - Buscar el archivo: `/backend-dotnet/SQL/01-create-database.sql` de este proyecto
   - Click en **Execute** (F5)

4. ✅ **Verificación:** Deberías ver un mensaje de éxito y la base de datos `SisuGrbRoomReservations` en el panel izquierdo

---

## 🏗️ FASE 2: Configurar el Backend .NET

### Paso 2.1: Crear el Proyecto en Visual Studio

1. Abrir **Visual Studio 2022**
2. Click en **Create a new project**
3. Buscar y seleccionar: **ASP.NET Core Web API**
4. Click en **Next**
5. Configurar:
   - **Project name:** `SisuGrb.RoomReservations`
   - **Location:** Elegir una carpeta (ejemplo: `C:\Proyectos\SISU-GRB\`)
   - Click en **Next**
6. Framework:
   - **Framework:** `.NET 8.0 (Long Term Support)`
   - ✅ Marcar: **Configure for HTTPS**
   - ✅ Marcar: **Enable OpenAPI support**
   - ❌ Desmarcar: **Use controllers** (vamos a usar controllers, pero crearemos la estructura manualmente)
   - Click en **Create**

### Paso 2.2: Copiar los archivos del backend

1. En el Explorador de Windows, navega a donde descargaste este proyecto
2. Copia toda la carpeta `/backend-dotnet/`
3. Pégala dentro de la carpeta de tu proyecto: `C:\Proyectos\SISU-GRB\SisuGrb.RoomReservations\`

4. En Visual Studio:
   - Click derecho en el proyecto → **Add → Existing Item...**
   - Navega a `/backend-dotnet/` y agrega todos los archivos:
     - Carpeta `Controllers/` completa
     - Carpeta `Data/` completa
     - Carpeta `Models/` completa
     - Archivo `Program.cs` (reemplazar el existente)

### Paso 2.3: Instalar Paquetes NuGet

1. En Visual Studio, ir a: **Tools → NuGet Package Manager → Package Manager Console**
2. Ejecutar estos comandos uno por uno:

```powershell
Install-Package Microsoft.EntityFrameworkCore.SqlServer -Version 8.0.0
Install-Package Microsoft.EntityFrameworkCore.Tools -Version 8.0.0
Install-Package Microsoft.AspNetCore.Authentication.Negotiate -Version 8.0.0
```

### Paso 2.4: Configurar Connection String

1. En Visual Studio, abrir el archivo `appsettings.json`
2. Reemplazar TODO el contenido con:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=SisuGrbRoomReservations;Integrated Security=true;TrustServerCertificate=True;MultipleActiveResultSets=true;"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

⚠️ **IMPORTANTE:** Si tu instancia de SQL Server tiene un nombre diferente a `localhost\SQLEXPRESS`, cámbialo en el `Server=...`

### Paso 2.5: Configurar Puerto y CORS

1. En el proyecto, buscar la carpeta **Properties**
2. Abrir `launchSettings.json`
3. Buscar la sección `"applicationUrl"` y cambiarla a:

```json
"applicationUrl": "http://localhost:5000"
```

4. Guardar el archivo

### Paso 2.6: Agregar tu Usuario de Windows a la Base de Datos

1. Primero, averigua tu usuario de Windows:
   - Presiona `Windows + R`
   - Escribe: `cmd`
   - Ejecuta: `whoami`
   - Copia el resultado (ejemplo: `SISUGRB\jperez`)

2. Abrir **SQL Server Management Studio**
3. Conectarte a tu servidor
4. Click en **New Query**
5. Ejecutar este script (REEMPLAZA los datos con tus datos reales):

```sql
-- Primero, verifica qué equipos hay
SELECT * FROM Teams;

-- Luego, inserta tu usuario (cambia los valores según tu caso)
INSERT INTO Users (WindowsUsername, DisplayName, Email, TeamId, IsActive)
VALUES (
    'SISUGRB\jperez',           -- TU usuario de Windows (del paso whoami)
    'Juan Pérez',                -- Tu nombre completo
    'jperez@sisugrb.com',       -- Tu email
    1,                           -- ID del equipo (mira la tabla Teams)
    1                            -- 1 = activo
);

-- Verificar que se insertó correctamente
SELECT * FROM Users WHERE WindowsUsername LIKE '%jperez%';
```

### Paso 2.7: Probar el Backend

1. En Visual Studio, presionar **F5** (Iniciar con depuración)
2. Se abrirá el navegador con Swagger: `http://localhost:5000/swagger`
3. Probar el endpoint: **GET /api/users/current**
   - Click en **Try it out**
   - Click en **Execute**
   - Deberías ver tu información de usuario

✅ **Si funciona:** ¡Tu backend está listo!
❌ **Si da error 401:** Tu usuario no está en la base de datos, repite el paso 2.6

---

## 🎨 FASE 3: Configurar el Frontend

### Paso 3.1: Instalar Node.js

1. Si no lo has hecho, descargar e instalar Node.js: https://nodejs.org/
2. Verificar la instalación:
   - Abrir **Command Prompt** o **PowerShell**
   - Ejecutar: `node --version`
   - Debería mostrar la versión (ejemplo: `v20.11.0`)

### Paso 3.2: Instalar dependencias del proyecto

1. Abrir **Command Prompt** o **PowerShell**
2. Navegar a la carpeta del proyecto frontend:
   ```bash
   cd C:\ruta\donde\descargaste\este\proyecto
   ```
3. Instalar dependencias:
   ```bash
   npm install
   ```

### Paso 3.3: Verificar la configuración de la API

1. Abrir el archivo `/src/app/services/api.ts`
2. Verificar que la línea 1 diga:
   ```typescript
   const API_BASE_URL = 'http://localhost:5000/api';
   ```
   (Este puerto debe coincidir con el del backend)

---

## 🚀 FASE 4: ¡Iniciar la Aplicación Completa!

### Método 1: Desarrollo (Recomendado para empezar)

**Terminal 1 - Backend:**
1. Abrir Visual Studio con el proyecto backend
2. Presionar **F5** para iniciar el servidor .NET
3. Dejar esta ventana abierta

**Terminal 2 - Frontend:**
1. Abrir **Command Prompt** o **PowerShell**
2. Navegar a la carpeta del proyecto
3. Ejecutar:
   ```bash
   npm run dev
   ```
4. Abrir el navegador en: `http://localhost:5173`

✅ **¡Listo!** La aplicación debería:
- Detectar automáticamente tu usuario de Windows
- Mostrar las 3 salas (Piso 1, Piso 2, Piso 3)
- Permitirte hacer reservas
- Todo guardado en SQL Server

---

### Método 2: Aplicación de Escritorio Completa (Opcional)

Si quieres empaquetar todo en un ejecutable `.exe` para distribuir en la empresa:

1. **Backend:** Publicar como aplicación auto-contenida
   ```powershell
   dotnet publish -c Release -r win-x64 --self-contained true
   ```

2. **Frontend:** Construir para producción
   ```bash
   npm run build
   ```

3. **Crear un instalador** usando:
   - **Inno Setup** (gratuito): https://jrsoftware.org/isinfo.php
   - O **WiX Toolset**: https://wixtoolset.org/

📌 **Nota:** Este paso es avanzado. Es recomendable primero asegurarse de que todo funcione en modo desarrollo.

---

## 🔧 Configuración Avanzada (Opcional)

### Hacer que la aplicación inicie automáticamente

1. Crear un archivo `start-sisugrb.bat`:
   ```batch
   @echo off
   echo Iniciando SISU GRB Room Reservations...
   
   REM Iniciar backend
   start "" "C:\Proyectos\SISU-GRB\SisuGrb.RoomReservations\bin\Debug\net8.0\SisuGrb.RoomReservations.exe"
   
   REM Esperar 5 segundos
   timeout /t 5 /nobreak
   
   REM Abrir navegador
   start "" "http://localhost:5173"
   ```

2. Guardar en el escritorio
3. Doble click para iniciar todo automáticamente

---

## 🐛 Solución de Problemas Comunes

### Error: "Cannot connect to SQL Server"
**Solución:**
1. Verificar que SQL Server esté corriendo (services.msc)
2. Verificar el nombre de la instancia en `appsettings.json`
3. Intentar conectar desde SSMS primero

### Error: "401 Unauthorized" en la API
**Solución:**
1. Tu usuario de Windows no está en la base de datos
2. Ejecutar el script del **Paso 2.6** con tus datos

### Error: "Port 5000 already in use"
**Solución:**
1. Cambiar el puerto en `launchSettings.json` del backend (ejemplo: 5001)
2. Actualizar `API_BASE_URL` en `/src/app/services/api.ts` con el nuevo puerto

### Error: "CORS policy error"
**Solución:**
1. Verificar que `Program.cs` tenga configurado CORS para `http://localhost:5173`
2. Verificar que `app.UseCors()` esté ANTES de `app.UseAuthorization()`

### La página se queda en blanco
**Solución:**
1. Abrir las herramientas de desarrollo del navegador (F12)
2. Ver la consola para errores
3. Verificar que el backend esté corriendo en `http://localhost:5000`

---

## ✅ Lista de Verificación Final

Antes de usar la aplicación en producción:

- [ ] SQL Server Express instalado y corriendo
- [ ] Base de datos `SisuGrbRoomReservations` creada con todas las tablas
- [ ] Todos los usuarios del equipo agregados a la tabla `Users`
- [ ] Backend .NET corriendo en `http://localhost:5000`
- [ ] Frontend React corriendo en `http://localhost:5173`
- [ ] Autenticación de Windows funcionando
- [ ] Puedes crear y cancelar reservas
- [ ] Los estados de las salas se actualizan correctamente

---

## 📞 Siguiente Paso

Después de completar esta instalación, el siguiente paso es:
1. Agregar todos los usuarios de SISU GRB a la base de datos
2. Configurar horarios especiales si los hay
3. Personalizar los equipos y colores si es necesario

¿Necesitas ayuda con algún paso? ¡Consulta el archivo `/backend-dotnet/COMENZAR-AQUI.md` para más detalles técnicos!
