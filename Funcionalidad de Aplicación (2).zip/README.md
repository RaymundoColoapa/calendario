# 🏢 Sistema de Reservas SISU GRB

Sistema de gestión de reservas de salas de juntas para SISU Global Reinsurance Broker.

---

## 🚀 DESPLIEGUE A PRODUCCIÓN

### ⚡ Inicio Rápido (10 minutos)

**📖 Lee: [`INICIO-RAPIDO-DESPLIEGUE.md`](./INICIO-RAPIDO-DESPLIEGUE.md)** ⭐ **EMPIEZA AQUÍ**

**Windows:** Ejecuta el script automático:
```batch
deploy-backend.bat
```

**Mac/Linux:** Comandos manuales:
```bash
npm install -g supabase
supabase login
supabase link --project-ref daowqmfdusubyicuuowy
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

**📚 Guía completa:** [`GUIA-DESPLIEGUE-COMPLETA.md`](./GUIA-DESPLIEGUE-COMPLETA.md)

---

## 🧪 MODO DEMO (Para Probar Sin Desplegar)

**Si solo quieres probar la aplicación localmente**, activa el modo demo ejecutando esto en consola (F12):

```javascript
localStorage.setItem('sisugrb_demo_mode', 'true');
location.reload();
```

**📖 Guía completa:** [`MODO_DEMO.md`](./MODO_DEMO.md)

---

## 🚨 ¿VES ALGÚN ERROR?

**Si ves cualquier error** ("Auto-login", "Conflicto", etc.), ejecuta esto en consola (F12):

```javascript
localStorage.clear();
localStorage.setItem('sisugrb_demo_mode', 'true');
localStorage.setItem('sisugrb_demo_version', '2.0');
location.reload();
```

📖 **Soluciones completas:** [`SOLUCION_DEFINITIVA.md`](./SOLUCION_DEFINITIVA.md)

---

## ⚡ INICIO RÁPIDO

**¿Quieres probarlo AHORA? Lee [`INICIO_RAPIDO.md`](./INICIO_RAPIDO.md)** - 3 pasos, 2 minutos.

O ejecuta esto en la consola del navegador (F12):
```javascript
localStorage.setItem('sisugrb_demo_mode', 'true');
location.reload();
```

---

## 📋 Características

### Gestión de Salas
- 🏢 **3 Salas de Juntas:**
  - Piso 1: Capacidad 10 personas
  - Piso 2: Capacidad 10 personas
  - Piso 3: Capacidad 30 personas (Capacitación)

### Reservas
- ✅ Crear reservas con propósito y duración
- ❌ Cancelar reservas (solo el dueño)
- 📅 Ver reservas por fecha
- 🔍 Autocompletado de nombres de usuarios
- ⏰ Validación de horarios (8:30 AM - 6:00 PM, Lun-Vie)
- 🚫 Prevención de conflictos de horarios

### Estados de Sala
- 🟢 **Libre** - Disponible para reservar
- 🔴 **Ocupado** - Tiene una reserva activa
- 🟠 **Mantenimiento** - No disponible

### Permisos
- 👥 **Usuarios normales**: Crear y cancelar sus propias reservas
- 👨‍💼 **Administradores**: Gestionar el estado de mantenimiento de las salas

### Equipos
- Operaciones
- Ventas
- Tecnología
- Administración

---

## 🎨 Diseño

- Colores corporativos: Gris cemento y Rojo SISU GRB
- Logo de SISU GRB en header
- Diseño responsive (funciona en laptops y celulares)
- Botones grandes y visibles
- Interfaz intuitiva

---

## 👥 Usuarios de Demostración

En modo demo, puedes ingresar como:

1. **María González** (Operaciones)
2. **Juan Pérez** (Ventas)
3. **Ana López** (Tecnología)
4. **José Luis Pimienta** (Administración) - ⭐ Tiene permisos de mantenimiento

---

## 🔧 Configuración Técnica

### Stack Tecnológico
- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Supabase Edge Functions (Deno + Hono)
- **Base de Datos**: Supabase PostgreSQL
- **Autenticación**: Auto-login con Azure AD / Windows

### Arquitectura
```
Frontend (React)
    ↓
Supabase Edge Function (Hono API)
    ↓
Supabase PostgreSQL (KV Store)
```

### Endpoints API
```
GET  /health                           # Health check
GET  /api/users                        # Listar usuarios
POST /api/users/auto-login             # Auto-login
GET  /api/rooms                        # Listar salas
GET  /api/reservations?date=YYYY-MM-DD # Listar reservas
POST /api/reservations                 # Crear reserva
DELETE /api/reservations/:id           # Cancelar reserva
POST /api/maintenance/toggle           # Toggle mantenimiento
```

---

## 🐛 Troubleshooting

### Error: "Failed to fetch"
**Causa**: El backend no está desplegado  
**Solución**: Usa modo demo o despliega el backend

### Error: "No se puede conectar"
**Causa**: Sin internet o backend caído  
**Solución**: Verifica conexión y logs de Supabase

### ¿Cómo salir del modo demo?
```javascript
localStorage.removeItem('sisugrb_demo_mode');
location.reload();
```

---

## 📊 Capacidad

- **Usuarios simultáneos**: 50+
- **Reservas diarias**: Ilimitadas
- **Salas**: 3 (configurable)
- **Horario**: 8:30 AM - 6:00 PM, Lun-Vie

---

## 📖 Documentación Adicional

- [`INSTRUCCIONES_DESPLIEGUE.md`](./INSTRUCCIONES_DESPLIEGUE.md) - Guía de despliegue paso a paso
- [`PERMISOS_Y_ROLES.md`](./PERMISOS_Y_ROLES.md) - Sistema de permisos y roles

---

## 🔒 Seguridad

- ✅ Solo el dueño puede cancelar sus reservas (verificado en backend)
- ✅ Solo administradores pueden gestionar mantenimiento
- ✅ Validación de horarios de oficina
- ✅ Prevención de conflictos de reservas
- ⚠️ **IMPORTANTE**: Cambiar la clave de admin debug antes de producción

---

## 💡 Próximos Pasos

1. ✅ Desplegar backend en Supabase
2. ✅ Probar con usuarios reales
3. ✅ Configurar Azure AD para auto-login
4. ✅ Capacitar al equipo
5. ✅ Configurar monitoreo y logs
6. ✅ Establecer backup de datos

---

## 📞 Soporte

Para problemas técnicos:
1. Revisa la consola del navegador (F12)
2. Revisa los logs de Supabase Edge Functions
3. Consulta la documentación en este repositorio

---

## ⚡ Desarrollo Rápido

```bash
# Desarrollo local
npm run dev

# Build
npm run build

# Ver logs del servidor
supabase functions logs make-server-f5c6167b
```

---

**¡Listo para usar! 🎉**