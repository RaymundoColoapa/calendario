# 🗑️ CÓMO LIMPIAR RESERVAS - GUÍA RÁPIDA

## ✅ ARREGLÉ EL PROBLEMA DE CONFLICTOS

Ahora el sistema solo compara reservas **del mismo día**.

---

## 🎯 USA EL PANEL DE ADMINISTRACIÓN

### **Paso 1: Abre el Panel**

1. **Recarga la página** (F5)
2. Busca el **botón morado** en la esquina inferior izquierda que dice:
   ```
   🗄️ Admin Debug
   ```
3. **Click en el botón**

---

### **Paso 2: Ver las Reservas**

Verás un panel que muestra:
- ✅ **Total de reservas** en el sistema
- ✅ **Cuántas están activas**
- ✅ **Cuántas están canceladas**
- ✅ **Lista de todas las reservas** con detalles

---

### **Paso 3: Limpiar Reservas (Si es necesario)**

Si ves muchas reservas viejas:

1. **Click en el botón rojo:**
   ```
   🗑️ Eliminar Todas (X)
   ```
   
2. **Confirmar** en el diálogo que aparece

3. **¡Listo!** Todas las reservas eliminadas

4. **Cierra el panel**

---

## 🧪 PROBAR AHORA

### **Después de limpiar (opcional):**

1. **Recarga la página** (F5)

2. **Crea una reserva de prueba:**
   - Sala: Piso 1
   - Fecha: Hoy
   - Hora: 10:00 - 11:00
   - Motivo: "Prueba"
   - Click "Confirmar Reserva"

3. **Debería funcionar ✅**

4. **Intenta crear otra en el MISMO horario:**
   - Sala: Piso 1
   - Fecha: Hoy
   - Hora: 10:00 - 11:00 (MISMO)
   - Motivo: "Otra prueba"

5. **Debería dar error ❌** (correcto - hay conflicto)

6. **Intenta crear en DIFERENTE horario:**
   - Sala: Piso 1
   - Fecha: Hoy
   - Hora: 11:00 - 12:00 (DIFERENTE)
   - Motivo: "Tercera prueba"

7. **Debería funcionar ✅** (no hay conflicto)

---

## 📊 LO QUE CAMBIÓ:

### **Antes:**
```
Sistema comparaba TODAS las reservas (de cualquier día)
↓
Falsos conflictos
```

### **Ahora:**
```
Sistema compara solo reservas del MISMO día
↓
Solo conflictos reales
```

---

## 💡 EJEMPLO CLARO:

### **Escenario:**
- Reserva A: **15 de febrero** a las 10:00-11:00
- Reserva B: **16 de febrero** a las 10:00-11:00

### **Antes:**
❌ "Conflicto de horario" (INCORRECTO)

### **Ahora:**
✅ Sin conflicto (CORRECTO - son días diferentes)

---

## 🔍 VER LOGS DETALLADOS:

Si quieres ver exactamente qué está pasando:

1. Abre **Consola del navegador** (F12)
2. Ve a **Console**
3. Intenta crear una reserva
4. Verás logs como:

```
📥 Datos de reserva recibidos: {...}
✅ Validaciones pasadas - Room: Sala Piso 1 - User: Tu Nombre
🔍 Buscando conflictos para fecha: 2026-02-15
📋 Reservas existentes para 2026-02-15: 0
✅ Reserva creada exitosamente: 1739654321000
```

Si hay conflicto:
```
📋 Reservas existentes para 2026-02-15: 1
⚠️ Conflicto detectado con reserva: {
  existing: "10:00:00 - 11:00:00",
  new: "10:30:00 - 11:30:00"
}
❌ Conflicto de horario detectado
```

---

## ✅ AHORA DEBERÍA FUNCIONAR

**Recarga la página y prueba crear una reserva.**

Si sigue dando error, usa el **Panel Admin Debug** para ver y limpiar las reservas.

---

¡Todo listo! 🚀
