# ⚡ GUÍA RÁPIDA DE REFERENCIA - SISU GRB

Esta es tu guía de "cheat sheet" para cuando ya tengas todo instalado y solo necesites recordar comandos básicos.

---

## 🚀 INICIAR LA APLICACIÓN

### Opción 1: Script Automático (Recomendado)

```bash
# Doble click en:
start-sisugrb-local.bat
```

✅ Inicia SQL Server  
✅ Inicia Frontend  
✅ Abre navegador  

---

### Opción 2: Manual (Paso a Paso)

**Terminal 1 - Backend:**
```bash
# Abrir Visual Studio 2022
# Abrir proyecto: SisuGrb.RoomReservations
# Presionar F5
```

**Terminal 2 - Frontend:**
```bash
cd C:\ruta\tu\proyecto
npm run dev
```

**Navegador:**
```
http://localhost:5173
```

---

## 🛑 DETENER LA APLICACIÓN

1. **Backend**: Detener depuración en Visual Studio (Shift+F5)
2. **Frontend**: `Ctrl+C` en la terminal
3. **SQL Server**: (dejar corriendo, o detener desde services.msc)

---

## 🗄️ COMANDOS SQL ÚTILES

### Ver todas las reservas de hoy

```sql
SELECT 
    r.Id,
    r.Purpose,
    r.StartTime,
    r.EndTime,
    u.DisplayName AS Usuario,
    rm.Name AS Sala,
    r.Status
FROM Reservations r
INNER JOIN Users u ON r.UserId = u.Id
INNER JOIN Rooms rm ON r.RoomId = rm.Id
WHERE CAST(r.StartTime AS DATE) = CAST(GETDATE() AS DATE)
    AND r.Status = 'Active'
ORDER BY r.StartTime;
```

### Agregar un nuevo usuario

```sql
INSERT INTO Users (WindowsUsername, DisplayName, Email, TeamId, IsActive)
VALUES (
    'SISUGRB\nuevousuario',  -- Usuario de Windows
    'Nombre Completo',        -- Nombre para mostrar
    'correo@sisugrb.com',    -- Email
    1,                        -- ID del equipo (1=Desarrollo, 2=Gestión, 3=Soporte, 4=Admin)
    1                         -- 1=Activo, 0=Inactivo
);
```

### Ver todos los usuarios

```sql
SELECT 
    u.Id,
    u.WindowsUsername,
    u.DisplayName,
    u.Email,
    t.Name AS Equipo,
    u.IsActive
FROM Users u
INNER JOIN Teams t ON u.TeamId = t.Id
ORDER BY u.DisplayName;
```

### Cancelar una reserva específica

```sql
UPDATE Reservations
SET Status = 'Cancelled'
WHERE Id = 123;  -- Reemplaza 123 con el ID de la reserva
```

### Ver reservas futuras por sala

```sql
SELECT 
    rm.Name AS Sala,
    r.Purpose AS Proposito,
    r.StartTime AS Inicio,
    r.EndTime AS Fin,
    u.DisplayName AS Organizador
FROM Reservations r
INNER JOIN Rooms rm ON r.RoomId = rm.Id
INNER JOIN Users u ON r.UserId = u.Id
WHERE r.StartTime > GETDATE()
    AND r.Status = 'Active'
ORDER BY rm.Name, r.StartTime;
```

---

## 🔧 COMANDOS DE NPM

### Iniciar desarrollo

```bash
npm run dev
```

### Instalar dependencias

```bash
npm install
```

### Limpiar caché (si hay problemas)

```bash
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

### Build para producción

```bash
npm run build
```

### Preview del build

```bash
npm run preview
```

---

## 🐛 TROUBLESHOOTING RÁPIDO

### Error: "Cannot connect to SQL Server"

```bash
# Verificar servicio
services.msc → Buscar "SQL Server (SQLEXPRESS)" → Iniciar
```

### Error: "401 Unauthorized"

```sql
-- Tu usuario no está en la base de datos
SELECT * FROM Users WHERE WindowsUsername LIKE '%tunombre%';

-- Si no aparece, agregarlo:
INSERT INTO Users (WindowsUsername, DisplayName, Email, TeamId, IsActive)
VALUES ('SISUGRB\tunombre', 'Tu Nombre', 'tu@email.com', 1, 1);
```

### Error: "Port 5000 already in use"

```bash
# Ver qué proceso usa el puerto
netstat -ano | findstr :5000

# Matar el proceso (reemplazar PID con el número que aparece)
taskkill /PID 1234 /F
```

### Error: "CORS policy"

Verificar en `Program.cs`:
```csharp
builder.Services.AddCors(options => {
    options.AddPolicy("AllowFrontend", policy => {
        policy.WithOrigins("http://localhost:5173")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});
```

### Frontend no conecta con Backend

```typescript
// Verificar en /src/app/services/api.ts
const API_BASE_URL = 'http://localhost:5000/api';  // ← Debe coincidir con el puerto del backend
```

---

## 🔑 ENDPOINTS DE LA API

### Base URL

```
http://localhost:5000/api
```

### Usuarios

```http
GET  /users/current          # Usuario actual (Windows Auth)
GET  /users                  # Listar todos
GET  /users/teams            # Listar equipos
```

### Salas

```http
GET  /rooms                  # Listar todas
GET  /rooms/{id}             # Obtener una
PUT  /rooms/{id}/status      # Cambiar estado
```

### Reservas

```http
GET    /rooms/reservations        # Todas (filtro: ?date=2026-02-11)
GET    /rooms/reservations/my     # Mis reservas
POST   /rooms/reservations        # Crear
DELETE /rooms/reservations/{id}   # Cancelar
```

---

## 📝 EJEMPLO: CREAR RESERVA CON CURL

```bash
curl -X POST "http://localhost:5000/api/rooms/reservations" \
  -H "Content-Type: application/json" \
  -d '{
    "roomId": 1,
    "startTime": "2026-02-11T10:00:00",
    "endTime": "2026-02-11T11:00:00",
    "purpose": "Reunión de equipo"
  }'
```

---

## 🗺️ ESTRUCTURA DE ARCHIVOS CLAVE

```
PROYECTO/
├── src/
│   ├── app/
│   │   ├── App.tsx                        ← Componente principal
│   │   ├── components/
│   │   │   ├── room-card-large.tsx        ← Tarjeta de sala
│   │   │   └── quick-reservation-form.tsx ← Formulario de reserva
│   │   └── services/
│   │       └── api.ts                     ← Cliente API
│   └── styles/
│       └── theme.css                      ← Colores SISU GRB
│
└── backend-dotnet/
    ├── Controllers/
    │   ├── UsersController.cs             ← Endpoints de usuarios
    │   └── RoomsController.cs             ← Endpoints de salas
    ├── Models/                            ← Modelos de datos
    └── SQL/
        └── 01-create-database.sql         ← Script de BD
```

---

## 🎨 COLORES SISU GRB

```css
/* Grises */
--neutral-100: #f5f5f5;
--neutral-200: #e5e5e5;
--neutral-300: #d4d4d4;
--neutral-400: #a3a3a3;
--neutral-700: #404040;
--neutral-800: #262626;

/* Rojo Corporativo */
--red-50: #fef2f2;
--red-100: #fee2e2;
--red-300: #fca5a5;
--red-600: #dc2626;  ← Color principal
--red-700: #b91c1c;
```

---

## ⚙️ CONFIGURACIÓN RÁPIDA

### Connection String (appsettings.json)

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=SisuGrbRoomReservations;Integrated Security=true;TrustServerCertificate=True;"
  }
}
```

### Puerto del Backend (launchSettings.json)

```json
{
  "applicationUrl": "http://localhost:5000"
}
```

### Puerto del Frontend (vite.config.ts)

```typescript
export default defineConfig({
  server: {
    port: 5173
  }
})
```

---

## 📊 DATOS INICIALES

### Equipos (Teams)

| ID | Nombre | Color |
|----|--------|-------|
| 1 | Desarrollo | #3B82F6 (Azul) |
| 2 | Gestión | #EF4444 (Rojo) |
| 3 | Soporte | #10B981 (Verde) |
| 4 | Administración | #F59E0B (Ámbar) |

### Salas (Rooms)

| ID | Nombre | Piso | Capacidad |
|----|--------|------|-----------|
| 1 | Sala Piso 1 | 1 | 10 |
| 2 | Sala Piso 2 | 2 | 10 |
| 3 | Sala Piso 3 - Capacitación | 3 | 30 |

---

## 🔐 VALIDACIONES AUTOMÁTICAS

### Horario de Operación

```
Lunes a Viernes: 8:30 AM - 6:00 PM
Sábado y Domingo: ❌ No permitido
```

### Reglas de Reserva

- ✅ Duración mínima: 30 minutos
- ✅ Duración máxima: 4 horas
- ✅ Sin conflictos de horario
- ✅ Solo organizador puede cancelar

---

## 📱 ACCESO DESDE OTRAS COMPUTADORAS (RED LOCAL)

Si quieres que otros en la red local accedan:

### 1. Configurar Backend

En `Program.cs`, cambiar:
```csharp
app.Urls.Add("http://0.0.0.0:5000");  // Escucha en todas las interfaces
```

### 2. Configurar Firewall

```bash
# Abrir puerto 5000 en Windows Firewall
netsh advfirewall firewall add rule name="SISU GRB Backend" dir=in action=allow protocol=TCP localport=5000
```

### 3. Obtener IP de la PC Servidor

```bash
ipconfig
# Buscar "IPv4 Address": Ejemplo: 192.168.1.100
```

### 4. Otros Usuarios Acceden a:

```
http://192.168.1.100:5173
```

⚠️ **Nota:** El backend debe apuntar a la misma IP en `/src/app/services/api.ts`

---

## 🔄 BACKUP DE BASE DE DATOS

### Backup Manual (SSMS)

```
1. Click derecho en base de datos "SisuGrbRoomReservations"
2. Tasks → Back Up...
3. Elegir ubicación
4. Click OK
```

### Backup Automático (SQL)

```sql
BACKUP DATABASE SisuGrbRoomReservations
TO DISK = 'C:\Backups\SISUGRB_Backup.bak'
WITH FORMAT;
```

### Restaurar Backup

```sql
RESTORE DATABASE SisuGrbRoomReservations
FROM DISK = 'C:\Backups\SISUGRB_Backup.bak'
WITH REPLACE;
```

---

## 🎯 CHECKLIST DIARIO

### Inicio del Día

- [ ] Verificar SQL Server corriendo
- [ ] Iniciar backend (F5 en Visual Studio)
- [ ] Iniciar frontend (`npm run dev`)
- [ ] Verificar que la app carga correctamente

### Fin del Día

- [ ] Detener frontend (Ctrl+C)
- [ ] Detener backend (Shift+F5)
- [ ] SQL Server puede quedarse corriendo

### Mantenimiento Semanal

- [ ] Verificar espacio en disco
- [ ] Backup de base de datos
- [ ] Limpiar reservas antiguas (opcional)
- [ ] Revisar logs de errores

---

## 📞 CONTACTOS DE SOPORTE

| Rol | Nombre | Contacto |
|-----|--------|----------|
| Administrador BD | _______________ | _______________ |
| Desarrollador | _______________ | _______________ |
| Soporte Técnico | _______________ | _______________ |

---

## 🚨 EMERGENCIAS

### ¿La aplicación no carga?

1. ✅ ¿SQL Server corriendo? → `services.msc`
2. ✅ ¿Backend corriendo? → Ver Visual Studio
3. ✅ ¿Frontend corriendo? → Ver terminal
4. ✅ ¿Puertos correctos? → Backend: 5000, Frontend: 5173

### ¿Los datos no se guardan?

1. ✅ Verificar conexión a BD en `appsettings.json`
2. ✅ Ver errores en consola del navegador (F12)
3. ✅ Ver Output en Visual Studio

### ¿Usuario no puede autenticarse?

```sql
-- Verificar que el usuario existe
SELECT * FROM Users WHERE WindowsUsername LIKE '%nombreusuario%';
```

---

## 🎓 RECURSOS ADICIONALES

| Documento | Para qué sirve |
|-----------|----------------|
| `README.md` | Visión general del proyecto |
| `COMIENZA-AQUI.md` | Tu punto de partida |
| `PASOS-INSTALACION-ESCRITORIO.md` | Instalación paso a paso |
| `MIGRACION-A-API.md` | Migrar código a API |
| `ARQUITECTURA-SISTEMA.md` | Entender la arquitectura |
| `CHECKLIST-INSTALACION.md` | Seguimiento de instalación |
| `GUIA-RAPIDA.md` | Este documento |

---

**¡Guarda este documento como referencia rápida! 📌**

*Sistema SISU GRB - Gestión de Salas de Juntas*
