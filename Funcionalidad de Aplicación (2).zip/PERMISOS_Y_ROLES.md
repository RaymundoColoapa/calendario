# Sistema de Permisos y Roles - SISU GRB

## 📋 Descripción General

El sistema de reservas de salas SISU GRB ahora incluye un **sistema de permisos basado en roles** que controla qué usuarios pueden realizar ciertas acciones administrativas.

## 🔐 Tipos de Permisos

### 1. **Permiso de Mantenimiento** (`canManageMaintenance`)

Este permiso permite a ciertos usuarios gestionar el estado de mantenimiento de las salas.

#### Usuarios con este permiso pueden:
- Poner salas en estado de "Mantenimiento"
- Sacar salas del estado de "Mantenimiento" y devolverlas a "Libre"
- Ver el panel de "Gestión de Mantenimiento" en la interfaz

#### Usuarios sin este permiso:
- NO ven el panel de mantenimiento
- NO pueden cambiar el estado de mantenimiento de las salas
- Recibirán un error 403 si intentan hacer cambios mediante la API

## 👤 Cómo Otorgar Permisos de Mantenimiento

### Opción 1: Para Usuarios Existentes en la Base de Datos

1. **Accede al Admin Debug Panel** (botón morado "Admin Debug" en la esquina inferior derecha)
2. Selecciona "Ver Datos Brutos" 
3. Busca el usuario al que quieres otorgar permisos
4. **Necesitarás actualizar el usuario manualmente mediante código**

### Opción 2: Agregar el Permiso Directamente en el Código del Servidor

Edita el archivo `/supabase/functions/server/index.tsx`:

```typescript
// Buscar el array INITIAL_USERS y agregar el permiso
const INITIAL_USERS: User[] = [
  // ... otros usuarios ...
  {
    id: 4,
    username: 'azuread\\jlpimienta',
    displayName: 'José Luis Pimienta',
    email: 'jlpimienta@sisugrb.com',
    teamId: 5,
    team: { id: 5, name: 'Operaciones', color: '#8B5CF6' },
    role: 'Supervisor de Mantenimiento',
    canManageMaintenance: true,  // ← ESTE CAMPO OTORGA EL PERMISO
    createdAt: new Date().toISOString()
  }
];
```

### Opción 3: Crear un Endpoint de Administración (RECOMENDADO PARA PRODUCCIÓN)

Puedes crear un endpoint en el backend para actualizar permisos:

```typescript
// Agregar en /supabase/functions/server/index.tsx

app.put('/make-server-f5c6167b/api/users/:id/permissions', async (c) => {
  try {
    const userId = c.req.param('id');
    const { canManageMaintenance } = await c.req.json();
    
    // IMPORTANTE: Agregar autenticación de administrador aquí
    // Solo ciertos usuarios deberían poder cambiar permisos
    
    const user = await kv.get(`user:${userId}`);
    if (!user) {
      return c.json({ error: 'Usuario no encontrado' }, 404);
    }

    const updatedUser = {
      ...user,
      canManageMaintenance
    };

    await kv.set(`user:${userId}`, updatedUser);
    return c.json(updatedUser);
  } catch (error) {
    console.error('Error actualizando permisos:', error);
    return c.json({ error: 'Error al actualizar permisos' }, 500);
  }
});
```

## 🛡️ Seguridad

### Reglas de Negocio Implementadas:

1. **Cancelación de Reservas**
   - ✅ Solo el usuario que creó una reserva puede cancelarla
   - ❌ Otros usuarios NO pueden cancelar reservas ajenas (error 403)

2. **Gestión de Mantenimiento**
   - ✅ Solo usuarios con `canManageMaintenance: true` pueden gestionar el mantenimiento
   - ❌ Usuarios sin permiso reciben error 403 al intentar cambiar el estado

3. **Validación en Backend**
   - Todas las operaciones críticas se validan en el servidor
   - Los permisos se verifican comparando el `userId` del request con los permisos almacenados en la base de datos

## 📝 Usuarios Actuales con Permisos Especiales

| Usuario | ID | Equipo | Permisos |
|---------|-------|--------|----------|
| José Luis Pimienta | 4 | Operaciones | `canManageMaintenance: true` |

## 🔧 Debugging de Permisos

### Ver el Usuario Actual en la Consola del Navegador

Abre DevTools → Console y ejecuta:
```javascript
JSON.parse(localStorage.getItem('sisugrb_current_user'))
```

Esto mostrará el objeto del usuario actual, incluyendo sus permisos.

### Ver Logs del Servidor

Los logs del backend mostrarán información detallada sobre:
- Validaciones de permisos
- Intentos de acceso no autorizados
- Comparaciones de userId

## ⚠️ Notas Importantes

1. **No usar IDs hardcodeados**: El sistema anterior usaba `userId === 4` para verificar permisos. Esto ha sido reemplazado por el campo `canManageMaintenance`.

2. **Permisos persisten en la base de datos**: Una vez otorgados, los permisos se mantienen hasta que sean revocados manualmente.

3. **Auto-login de nuevos usuarios**: Los usuarios que se crean automáticamente mediante Azure AD NO tienen permisos de mantenimiento por defecto. Estos deben ser otorgados manualmente.

## 🚀 Próximos Pasos para Producción

Antes de desplegar en producción, considera implementar:

1. **Panel de Administración de Usuarios**
   - Interfaz para gestionar permisos sin editar código
   - Lista de todos los usuarios con sus permisos actuales
   - Botones para otorgar/revocar permisos

2. **Roles Jerárquicos**
   - Super Admin
   - Admin de Mantenimiento
   - Usuario Regular

3. **Auditoría**
   - Log de quién otorgó permisos a quién
   - Registro de cambios de permisos

4. **Autenticación Mejorada**
   - Verificar que solo Super Admins puedan cambiar permisos
   - Protección contra escalada de privilegios
