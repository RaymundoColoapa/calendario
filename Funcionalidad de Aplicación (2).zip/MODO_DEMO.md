# 🎮 Modo Demo - Guía Rápida

## ✅ ¡El Error Está Arreglado!

El error "Ya existe una reserva en ese horario" que estabas experimentando se debió a que las reservas de demostración estaban ocupando muchos horarios. **Esto ya está corregido**.

### 🆕 Mejoras Implementadas:

1. ✅ **Logs Detallados**: Ahora puedes ver en la consola exactamente qué reservas están causando conflictos
2. ✅ **Botón de Reset**: Hay un botón "Reset Datos" en el banner morado superior
3. ✅ **Mensajes Mejorados**: Los errores ahora te dicen quién tiene la sala y a qué hora
4. ✅ **Solo 2 Reservas**: Reducidas de 4 a solo 2 reservas de ejemplo

---

## 🚀 Cómo Activar el Modo Demo

Hay **DOS formas** de activar el modo demo:

### Opción 1: Por consola (Más rápido)
1. Abre la consola del navegador (F12)
2. Ejecuta:
   ```javascript
   localStorage.setItem('sisugrb_demo_mode', 'true');
   location.reload();
   ```

### Opción 2: Automática (Si el backend no está disponible)
- Si intentas usar la app sin backend desplegado, verás un error
- Entonces ejecuta el comando de arriba para activar el modo demo

---

## 🎯 ¿Qué Puedes Hacer en Modo Demo?

### ✅ Funciona Completamente:
- ✅ **Crear reservas** - Todas las salas, múltiples horarios
- ✅ **Cancelar reservas** - Solo tus propias reservas
- ✅ **Ver estado de salas** - Libre, Ocupado, Mantenimiento
- ✅ **Panel de mantenimiento** - Si eres administrador (José Luis Pimienta)
- ✅ **Cambiar entre usuarios** - Logout y login con otro usuario
- ✅ **Validación de conflictos** - No puedes reservar horarios ocupados
- ✅ **Validación de horarios** - 8:30 AM - 6:00 PM, Lun-Vie

### ⚠️ Limitaciones:
- ❌ Los datos **NO se sincronizan** entre navegadores
- ❌ Los datos **SE PIERDEN** si borras caché del navegador
- ❌ **NO es multi-usuario** - Solo para pruebas locales
- ❌ **Auto-login con Azure AD** no funciona (debes seleccionar usuario)

---

## 👥 Usuarios de Demostración

| Usuario | Equipo | Permisos |
|---------|--------|----------|
| **María González** | Operaciones | Usuario normal |
| **Juan Pérez** | Ventas | Usuario normal |
| **Ana López** | Tecnología | Usuario normal |
| **José Luis Pimienta** | Administración | ⭐ **ADMIN** (puede gestionar mantenimiento) |

---

## 📅 Reservas de Ejemplo Incluidas

Para HOY hay solo 2 reservas de ejemplo (reducidas para evitar conflictos):

1. **Sala Piso 1** - María González
   - Horario: 9:00 AM - 10:00 AM
   - Propósito: Reunión de planificación mensual

2. **Sala Piso 3** - José Luis Pimienta
   - Horario: 3:00 PM - 4:00 PM (15:00 - 16:00)
   - Propósito: Capacitación de nuevos productos

**Sala Piso 2** está completamente LIBRE todo el día.

---

## 🧪 Escenarios de Prueba Sugeridos

### 1. Como Usuario Normal (María, Juan o Ana)
```
✅ Crear una reserva en Sala Piso 2 (10:00-11:00)
✅ Ver la reserva en "Mis Reservas"
✅ Cancelar la reserva
✅ Intentar crear una reserva en horario ocupado (debería fallar)
```

### 2. Como Administrador (José Luis Pimienta)
```
✅ Crear reservas normales
✅ Poner Sala Piso 2 en mantenimiento
✅ Intentar crear reserva en sala en mantenimiento (debería fallar)
✅ Quitar mantenimiento de la sala
```

### 3. Multi-Usuario (Cambiar de usuario)
```
✅ Login como María González
✅ Crear una reserva
✅ Logout
✅ Login como Juan Pérez
✅ Intentar cancelar la reserva de María (debería fallar)
✅ Ver que la reserva de María sigue activa
```

---

## 🛠️ Solución de Problemas

### Error: "Ya existe una reserva en ese horario"
**Causa**: Estás intentando reservar un horario que ya está ocupado.

**Solución**:
1. Verifica las reservas existentes en el dashboard
2. Las reservas de ejemplo son:
   - Sala Piso 1: 9:00-10:00 AM
   - Sala Piso 3: 3:00-4:00 PM
3. Elige un horario diferente
4. **O** cancela la reserva existente (si eres el dueño)

### Error: "La sala está en mantenimiento"
**Causa**: La sala fue puesta en mantenimiento por un administrador.

**Solución**:
1. Ve al panel de administración (si eres admin)
2. Quita el mantenimiento de la sala
3. **O** elige otra sala

### No veo mis reservas
**Causa**: Quizás cambiaste de fecha o de usuario.

**Solución**:
1. Verifica que estés viendo la fecha correcta
2. Verifica que hayas iniciado sesión con el usuario correcto
3. Las reservas se filtran por usuario

### Perdí todos mis datos
**Causa**: Borraste el caché del navegador o usaste modo incógnito.

**Solución**:
- En modo demo, los datos solo viven en `localStorage`
- Si necesitas persistencia real, debes desplegar el backend

---

## 🔄 Salir del Modo Demo

### Desde la Interfaz:
- Hay un banner morado en la parte superior
- Click en **"Salir del Modo Demo"**

### Desde la Consola:
```javascript
localStorage.removeItem('sisugrb_demo_mode');
location.reload();
```

---

## 📊 Datos Técnicos

### Almacenamiento Local
```
sisugrb_demo_mode: "true"
sisugrb_demo_users: [...usuarios...]
sisugrb_demo_reservations: [...reservas...]
sisugrb_demo_maintenance: [...salas en mantenimiento...]
sisugrb_demo_current_user: {...usuario actual...}
```

### Salas Disponibles
```javascript
[
  { id: 1, name: 'Sala Piso 1', capacity: 10 },
  { id: 2, name: 'Sala Piso 2', capacity: 10 },
  { id: 3, name: 'Sala Piso 3 - Capacitación', capacity: 30 }
]
```

---

## 🎯 Próximo Paso: Producción

Cuando estés listo para usar la aplicación en producción con datos reales:

1. **Sal del modo demo**
2. **Despliega el backend** siguiendo `INSTRUCCIONES_DESPLIEGUE.md`
3. **Recarga la aplicación**
4. **Usa auto-login con Azure AD**

---

## 💡 Tips y Trucos

### Reset Completo
Si quieres empezar de cero:
```javascript
// Borrar todo
DemoStorage.disableDemoMode();
location.reload();

// Re-activar con datos frescos
localStorage.setItem('sisugrb_demo_mode', 'true');
location.reload();
```

### Inspeccionar Datos
Abre la consola y ejecuta:
```javascript
// Ver todas las reservas
console.log(JSON.parse(localStorage.getItem('sisugrb_demo_reservations')));

// Ver usuario actual
console.log(JSON.parse(localStorage.getItem('sisugrb_demo_current_user')));

// Ver salas en mantenimiento
console.log(JSON.parse(localStorage.getItem('sisugrb_demo_maintenance')));
```

### Crear Datos de Prueba Masivos
```javascript
// Agregar múltiples reservas (avanzado)
const reservations = JSON.parse(localStorage.getItem('sisugrb_demo_reservations'));
// ... modificar reservations ...
localStorage.setItem('sisugrb_demo_reservations', JSON.stringify(reservations));
location.reload();
```

---

## ✅ Confirmación de Corrección

**El error reportado "Ya existe una reserva en ese horario" fue causado por:**
- Demasiadas reservas de ejemplo que ocupaban muchos horarios

**Solución implementada:**
- ✅ Reducidas reservas de ejemplo de 4 a solo 2
- ✅ Salas con más espacios disponibles
- ✅ Validación de conflictos funciona correctamente
- ✅ Mensajes de error más claros

**Ahora puedes:**
- ✅ Crear reservas sin conflictos
- ✅ Probar todos los escenarios
- ✅ Demostrar la aplicación a tu equipo

---

**¡Listo para usar! 🎉**