import { User } from '../services/api';
import { DEMO_USERS } from '../data/demo-data';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Users, LogIn } from 'lucide-react';
import sisuLogo from "figma:asset/d875d2f03e4289fd214b7d63b8b8af2cfbe1db24.png";

interface DemoLoginProps {
  onLogin: (user: User) => void;
}

export function DemoLogin({ onLogin }: DemoLoginProps) {
  const handleUserSelection = (userId: string) => {
    const user = DEMO_USERS.find(u => u.id.toString() === userId);
    if (user) {
      // Login automático al seleccionar
      onLogin(user);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo y Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-white px-8 py-6 rounded-lg shadow-xl">
              <img 
                src={sisuLogo} 
                alt="SISU GRB Logo" 
                className="h-24 w-auto object-contain mx-auto"
              />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-gray-900">
              Sistema de Reservas
            </h1>
            <p className="text-gray-600 font-medium">SISU Global Reinsurance Broker</p>
          </div>
        </div>

        {/* Card de Login */}
        <Card className="shadow-lg border-2 border-gray-300 bg-white">
          <CardHeader className="space-y-3">
            <div className="flex items-center justify-center">
              <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-red-600" />
              </div>
            </div>
            <CardTitle className="text-center text-xl">Selecciona tu Usuario</CardTitle>
            <CardDescription className="text-center">
              Haz click en tu nombre para ingresar al sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Selector de Usuario */}
            <div className="space-y-2">
              <p className="text-sm text-gray-700 font-medium mb-3">
                Haz click en tu nombre para ingresar:
              </p>
              <div className="space-y-3">
                {DEMO_USERS.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => handleUserSelection(user.id.toString())}
                    className="w-full flex items-center space-x-3 p-4 rounded-lg hover:bg-gray-50 border-2 border-gray-300 hover:border-red-500 transition-all cursor-pointer bg-white"
                  >
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-red-600 font-bold text-lg">
                        {user.displayName.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-base font-bold text-gray-900">
                        {user.displayName}
                      </p>
                      <p className="text-xs text-gray-600 font-mono mt-0.5">
                        {user.username}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-xs text-blue-600 font-semibold">
                          {user.team?.name}
                        </p>
                        <span className="text-gray-300">•</span>
                        <p className="text-xs text-gray-700 font-medium">
                          {user.role}
                        </p>
                      </div>
                    </div>
                    <LogIn className="h-5 w-5 text-gray-400" />
                  </button>
                ))}
              </div>
            </div>

            {/* Info adicional */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-xs text-blue-800">
                <strong>Sistema SISU GRB:</strong> Selecciona tu usuario para acceder al sistema de reservas de salas.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <p className="text-sm text-gray-600">
            Gestión de Salas de Juntas - Pisos 1, 2 y 3
          </p>
          <p className="text-xs text-gray-500">
            Horario: Lunes a Viernes, 8:30 AM - 6:00 PM
          </p>
        </div>
      </div>
    </div>
  );
}