import { Room, Reservation, User } from '../services/api';
import { RoomCard } from './room-card-dashboard';
import { Calendar } from './ui/calendar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { format, isWeekend } from 'date-fns';
import { es } from 'date-fns/locale';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface RoomDashboardProps {
  rooms: Room[];
  reservations: Reservation[];
  currentUser: User;
  selectedDate: Date;
  onDateChange: (date: Date) => void;
  onReservationCreated: (reservation: Reservation) => void;
}

export function RoomDashboard({
  rooms,
  reservations,
  currentUser,
  selectedDate,
  onDateChange,
  onReservationCreated,
}: RoomDashboardProps) {
  const isWeekendDay = isWeekend(selectedDate);

  return (
    <div className="space-y-6">
      {/* Selector de Fecha */}
      <Card className="border-2 border-gray-300 shadow-md">
        <CardHeader className="bg-gray-100 border-b-2 border-gray-300">
          <CardTitle className="text-lg font-bold text-gray-900">Seleccionar Fecha</CardTitle>
          <CardDescription className="text-gray-600">
            Horario de operación: 8:30 AM - 6:00 PM (Lunes a Viernes)
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-6">
          <div className="flex justify-center">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && onDateChange(date)}
              locale={es}
              disabled={(date) => {
                // Deshabilitar fines de semana y días pasados
                return isWeekend(date) || date < new Date(new Date().setHours(0, 0, 0, 0));
              }}
              className="rounded-lg border-2 border-gray-300 p-4 bg-white"
              classNames={{
                months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
                month: "space-y-4",
                caption: "flex justify-center pt-1 relative items-center text-gray-900",
                caption_label: "text-base font-bold",
                nav: "space-x-1 flex items-center",
                nav_button: "h-8 w-8 bg-transparent p-0 hover:bg-red-100 rounded transition-colors",
                nav_button_previous: "absolute left-1",
                nav_button_next: "absolute right-1",
                table: "w-full border-collapse space-y-1",
                head_row: "flex",
                head_cell: "text-gray-600 rounded-md w-10 font-semibold text-sm",
                row: "flex w-full mt-2",
                cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-red-50 first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
                day: "h-10 w-10 p-0 font-medium aria-selected:opacity-100 hover:bg-gray-100 rounded-md transition-colors",
                day_selected: "bg-red-600 text-white hover:bg-red-700 hover:text-white focus:bg-red-600 focus:text-white font-bold",
                day_today: "bg-gray-200 text-gray-900 font-bold border-2 border-gray-400",
                day_outside: "text-gray-300 opacity-50",
                day_disabled: "text-gray-300 opacity-30",
                day_range_middle: "aria-selected:bg-red-50 aria-selected:text-gray-900",
                day_hidden: "invisible",
              }}
            />
          </div>
          {isWeekendDay && (
            <Alert variant="destructive" className="mt-4 border-2 border-red-300 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 font-medium">
                Las salas solo están disponibles de lunes a viernes
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* DASHBOARD DE ESTADO DE SALAS */}
      <div className="bg-white rounded-lg shadow-md border-2 border-gray-300 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900">
            Estado de las Salas
          </h2>
          <div className="text-right">
            <p className="text-sm text-gray-600">
              {format(selectedDate, "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
            </p>
          </div>
        </div>

        {/* Indicadores de estado visual */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gray-100 border-2 border-gray-500 text-gray-800 p-4 rounded-lg text-center">
            <div className="text-3xl font-bold">{rooms.filter(r => r.status === 'Libre').length}</div>
            <div className="text-sm font-semibold mt-1">Salas Libres</div>
          </div>
          <div className="bg-red-50 border-2 border-red-500 text-red-800 p-4 rounded-lg text-center">
            <div className="text-3xl font-bold">{rooms.filter(r => r.status === 'Ocupado').length}</div>
            <div className="text-sm font-semibold mt-1">Salas Ocupadas</div>
          </div>
          <div className="bg-blue-50 border-2 border-blue-500 text-blue-800 p-4 rounded-lg text-center">
            <div className="text-3xl font-bold">{reservations.length}</div>
            <div className="text-sm font-semibold mt-1">Reservas Hoy</div>
          </div>
        </div>
      </div>

      {/* Grid de Salas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rooms.map((room) => {
          const roomReservations = reservations.filter(r => r.roomId === room.id);
          return (
            <RoomCard
              key={room.id}
              room={room}
              reservations={roomReservations}
              currentUser={currentUser}
              selectedDate={selectedDate}
              onReservationCreated={onReservationCreated}
              disabled={isWeekendDay}
            />
          );
        })}
      </div>
    </div>
  );
}