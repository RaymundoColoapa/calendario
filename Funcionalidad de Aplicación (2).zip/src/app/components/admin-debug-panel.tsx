import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Trash2, RefreshCw, Database, AlertTriangle } from 'lucide-react';
import { api } from '../services/api';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Badge } from './ui/badge';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface Reservation {
  id: number;
  roomId: number;
  userId: number;
  startTime: string;
  endTime: string;
  purpose: string;
  status: string;
  createdAt: string;
  user?: any;
  room?: any;
}

export function AdminDebugPanel() {
  const [open, setOpen] = useState(false);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [rawReservations, setRawReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [showRaw, setShowRaw] = useState(false);

  const loadAllReservations = async () => {
    try {
      setLoading(true);
      const data = await api.getReservations();
      setReservations(data);
      
      // También cargar las reservas crudas del endpoint de debug
      const rawResponse = await fetch(
        'https://czbdjnjywggqkxsbmnmc.supabase.co/functions/v1/make-server-f5c6167b/api/debug/reservations',
        {
          headers: {
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6YmRqbmp5d2dncWt4c2Jtbm1jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkyMjE4MzQsImV4cCI6MjA1NDc5NzgzNH0.Fpp3XPZh0_1wZr8mQ6KVKUpzqvqC7omewW5gPd1VVYI',
          }
        }
      );
      const rawData = await rawResponse.json();
      setRawReservations(rawData.reservations || []);
      
      console.log('📊 Reservas cargadas:', data.length);
      console.log('📊 Reservas crudas:', rawData.reservations?.length || 0);
    } catch (error) {
      console.error('Error cargando reservas:', error);
      toast.error('Error al cargar reservas');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      loadAllReservations();
    }
  }, [open]);

  const clearAllReservations = async () => {
    if (!confirm('¿Estás seguro de eliminar TODAS las reservas? Esta acción no se puede deshacer.')) {
      return;
    }

    try {
      setClearing(true);
      
      const response = await fetch(
        'https://czbdjnjywggqkxsbmnmc.supabase.co/functions/v1/make-server-f5c6167b/api/reservations/admin/clear-all',
        {
          method: 'DELETE',
          headers: {
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6YmRqbmp5d2dncWt4c2Jtbm1jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkyMjE4MzQsImV4cCI6MjA1NDc5NzgzNH0.Fpp3XPZh0_1wZr8mQ6KVKUpzqvqC7omewW5gPd1VVYI',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ adminKey: 'sisugrb-admin-2026' })
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success(`${data.count} reservas eliminadas exitosamente`);
        loadAllReservations();
      } else {
        toast.error(data.error || 'Error al limpiar reservas');
      }
    } catch (error) {
      console.error('Error limpiando reservas:', error);
      toast.error('Error al limpiar reservas');
    } finally {
      setClearing(false);
    }
  };

  return (
    <>
      {/* Botón flotante en la esquina */}
      <Button
        onClick={() => setOpen(true)}
        className="fixed bottom-4 left-4 bg-purple-600 hover:bg-purple-700 text-white shadow-lg z-50"
        size="sm"
      >
        <Database className="h-4 w-4 mr-2" />
        Admin Debug
      </Button>

      {/* Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Database className="h-5 w-5 text-purple-600" />
              Panel de Administración - Debug
            </DialogTitle>
            <DialogDescription>
              Ver y limpiar todas las reservas del sistema
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Acciones */}
            <div className="flex gap-3">
              <Button
                onClick={loadAllReservations}
                disabled={loading}
                variant="outline"
                size="sm"
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Recargar
              </Button>
              <Button
                onClick={clearAllReservations}
                disabled={clearing || reservations.length === 0}
                variant="destructive"
                size="sm"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Eliminar Todas ({reservations.length})
              </Button>
            </div>

            {/* Estadísticas */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Estadísticas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">{reservations.length}</p>
                    <p className="text-xs text-gray-600">Total Reservas</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">
                      {reservations.filter(r => r.status === 'Active').length}
                    </p>
                    <p className="text-xs text-gray-600">Activas</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-600">
                      {reservations.filter(r => r.status !== 'Active').length}
                    </p>
                    <p className="text-xs text-gray-600">Canceladas</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Advertencia si hay muchas reservas */}
            {reservations.length > 10 && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-yellow-900">
                    Hay {reservations.length} reservas en el sistema
                  </p>
                  <p className="text-xs text-yellow-800">
                    Si estás viendo errores de conflicto, considera limpiar las reservas viejas.
                  </p>
                </div>
              </div>
            )}

            {/* Lista de reservas */}
            <div>
              <h3 className="font-semibold text-sm mb-3 text-gray-700">
                Todas las Reservas ({reservations.length})
              </h3>
              
              {loading ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Cargando...</p>
                </div>
              ) : reservations.length === 0 ? (
                <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
                  <Database className="h-12 w-12 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 font-medium">No hay reservas</p>
                  <p className="text-xs text-gray-500 mt-1">La base de datos está limpia</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {reservations.map((reservation) => {
                    const startDate = new Date(reservation.startTime);
                    const endDate = new Date(reservation.endTime);
                    const isPast = endDate < new Date();
                    
                    return (
                      <Card key={reservation.id} className={`${isPast ? 'bg-gray-50 opacity-75' : ''}`}>
                        <CardContent className="py-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center gap-2">
                                <Badge 
                                  className={
                                    reservation.status === 'Active' 
                                      ? 'bg-green-600 text-white text-xs' 
                                      : 'bg-gray-500 text-white text-xs'
                                  }
                                >
                                  {reservation.status}
                                </Badge>
                                <span className="text-xs font-mono text-gray-500">
                                  ID: {reservation.id}
                                </span>
                                {isPast && (
                                  <Badge variant="outline" className="text-xs">
                                    Pasada
                                  </Badge>
                                )}
                              </div>
                              
                              <div className="flex items-center gap-4 text-sm">
                                <div>
                                  <p className="font-semibold text-gray-900">
                                    {reservation.room?.name || `Sala ${reservation.roomId}`}
                                  </p>
                                  <p className="text-xs text-gray-600">
                                    {reservation.user?.displayName || `Usuario ${reservation.userId}`}
                                  </p>
                                </div>
                                <div className="text-xs text-gray-700">
                                  <p className="font-medium">
                                    {format(startDate, "d 'de' MMMM, yyyy", { locale: es })}
                                  </p>
                                  <p>
                                    {format(startDate, 'HH:mm')} - {format(endDate, 'HH:mm')}
                                  </p>
                                </div>
                              </div>
                              
                              <p className="text-xs text-gray-600 italic">
                                {reservation.purpose}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}