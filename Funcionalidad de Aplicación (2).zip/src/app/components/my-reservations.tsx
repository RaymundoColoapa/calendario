import { useState } from 'react';
import { User, Reservation, api } from '../services/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { toast } from 'sonner';
import { format, isPast, isFuture, isToday } from 'date-fns';
import { es } from 'date-fns/locale';
import { Calendar, Clock, MapPin, Trash2, Loader2, X } from 'lucide-react';

interface MyReservationsProps {
  currentUser: User;
  reservations: Reservation[];
  onReservationCancelled: (reservationId: number) => void;
}

export function MyReservations({ currentUser, reservations, onReservationCancelled }: MyReservationsProps) {
  const [cancellingId, setCancellingId] = useState<number | null>(null);
  const [reservationToCancel, setReservationToCancel] = useState<Reservation | null>(null);

  const handleCancelReservation = async (reservation: Reservation) => {
    try {
      setCancellingId(reservation.id);
      
      // Cancelar la reserva en el backend - PASAR EL userId
      await api.cancelReservation(reservation.id, currentUser.id);
      
      toast.success('Reserva cancelada', {
        description: `${reservation.room?.name} - ${format(new Date(reservation.startTime), "d/MM/yyyy 'a las' HH:mm")}`,
      });
      
      onReservationCancelled(reservation.id);
      setReservationToCancel(null);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error al cancelar la reserva';
      toast.error('Error', {
        description: errorMessage,
      });
    } finally {
      setCancellingId(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Active':
        return <Badge className="bg-gray-200 text-gray-800 font-semibold">Activa</Badge>;
      case 'Completed':
        return <Badge className="bg-gray-100 text-gray-800">Completada</Badge>;
      case 'Cancelled':
        return <Badge className="bg-red-100 text-red-800">Cancelada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const canCancelReservation = (reservation: Reservation) => {
    // Solo se puede cancelar si el estado es Active (sin importar la fecha/hora)
    return reservation.status === 'Active';
  };

  // Separar reservas en activas/futuras y pasadas/canceladas
  const activeReservations = reservations.filter(r => {
    // Mostrar todas las reservas con estado Active, sin importar la fecha/hora
    return r.status === 'Active';
  });
  
  const pastReservations = reservations.filter(r => {
    // Solo mostrar en historial las que están canceladas o completadas
    return r.status === 'Cancelled' || r.status === 'Completed';
  });

  if (reservations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Mis Reservas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Calendar className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No tienes reservas</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-2 border-gray-300 shadow-md">
        <CardHeader className="bg-gray-100 border-b-2 border-gray-300">
          <CardTitle className="text-lg font-bold text-gray-900">Mis Reservas</CardTitle>
          <CardDescription className="text-gray-600">
            Solo tú puedes cancelar tus propias reservas
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {reservations.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
              <Calendar className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <p className="text-gray-600 font-medium">No tienes reservas activas</p>
              <p className="text-gray-500 text-sm mt-1">Selecciona una fecha y reserva una sala</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Reservas Activas */}
              {activeReservations.length > 0 && (
                <div>
                  <div className="bg-gray-600 text-white p-3 rounded-t-md flex items-center justify-between">
                    <h3 className="text-base font-bold">
                      Próximas Reservas ({activeReservations.length})
                    </h3>
                  </div>
                  <div className="space-y-3 p-4 bg-gray-100 rounded-b-md border-2 border-gray-600 border-t-0">
                    {activeReservations.map((reservation) => (
                      <div
                        key={reservation.id}
                        className="border-2 border-gray-300 rounded-lg p-4 bg-white hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <div className="bg-red-600 text-white px-3 py-1 rounded-md font-bold text-sm">
                                {reservation.room?.name || 'Sala'}
                              </div>
                              {isToday(new Date(reservation.startTime)) && (
                                <Badge className="bg-yellow-500 text-white font-semibold text-xs">
                                  HOY
                                </Badge>
                              )}
                            </div>
                            <p className="text-gray-800 font-semibold">
                              {reservation.purpose}
                            </p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3 mb-3">
                          <div className="bg-blue-50 p-2 rounded-md border border-blue-200">
                            <p className="text-xs text-blue-700 font-medium mb-1">Fecha</p>
                            <p className="text-blue-900 font-semibold text-sm">
                              {format(new Date(reservation.startTime), "d 'de' MMMM, yyyy", { locale: es })}
                            </p>
                          </div>
                          <div className="bg-purple-50 p-2 rounded-md border border-purple-200">
                            <p className="text-xs text-purple-700 font-medium mb-1">Horario</p>
                            <p className="text-purple-900 font-semibold text-sm">
                              {format(new Date(reservation.startTime), 'HH:mm')} - 
                              {format(new Date(reservation.endTime), 'HH:mm')}
                            </p>
                          </div>
                        </div>

                        {/* Botón de cancelar */}
                        {canCancelReservation(reservation) && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setReservationToCancel(reservation)}
                            disabled={cancellingId === reservation.id}
                            className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold"
                          >
                            {cancellingId === reservation.id ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Cancelando...
                              </>
                            ) : (
                              <>
                                <X className="mr-2 h-4 w-4" />
                                Cancelar Reserva
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reservas Pasadas/Canceladas */}
              {pastReservations.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">
                    Historial ({pastReservations.length})
                  </h3>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {pastReservations.map((reservation) => (
                      <div
                        key={reservation.id}
                        className="border border-gray-200 rounded-lg p-4 bg-gray-50 opacity-75"
                      >
                        <div className="space-y-2">
                          {/* Sala */}
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-gray-400" />
                            <span className="font-semibold text-gray-700">
                              {reservation.room?.name || 'Sala desconocida'}
                            </span>
                            {getStatusBadge(reservation.status)}
                          </div>

                          {/* Fecha y Hora */}
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span>
                              {format(new Date(reservation.startTime), "d/MM/yyyy")}
                            </span>
                            <span>
                              {format(new Date(reservation.startTime), 'HH:mm')} - 
                              {format(new Date(reservation.endTime), 'HH:mm')}
                            </span>
                          </div>

                          {/* Propósito */}
                          <p className="text-xs text-gray-600">
                            {reservation.purpose}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diálogo de confirmación para cancelar */}
      <AlertDialog
        open={!!reservationToCancel}
        onOpenChange={(open) => !open && setReservationToCancel(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Cancelar esta reserva?</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2">
                <p>Estás por cancelar la siguiente reserva:</p>
                {reservationToCancel && (
                  <div className="bg-gray-50 rounded-lg p-3 space-y-1 text-sm">
                    <p><strong>Sala:</strong> {reservationToCancel.room?.name}</p>
                    <p>
                      <strong>Fecha:</strong>{' '}
                      {format(new Date(reservationToCancel.startTime), "d 'de' MMMM 'de' yyyy", {
                        locale: es,
                      })}
                    </p>
                    <p>
                      <strong>Hora:</strong>{' '}
                      {format(new Date(reservationToCancel.startTime), 'HH:mm')} - 
                      {format(new Date(reservationToCancel.endTime), 'HH:mm')}
                    </p>
                    <p><strong>Motivo:</strong> {reservationToCancel.purpose}</p>
                  </div>
                )}
                <p className="text-red-600 font-medium">
                  Esta acción no se puede deshacer.
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No, mantener reserva</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => reservationToCancel && handleCancelReservation(reservationToCancel)}
              className="bg-red-600 hover:bg-red-700"
            >
              Sí, cancelar reserva
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}