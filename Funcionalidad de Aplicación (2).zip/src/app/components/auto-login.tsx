import { useEffect, useState } from 'react';
import { User, api } from '../services/api';
import { DemoStorage, demoUsers } from '../services/demo-data';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Loader2, User as UserIcon, AlertCircle, HelpCircle, PlayCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import sisuLogo from "figma:asset/d875d2f03e4289fd214b7d63b8b8af2cfbe1db24.png";
import { Alert, AlertDescription } from './ui/alert';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "./ui/collapsible";

interface AutoLoginProps {
  onLogin: (user: User) => void;
}

export function AutoLogin({ onLogin }: AutoLoginProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [manualLogin, setManualLogin] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [formData, setFormData] = useState({
    displayName: '',
    email: ''
  });

  useEffect(() => {
    attemptAutoLogin();
  }, []);

  const attemptAutoLogin = async () => {
    try {
      // Intentar obtener información del usuario guardado
      const detectedUsername = await detectWindowsUser();
      
      if (detectedUsername) {
        // Auto-login con usuario detectado
        const user = await api.autoLogin(
          detectedUsername.username,
          detectedUsername.displayName,
          detectedUsername.email
        );
        onLogin(user);
      } else {
        // No se pudo detectar, mostrar login manual
        setManualLogin(true);
        setLoading(false);
      }
    } catch (err: any) {
      console.error('Error en auto-login:', err);
      setError(err.message);
      setManualLogin(true);
      setLoading(false);
    }
  };

  const detectWindowsUser = async (): Promise<{ username: string; displayName: string; email: string } | null> => {
    try {
      // Verificar si hay usuario guardado en localStorage
      const savedUser = await api.getCurrentUser();
      if (savedUser && savedUser.username) {
        return {
          username: savedUser.username,
          displayName: savedUser.displayName,
          email: savedUser.email || ''
        };
      }
      
      return null;
    } catch {
      return null;
    }
  };

  const generateUsername = (displayName: string, email: string): string => {
    // Si hay email, usar la parte antes del @
    if (email && email.includes('@')) {
      const emailUsername = email.split('@')[0].toLowerCase();
      return `azuread\\${emailUsername}`;
    }
    
    // Si no hay email, generar desde el nombre
    // Ejemplo: "Juan Pérez González" -> "jperez"
    const names = displayName.trim().toLowerCase().split(' ');
    if (names.length >= 2) {
      const firstName = names[0];
      const lastName = names[1];
      const username = firstName[0] + lastName;
      return `azuread\\${username}`;
    }
    
    // Si solo hay un nombre, usar ese
    const username = displayName.trim().toLowerCase().replace(/\s+/g, '');
    return `azuread\\${username}`;
  };

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Validaciones
      if (!formData.displayName.trim()) {
        setError('Por favor ingresa tu nombre completo');
        setLoading(false);
        return;
      }

      if (!formData.email.trim()) {
        setError('Por favor ingresa tu email corporativo');
        setLoading(false);
        return;
      }

      // Validar formato de email
      if (!formData.email.includes('@') || !formData.email.includes('.')) {
        setError('Por favor ingresa un email válido');
        setLoading(false);
        return;
      }

      // Auto-generar username desde el email
      const username = generateUsername(formData.displayName, formData.email);

      console.log('Generando usuario:', username);

      const user = await api.autoLogin(
        username,
        formData.displayName.trim(),
        formData.email.trim()
      );
      
      onLogin(user);
    } catch (err: any) {
      console.error('Error en login manual:', err);
      setError(err.message || 'Error al iniciar sesión');
      setLoading(false);
    }
  };

  if (loading && !manualLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center p-4">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-white px-8 py-6 rounded-lg shadow-xl">
              <img 
                src={sisuLogo} 
                alt="SISU GRB Logo" 
                className="h-24 w-auto object-contain mx-auto"
              />
            </div>
          </div>
          <Loader2 className="h-12 w-12 animate-spin text-red-600 mx-auto" />
          <p className="text-gray-700 font-medium text-lg">
            Verificando sesión...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo y Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-white px-8 py-6 rounded-lg shadow-xl">
              <img 
                src={sisuLogo} 
                alt="SISU GRB Logo" 
                className="h-24 w-auto object-contain mx-auto"
              />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-gray-900">
              Sistema de Reservas
            </h1>
            <p className="text-gray-600 font-medium">SISU Global Reinsurance Broker</p>
          </div>
        </div>

        {/* Card de Login Manual */}
        <Card className="shadow-lg border-2 border-gray-300 bg-white">
          <CardHeader className="space-y-3">
            <div className="flex items-center justify-center">
              <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center">
                <UserIcon className="h-6 w-6 text-red-600" />
              </div>
            </div>
            <CardTitle className="text-center text-xl">Bienvenido</CardTitle>
            <CardDescription className="text-center">
              Primera vez: Ingresa tus datos para registrarte
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleManualLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="displayName">Nombre Completo *</Label>
                <Input
                  id="displayName"
                  required
                  value={formData.displayName}
                  onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                  placeholder="Ej: María González López"
                  autoFocus
                  className="text-base"
                />
                <p className="text-xs text-gray-500">
                  Tu nombre como aparece en tu correo
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email Corporativo *</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Ej: mgonzalez@sisugrb.com"
                  className="text-base"
                />
                <p className="text-xs text-gray-500">
                  Tu correo de SISU GRB
                </p>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-red-600 hover:bg-red-700 h-12 text-base font-semibold"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Registrando...
                  </>
                ) : (
                  'Ingresar al Sistema'
                )}
              </Button>
            </form>

            {/* Info adicional */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900 font-medium mb-2">
                ℹ️ Primera vez en el sistema:
              </p>
              <ul className="text-xs text-blue-800 space-y-1 list-disc list-inside">
                <li>Tu usuario se creará automáticamente</li>
                <li>Serás asignado al equipo de Operaciones</li>
                <li>La próxima vez entrarás automáticamente</li>
                <li>Un administrador puede cambiar tu equipo después</li>
              </ul>
            </div>

            {/* Ayuda para encontrar usuario Windows */}
            <Collapsible open={showHelp} onOpenChange={setShowHelp}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full text-gray-600 hover:text-gray-900">
                  <HelpCircle className="h-4 w-4 mr-2" />
                  ¿Necesitas ayuda para encontrar tu usuario de Windows?
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-3">
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-3">
                  <p className="text-sm font-semibold text-gray-900">
                    Cómo encontrar tu usuario de Windows:
                  </p>
                  
                  <div className="space-y-2">
                    <p className="text-xs text-gray-700 font-medium">Opción 1: Botón Inicio</p>
                    <ol className="text-xs text-gray-600 list-decimal list-inside space-y-1 ml-2">
                      <li>Click en el botón de Inicio (esquina inferior izquierda)</li>
                      <li>Verás tu nombre arriba del menú</li>
                      <li>El usuario es la parte antes del @</li>
                    </ol>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs text-gray-700 font-medium">Opción 2: Símbolo del Sistema</p>
                    <ol className="text-xs text-gray-600 list-decimal list-inside space-y-1 ml-2">
                      <li>Presiona tecla Windows + R</li>
                      <li>Escribe: <code className="bg-gray-200 px-1">cmd</code></li>
                      <li>Escribe: <code className="bg-gray-200 px-1">whoami</code></li>
                      <li>Verás algo como: <code className="bg-gray-200 px-1">azuread\tuusuario</code></li>
                    </ol>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mt-3">
                    <p className="text-xs text-yellow-800">
                      <strong>💡 Más fácil:</strong> Simplemente usa tu email corporativo. 
                      La parte antes del @ es tu usuario. Ejemplo: si tu email es 
                      <strong> jperez@sisugrb.com</strong>, tu usuario es <strong>jperez</strong>
                    </p>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <p className="text-sm text-gray-600">
            Gestión de Salas de Juntas - Pisos 1, 2 y 3
          </p>
          <p className="text-xs text-gray-500">
            Horario: Lunes a Viernes, 8:30 AM - 6:00 PM
          </p>
        </div>
      </div>
    </div>
  );
}