import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/app/components/ui/dialog";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Textarea } from "@/app/components/ui/textarea";
import { Room, Reservation, TeamMember, ServiceType } from "@/app/types";
import { useState, useRef, useEffect } from "react";
import { Calendar, Clock, User, Mail, Users, Coffee, ChevronDown } from "lucide-react";
import { Badge } from "@/app/components/ui/badge";

interface QuickReservationFormProps {
  room: Room | null;
  teamMembers: TeamMember[];
  currentUser: TeamMember;
  onClose: () => void;
  onSubmit: (reservation: Omit<Reservation, "id">) => void;
  existingReservations?: Reservation[];
}

export function QuickReservationForm({
  room,
  teamMembers,
  currentUser,
  onClose,
  onSubmit,
  existingReservations = [],
}: QuickReservationFormProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    date: new Date().toISOString().split("T")[0],
    startTime: "09:00",
    endTime: "10:00",
    organizerName: currentUser.name,
    organizerEmail: currentUser.email,
  });

  const [openOrganizer, setOpenOrganizer] = useState(false);
  const [openAttendees, setOpenAttendees] = useState(false);
  const [searchOrganizer, setSearchOrganizer] = useState("");
  const [searchAttendees, setSearchAttendees] = useState("");
  const [selectedAttendees, setSelectedAttendees] = useState<TeamMember[]>([]);
  const [selectedServices, setSelectedServices] = useState<ServiceType[]>([]);
  
  const organizerRef = useRef<HTMLDivElement>(null);
  const attendeesRef = useRef<HTMLDivElement>(null);

  const availableServices: ServiceType[] = ["Cafés", "Aguas", "Galletas", "Refrescos", "IdeaShare"];

  // Filtrar miembros del equipo
  const filteredOrganizers = teamMembers.filter((member) =>
    member.name.toLowerCase().includes(searchOrganizer.toLowerCase()) ||
    member.email.toLowerCase().includes(searchOrganizer.toLowerCase())
  );

  const filteredAttendees = teamMembers.filter((member) =>
    member.name.toLowerCase().includes(searchAttendees.toLowerCase()) ||
    member.email.toLowerCase().includes(searchAttendees.toLowerCase())
  );

  // Cerrar dropdowns al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (organizerRef.current && !organizerRef.current.contains(event.target as Node)) {
        setOpenOrganizer(false);
      }
      if (attendeesRef.current && !attendeesRef.current.contains(event.target as Node)) {
        setOpenAttendees(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  
  const handleToggleService = (service: ServiceType) => {
    setSelectedServices((prev) => {
      const exists = prev.includes(service);
      if (exists) {
        return prev.filter((s) => s !== service);
      }
      return [...prev, service];
    });
  };

  const handleSelectOrganizer = (member: TeamMember) => {
    setFormData({
      ...formData,
      organizerName: member.name,
      organizerEmail: member.email,
    });
    setOpenOrganizer(false);
  };

  const handleToggleAttendee = (member: TeamMember) => {
    setSelectedAttendees((prev) => {
      const exists = prev.find((m) => m.id === member.id);
      if (exists) {
        return prev.filter((m) => m.id !== member.id);
      }
      return [...prev, member];
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!room) return;

    // Validar campos requeridos
    if (!formData.organizerName || !formData.title) {
      alert('⚠️ Por favor completa todos los campos requeridos (Organizador y Título).');
      return;
    }

    // Validar día de la semana (solo lunes a viernes)
    const selectedDate = new Date(formData.date + 'T00:00:00');
    const dayOfWeek = selectedDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      alert('⚠️ Las salas solo están disponibles de Lunes a Viernes. Por favor, selecciona un día laboral.');
      return;
    }

    // Validar horario de operación (8:30 AM - 6:00 PM)
    const [startHour, startMin] = formData.startTime.split(':').map(Number);
    const [endHour, endMin] = formData.endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    const openingTime = 8 * 60 + 30;
    const closingTime = 18 * 60;

    if (startMinutes < openingTime || endMinutes > closingTime) {
      alert('⚠️ El horario de operación es de 8:30 AM a 6:00 PM. Por favor, ajusta el horario de tu reserva.');
      return;
    }

    if (startMinutes >= endMinutes) {
      alert('⚠️ La hora de inicio debe ser anterior a la hora de fin.');
      return;
    }

    // Validar conflictos de horario
    const hasConflict = existingReservations.some((existing) => {
      if (existing.roomId !== room.id) return false;
      
      const existingDateStr = new Date(existing.date).toISOString().split('T')[0];
      const newDateStr = formData.date;
      
      if (existingDateStr !== newDateStr) return false;

      const [existingStartHour, existingStartMin] = existing.startTime.split(':').map(Number);
      const [existingEndHour, existingEndMin] = existing.endTime.split(':').map(Number);

      const existingStart = existingStartHour * 60 + existingStartMin;
      const existingEnd = existingEndHour * 60 + existingEndMin;
      const newStart = startMinutes;
      const newEnd = endMinutes;

      return (newStart < existingEnd && newEnd > existingStart);
    });

    if (hasConflict) {
      alert('⚠️ Ya existe una reserva en esta sala para el horario seleccionado. Por favor, elige otro horario.');
      return;
    }

    const reservation: Omit<Reservation, "id"> = {
      roomId: room.id,
      title: formData.title,
      description: formData.description,
      startTime: formData.startTime,
      endTime: formData.endTime,
      date: new Date(formData.date + 'T00:00:00'),
      organizer: formData.organizerName,
      organizerEmail: formData.organizerEmail,
      organizerWindowsUsername: currentUser.windowsUsername, // Agregar Windows username
      attendees: selectedAttendees.map((a) => a.name),
      services: selectedServices.length > 0 ? selectedServices : undefined,
    };

    onSubmit(reservation);
    
    // Reset form
    setFormData({
      title: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      startTime: "09:00",
      endTime: "10:00",
      organizerName: currentUser.name,
      organizerEmail: currentUser.email,
    });
    setSelectedAttendees([]);
    setSelectedServices([]);
    
    onClose();
  };

  if (!room) return null;

  return (
    <Dialog open={!!room} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Reservar {room.name}</DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            {room.location} • Capacidad: {room.capacity} personas
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Organizer */}
          <div className="space-y-2">
            <Label className="text-sm font-semibold flex items-center gap-2">
              <User className="size-4" />
              Organizador *
            </Label>
            <div ref={organizerRef} className="relative">
              <Button
                variant="outline"
                role="combobox"
                type="button"
                className="w-full justify-between h-11 text-left font-normal border-neutral-300 hover:border-red-600"
                onClick={() => setOpenOrganizer(!openOrganizer)}
              >
                {formData.organizerName || "Selecciona tu nombre..."}
                <ChevronDown className="size-4" />
              </Button>
              {openOrganizer && (
                <div className="absolute top-full left-0 w-full bg-white border border-gray-300 shadow-md z-10">
                  <Input
                    placeholder="Buscar miembro del equipo..."
                    value={searchOrganizer}
                    onChange={(e) => setSearchOrganizer(e.target.value)}
                    className="w-full px-3 py-2 border-b border-gray-300"
                  />
                  <div className="max-h-40 overflow-y-auto">
                    {filteredOrganizers.length > 0 ? (
                      filteredOrganizers.map((member) => (
                        <div
                          key={member.id}
                          className="flex flex-col items-start py-2.5 cursor-pointer hover:bg-gray-100 px-3"
                          onClick={() => handleSelectOrganizer(member)}
                        >
                          <div className="font-medium text-sm">{member.name}</div>
                          <div className="text-xs text-muted-foreground">{member.email}</div>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-sm text-gray-500">No se encontraron resultados.</div>
                    )}
                  </div>
                </div>
              )}
            </div>
            {formData.organizerEmail && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground pl-2">
                <Mail className="size-4" />
                {formData.organizerEmail}
              </div>
            )}
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-semibold">
              Título de la reunión *
            </Label>
            <Input
              id="title"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Ej: Reunión de equipo, Presentación de proyecto..."
              className="h-11"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-semibold">
              Descripción
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Detalles de la reunión..."
              rows={3}
            />
          </div>

          {/* Date and Time */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date" className="text-sm font-semibold flex items-center gap-2">
                <Calendar className="size-4" />
                Fecha *
              </Label>
              <Input
                id="date"
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="startTime" className="text-sm font-semibold flex items-center gap-2">
                <Clock className="size-4" />
                Inicio *
              </Label>
              <Input
                id="startTime"
                type="time"
                required
                value={formData.startTime}
                onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endTime" className="text-sm font-semibold flex items-center gap-2">
                <Clock className="size-4" />
                Fin *
              </Label>
              <Input
                id="endTime"
                type="time"
                required
                value={formData.endTime}
                onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                className="h-11"
              />
            </div>
          </div>

          {/* Attendees */}
          <div className="space-y-2">
            <Label className="text-sm font-semibold flex items-center gap-2">
              <Users className="size-4" />
              Asistentes
            </Label>
            <div ref={attendeesRef} className="relative">
              <Button
                variant="outline"
                role="combobox"
                type="button"
                className="w-full justify-between h-12 text-left font-normal border-gray-300 hover:border-red-600"
                onClick={() => setOpenAttendees(!openAttendees)}
              >
                {selectedAttendees.length === 0
                  ? "Agregar asistentes..."
                  : `${selectedAttendees.length} asistente${selectedAttendees.length > 1 ? "s" : ""} seleccionado${selectedAttendees.length > 1 ? "s" : ""}`}
                <ChevronDown className="size-4" />
              </Button>
              {openAttendees && (
                <div className="absolute top-full left-0 w-full bg-white border border-gray-300 shadow-md z-10">
                  <Input
                    placeholder="Buscar asistentes..."
                    value={searchAttendees}
                    onChange={(e) => setSearchAttendees(e.target.value)}
                    className="w-full px-3 py-2 border-b border-gray-300"
                  />
                  <div className="max-h-40 overflow-y-auto">
                    {filteredAttendees.length > 0 ? (
                      filteredAttendees.map((member) => {
                        const isSelected = selectedAttendees.find((m) => m.id === member.id);
                        return (
                          <div
                            key={member.id}
                            className="flex items-center gap-3 py-3 cursor-pointer hover:bg-gray-100 px-3"
                            onClick={() => handleToggleAttendee(member)}
                          >
                            <div
                              className={`size-5 rounded border-2 flex items-center justify-center ${
                                isSelected ? "bg-red-600 border-red-600" : "border-gray-400"
                              }`}
                            >
                              {isSelected && (
                                <svg
                                  className="size-3 text-white"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={3}
                                    d="M5 13l4 4L19 7"
                                  />
                                </svg>
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="font-medium">{member.name}</div>
                              <div className="text-sm text-muted-foreground">{member.email}</div>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="p-3 text-sm text-gray-500">No se encontraron resultados.</div>
                    )}
                  </div>
                </div>
              )}
            </div>
            {selectedAttendees.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {selectedAttendees.map((attendee) => (
                  <Badge key={attendee.id} variant="secondary" className="px-3 py-1.5 bg-gray-200 text-gray-700">
                    {attendee.name}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Services */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold flex items-center gap-2">
              <Coffee className="size-4" />
              Servicios para la Junta
            </Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {availableServices.map((service) => {
                const isSelected = selectedServices.includes(service);
                return (
                  <div
                    key={service}
                    onClick={() => handleToggleService(service)}
                    className={`cursor-pointer p-3 rounded-lg border-2 transition-all ${
                      isSelected
                        ? "border-red-600 bg-red-50"
                        : "border-neutral-300 bg-white hover:border-red-400"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={`size-5 rounded border-2 flex items-center justify-center ${
                          isSelected ? "bg-red-600 border-red-600" : "border-gray-400"
                        }`}
                      >
                        {isSelected && (
                          <svg
                            className="size-3 text-white"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={3}
                              d="M5 13l4 4L19 7"
                            />
                          </svg>
                        )}
                      </div>
                      <span className="text-sm font-medium text-neutral-800">{service}</span>
                    </div>
                  </div>
                );
              })}
            </div>
            {selectedServices.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3 p-3 bg-red-50 rounded-lg border border-red-200">
                <span className="text-xs font-medium text-neutral-700">Seleccionados:</span>
                {selectedServices.map((service) => (
                  <Badge key={service} className="bg-red-600 hover:bg-red-700 text-white">
                    {service}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 h-12 border-gray-300">
              Cancelar
            </Button>
            <Button type="submit" className="flex-1 h-12 text-base font-semibold bg-red-600 hover:bg-red-700">
              Confirmar Reserva
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}