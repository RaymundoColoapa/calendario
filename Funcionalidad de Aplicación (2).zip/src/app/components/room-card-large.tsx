import { Room, RoomStatus } from "@/app/types";
import { Button } from "@/app/components/ui/button";
import { Users, MapPin, CalendarPlus, Settings, Clock, CheckCircle, AlertCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/app/components/ui/dialog";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { useState } from "react";

interface RoomCardLargeProps {
  room: Room;
  onReserve: (room: Room) => void;
  onChangeStatus: (roomId: string, status: RoomStatus, maintenanceInfo?: { startTime: string; endTime: string }) => void;
  reservationsToday?: number;
}

// Función para formatear hora en formato 24h con AM/PM
const formatTime = (time: string) => {
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours);
  const period = hour >= 12 ? 'PM' : 'AM';
  return `${time} ${period}`;
};

// Calcular disponibilidad basado en horario de 8:30 AM - 6:00 PM (9.5 horas = 19 slots de 30min)
const calculateAvailability = (reservationsCount: number) => {
  const totalSlots = 19; // 8:30 AM - 6:00 PM en slots de 30 minutos
  const usedSlots = reservationsCount * 2; // Asumiendo cada junta es al menos 1 hora (2 slots)
  const availableSlots = totalSlots - usedSlots;
  
  if (availableSlots <= 0) {
    return { status: 'full', color: 'red', message: 'Completamente Reservado', availableSlots: 0 };
  } else if (availableSlots <= 2) {
    return { status: 'almost-full', color: 'orange', message: `Solo queda ${availableSlots === 1 ? '1 horario' : '2 horarios'}`, availableSlots };
  } else {
    return { status: 'available', color: 'green', message: 'Disponible', availableSlots };
  }
};

export function RoomCardLarge({ room, onReserve, onChangeStatus, reservationsToday }: RoomCardLargeProps) {
  const [open, setOpen] = useState(false);
  const [showMaintenanceForm, setShowMaintenanceForm] = useState(false);
  const [maintenanceStartTime, setMaintenanceStartTime] = useState('09:00');
  const [maintenanceEndTime, setMaintenanceEndTime] = useState('17:00');

  const handleStatusChange = (status: RoomStatus) => {
    if (status === 'maintenance') {
      setShowMaintenanceForm(true);
    } else {
      onChangeStatus(room.id, status);
      setOpen(false);
    }
  };

  const handleMaintenanceSubmit = () => {
    if (!maintenanceStartTime || !maintenanceEndTime) {
      return;
    }
    onChangeStatus(room.id, 'maintenance', {
      startTime: maintenanceStartTime,
      endTime: maintenanceEndTime,
    });
    setShowMaintenanceForm(false);
    setOpen(false);
    setMaintenanceStartTime('09:00');
    setMaintenanceEndTime('17:00');
  };

  const availability = calculateAvailability(reservationsToday || 0);

  return (
    <div
      className={`rounded-2xl shadow-xl overflow-hidden transition-all duration-300 border-2 ${
        room.status === "available"
          ? "border-neutral-400 bg-gradient-to-br from-neutral-50 to-neutral-100"
          : room.status === "occupied"
          ? "border-red-400 bg-gradient-to-br from-red-50 to-red-100"
          : "border-neutral-400 bg-gradient-to-br from-neutral-100 to-neutral-200"
      }`}
    >
      {/* Header */}
      <div
        className={`p-6 ${
          room.status === "available"
            ? "bg-gradient-to-r from-neutral-600 to-neutral-700"
            : room.status === "occupied"
            ? "bg-gradient-to-r from-red-600 to-red-700"
            : "bg-gradient-to-r from-neutral-500 to-neutral-600"
        }`}
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-white">{room.name}</h3>
            <div className="flex items-center gap-2 mt-2">
              <MapPin className="size-5 text-white/90" />
              <p className="text-base text-white/90">{room.location}</p>
            </div>
          </div>
          <div
            className={`px-4 py-2 rounded-full text-sm font-bold uppercase tracking-wide ${
              room.status === "available"
                ? "bg-neutral-900/30 text-white"
                : room.status === "occupied"
                ? "bg-red-900/30 text-white"
                : "bg-neutral-900/40 text-white"
            }`}
          >
            {room.status === "available"
              ? "Disponible"
              : room.status === "occupied"
              ? "Ocupado"
              : "Mantenimiento"}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Users className="size-6 text-white/90" />
          <p className="text-base text-white/90">
            Capacidad: <span className="font-bold text-white">{room.capacity} personas</span>
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="bg-neutral-100 p-8 space-y-6">
        {/* Current Reservation */}
        {room.currentReservation && (
          <div className="bg-red-50 p-5 rounded-xl border-2 border-red-200">
            <p className="text-sm font-medium text-neutral-700 mb-2">
              Reserva Actual
            </p>
            <p className="font-semibold text-lg mb-1 text-neutral-800">{room.currentReservation.title}</p>
            <p className="text-sm text-neutral-700 mb-2">
              {formatTime(room.currentReservation.startTime)} - {formatTime(room.currentReservation.endTime)}
            </p>
            <div className="flex items-center gap-2 mt-3 pt-3 border-t border-red-200">
              <div className="size-8 rounded-full bg-red-600 flex items-center justify-center">
                <span className="text-sm font-semibold text-white">
                  {room.currentReservation.organizer.charAt(0)}
                </span>
              </div>
              <p className="text-sm font-medium text-neutral-800">{room.currentReservation.organizer}</p>
            </div>
          </div>
        )}

        {/* Maintenance Info */}
        {room.status === 'maintenance' && room.maintenanceInfo && (
          <div className="bg-yellow-50 p-5 rounded-xl border-2 border-yellow-300">
            <p className="text-sm font-medium text-neutral-700 mb-2">
              Mantenimiento Programado
            </p>
            <div className="flex items-center gap-2 text-neutral-800">
              <Clock className="size-5 text-yellow-600" />
              <p className="text-base font-semibold">
                {formatTime(room.maintenanceInfo.startTime)} - {formatTime(room.maintenanceInfo.endTime)}
              </p>
            </div>
          </div>
        )}

        {/* Availability Indicator */}
        {room.status === 'available' && (
          <div className={`p-4 rounded-xl border-2 ${
            availability.status === 'full' 
              ? 'bg-red-50 border-red-300' 
              : availability.status === 'almost-full'
              ? 'bg-orange-50 border-orange-300'
              : 'bg-green-50 border-green-300'
          }`}>
            <div className="flex items-center gap-3">
              {availability.status === 'full' ? (
                <AlertCircle className="size-6 text-red-600" />
              ) : availability.status === 'almost-full' ? (
                <AlertCircle className="size-6 text-orange-600" />
              ) : (
                <CheckCircle className="size-6 text-green-600" />
              )}
              <div className="flex-1">
                <p className={`font-semibold text-base ${
                  availability.status === 'full' 
                    ? 'text-red-700' 
                    : availability.status === 'almost-full'
                    ? 'text-orange-700'
                    : 'text-green-700'
                }`}>
                  {availability.message}
                </p>
                <p className="text-sm text-neutral-600">
                  {reservationsToday || 0} reserva{(reservationsToday || 0) !== 1 ? 's' : ''} hoy • Horario: 8:30 AM - 6:00 PM
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={() => onReserve(room)}
            size="lg"
            className="flex-1 h-14 text-lg font-semibold shadow-lg hover:shadow-xl transition-all bg-red-600 hover:bg-red-700 text-white"
          >
            <CalendarPlus className="size-6 mr-3" />
            RESERVAR SALA
          </Button>

          {/* Change Status Dialog */}
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button
                size="lg"
                variant="outline"
                className="h-14 px-5 border-2 border-neutral-400 hover:border-neutral-600 hover:bg-neutral-100"
              >
                <Settings className="size-6 text-neutral-700" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Cambiar Estado - {room.name}</DialogTitle>
                <DialogDescription>
                  Selecciona el nuevo estado de la sala o programa un mantenimiento.
                </DialogDescription>
              </DialogHeader>

              {!showMaintenanceForm ? (
                <div className="space-y-3 py-4">
                  <Button
                    onClick={() => handleStatusChange("available")}
                    variant="outline"
                    className="w-full h-14 text-base font-semibold justify-start border-2 border-neutral-400 hover:border-neutral-600 hover:bg-neutral-50"
                  >
                    <div className="size-4 rounded-full bg-neutral-500 mr-3"></div>
                    Disponible
                  </Button>
                  <Button
                    onClick={() => handleStatusChange("occupied")}
                    variant="outline"
                    className="w-full h-14 text-base font-semibold justify-start border-2 border-red-400 hover:border-red-600 hover:bg-red-50"
                  >
                    <div className="size-4 rounded-full bg-red-600 mr-3"></div>
                    Ocupado
                  </Button>
                  <Button
                    onClick={() => handleStatusChange("maintenance")}
                    variant="outline"
                    className="w-full h-14 text-base font-semibold justify-start border-2 border-yellow-400 hover:border-yellow-600 hover:bg-yellow-50"
                  >
                    <div className="size-4 rounded-full bg-yellow-500 mr-3"></div>
                    Mantenimiento
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="maintenance-start">Hora de Inicio</Label>
                    <Input
                      id="maintenance-start"
                      type="time"
                      value={maintenanceStartTime}
                      onChange={(e) => setMaintenanceStartTime(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maintenance-end">Hora de Fin</Label>
                    <Input
                      id="maintenance-end"
                      type="time"
                      value={maintenanceEndTime}
                      onChange={(e) => setMaintenanceEndTime(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-3 pt-2">
                    <Button
                      variant="outline"
                      onClick={() => setShowMaintenanceForm(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                    <Button
                      onClick={handleMaintenanceSubmit}
                      className="flex-1 bg-yellow-600 hover:bg-yellow-700"
                    >
                      Programar Mantenimiento
                    </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>

        {/* Amenities */}
        <div>
          <p className="text-sm font-medium text-neutral-700 mb-3">Servicios Disponibles</p>
          <div className="flex flex-wrap gap-2">
            {room.amenities.map((amenity) => (
              <span
                key={amenity}
                className="px-3 py-1.5 bg-neutral-200 rounded-full text-sm font-medium text-neutral-800"
              >
                {amenity}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
