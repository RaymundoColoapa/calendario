import { useState } from 'react';
import { Room } from '../services/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { toast } from 'sonner';
import { Wrench, CheckCircle, AlertTriangle } from 'lucide-react';

interface MaintenancePanelProps {
  rooms: Room[];
  onMaintenanceToggle: (roomId: number, inMaintenance: boolean) => void;
}

export function MaintenancePanel({ rooms, onMaintenanceToggle }: MaintenancePanelProps) {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [actionType, setActionType] = useState<'activate' | 'deactivate'>('activate');

  const handleMaintenanceClick = (room: Room, activate: boolean) => {
    setSelectedRoom(room);
    setActionType(activate ? 'activate' : 'deactivate');
  };

  const handleConfirm = () => {
    if (!selectedRoom) return;
    
    const inMaintenance = actionType === 'activate';
    onMaintenanceToggle(selectedRoom.id, inMaintenance);
    
    toast.success(
      inMaintenance ? 'Sala en mantenimiento' : 'Sala disponible',
      {
        description: `${selectedRoom.name} ${inMaintenance ? 'ahora está en mantenimiento' : 'está nuevamente disponible'}`,
      }
    );
    
    setSelectedRoom(null);
  };

  return (
    <>
      <Card className="border-2 border-orange-300 shadow-md">
        <CardHeader className="bg-orange-50 border-b-2 border-orange-300">
          <div className="flex items-center gap-2">
            <Wrench className="h-6 w-6 text-orange-600" />
            <div>
              <CardTitle className="text-lg font-bold text-gray-900">
                Panel de Mantenimiento
              </CardTitle>
              <CardDescription className="text-gray-600">
                Control de estado de mantenimiento de salas
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {rooms.map((room) => {
              const isInMaintenance = room.status === 'Mantenimiento';
              
              return (
                <div
                  key={room.id}
                  className={`border-2 rounded-lg p-4 transition-all ${
                    isInMaintenance
                      ? 'border-orange-400 bg-orange-50'
                      : 'border-gray-300 bg-white hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-bold text-gray-900">{room.name}</h3>
                        {isInMaintenance ? (
                          <Badge className="bg-orange-500 text-white font-semibold">
                            <AlertTriangle className="h-3 w-3 mr-1" />
                            En Mantenimiento
                          </Badge>
                        ) : (
                          <Badge className="bg-green-500 text-white font-semibold">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Disponible
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">
                        Capacidad: {room.capacity} personas • Piso {room.floor}
                      </p>
                    </div>
                    
                    <div>
                      {isInMaintenance ? (
                        <Button
                          onClick={() => handleMaintenanceClick(room, false)}
                          className="bg-green-600 hover:bg-green-700 text-white font-semibold"
                          size="sm"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Finalizar Mantenimiento
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleMaintenanceClick(room, true)}
                          className="bg-orange-600 hover:bg-orange-700 text-white font-semibold"
                          size="sm"
                        >
                          <Wrench className="h-4 w-4 mr-2" />
                          Poner en Mantenimiento
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Diálogo de confirmación */}
      <AlertDialog
        open={!!selectedRoom}
        onOpenChange={(open) => !open && setSelectedRoom(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionType === 'activate'
                ? '¿Poner sala en mantenimiento?'
                : '¿Finalizar mantenimiento?'}
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2">
                {selectedRoom && (
                  <>
                    <p>
                      {actionType === 'activate'
                        ? 'Estás por marcar la siguiente sala como "En Mantenimiento":'
                        : 'Estás por marcar la siguiente sala como "Disponible":'}
                    </p>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="font-semibold text-gray-900">{selectedRoom.name}</p>
                      <p className="text-sm text-gray-600">
                        Capacidad: {selectedRoom.capacity} personas
                      </p>
                    </div>
                    {actionType === 'activate' && (
                      <p className="text-orange-600 font-medium">
                        ⚠️ La sala no estará disponible para reservas mientras esté en mantenimiento.
                      </p>
                    )}
                  </>
                )}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirm}
              className={
                actionType === 'activate'
                  ? 'bg-orange-600 hover:bg-orange-700'
                  : 'bg-green-600 hover:bg-green-700'
              }
            >
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
