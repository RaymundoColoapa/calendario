import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/app/components/ui/dialog";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Textarea } from "@/app/components/ui/textarea";
import { Room, Reservation } from "@/app/types";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { useState } from "react";

interface ReservationFormProps {
  room: Room | null;
  date: Date | null;
  onClose: () => void;
  onSubmit: (reservation: Omit<Reservation, "id">) => void;
}

export function ReservationForm({ room, date, onClose, onSubmit }: ReservationFormProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startTime: "09:00",
    endTime: "10:00",
    organizer: "",
    attendees: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!room || !date) return;

    const reservation: Omit<Reservation, "id"> = {
      roomId: room.id,
      title: formData.title,
      description: formData.description,
      startTime: formData.startTime,
      endTime: formData.endTime,
      date,
      organizer: formData.organizer,
      attendees: formData.attendees.split(",").map((a) => a.trim()).filter(Boolean),
    };

    onSubmit(reservation);
    setFormData({
      title: "",
      description: "",
      startTime: "09:00",
      endTime: "10:00",
      organizer: "",
      attendees: "",
    });
  };

  if (!room || !date) return null;

  return (
    <Dialog open={!!(room && date)} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Nueva Reserva</DialogTitle>
          <p className="text-sm text-muted-foreground">
            {room.name} - {format(date, "d 'de' MMMM, yyyy", { locale: es })}
          </p>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Título de la reunión *</Label>
            <Input
              id="title"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Ej: Reunión de equipo"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descripción</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Detalles adicionales..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime">Hora inicio *</Label>
              <Input
                id="startTime"
                type="time"
                required
                value={formData.startTime}
                onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endTime">Hora fin *</Label>
              <Input
                id="endTime"
                type="time"
                required
                value={formData.endTime}
                onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="organizer">Organizador *</Label>
            <Input
              id="organizer"
              required
              value={formData.organizer}
              onChange={(e) => setFormData({ ...formData, organizer: e.target.value })}
              placeholder="Nombre del organizador"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="attendees">Asistentes</Label>
            <Input
              id="attendees"
              value={formData.attendees}
              onChange={(e) => setFormData({ ...formData, attendees: e.target.value })}
              placeholder="Separados por comas"
            />
            <p className="text-xs text-muted-foreground">
              Ej: Juan Pérez, María García, Carlos López
            </p>
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
            <Button type="submit" className="flex-1">
              Crear Reserva
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
