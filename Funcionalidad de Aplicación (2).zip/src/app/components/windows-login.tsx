import { useState } from "react";
import { TeamMember } from "@/app/types";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Shield, AlertCircle } from "lucide-react";
import logo from "figma:asset/4562cf8a6debeed3977bf0f0ca94cfc147e69f16.png";

interface WindowsLoginProps {
  teamMembers: TeamMember[];
  onLogin: (user: TeamMember) => void;
}

export function WindowsLogin({ teamMembers, onLogin }: WindowsLoginProps) {
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Simular delay de autenticación
    setTimeout(() => {
      // Buscar usuario por windowsUsername (case insensitive)
      const user = teamMembers.find(
        (member) => member.windowsUsername.toLowerCase() === username.toLowerCase()
      );

      if (user) {
        // Guardar en localStorage para persistencia
        localStorage.setItem("sisugrb_windows_user", JSON.stringify(user));
        onLogin(user);
      } else {
        setError("Usuario de Windows no encontrado en el sistema SISU GRB");
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-100 via-neutral-200 to-red-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo y Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img src={logo} alt="SISU GRB Logo" className="h-20 w-auto" />
          </div>
          <h1 className="text-3xl font-bold text-neutral-800 mb-2">
            Sistema de Reservas
          </h1>
          <p className="text-neutral-600">SISU GRB</p>
        </div>

        {/* Card de Login */}
        <div className="bg-white rounded-2xl shadow-2xl p-8 border-2 border-neutral-300">
          <div className="flex items-center gap-3 mb-6">
            <div className="size-12 rounded-full bg-red-600 flex items-center justify-center">
              <Shield className="size-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-neutral-800">
                Autenticación Windows
              </h2>
              <p className="text-sm text-neutral-600">
                Ingresa tu usuario de red corporativa
              </p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            {/* Username Input */}
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-semibold text-neutral-700">
                Usuario de Windows
              </Label>
              <Input
                id="username"
                type="text"
                placeholder="SISUGRB\usuario"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setError("");
                }}
                className="h-12 text-base border-2 border-neutral-300 focus:border-red-600"
                disabled={isLoading}
                autoFocus
                required
              />
              <p className="text-xs text-neutral-500">
                Formato: SISUGRB\tunombredeusuario (Ejemplo: SISUGRB\mgonzalez)
              </p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border-2 border-red-300 rounded-lg p-4 flex items-start gap-3">
                <AlertCircle className="size-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-red-900">Error de Autenticación</p>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            )}

            {/* Login Button */}
            <Button
              type="submit"
              disabled={isLoading || !username.trim()}
              className="w-full h-12 text-base font-semibold bg-red-600 hover:bg-red-700 disabled:bg-neutral-400"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="size-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Autenticando...</span>
                </div>
              ) : (
                "Iniciar Sesión"
              )}
            </Button>
          </form>

          {/* Info Box */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-xs font-semibold text-blue-900 mb-1">
              ℹ️ Modo Demo
            </p>
            <p className="text-xs text-blue-800">
              En producción, este login se reemplazará con <strong>Windows Authentication</strong> 
              automática. El sistema detectará automáticamente tu usuario de red sin necesidad de ingresar credenciales.
            </p>
          </div>

          {/* Usuarios de ejemplo */}
          <details className="mt-4">
            <summary className="text-sm font-semibold text-neutral-700 cursor-pointer hover:text-red-600">
              Ver usuarios de ejemplo
            </summary>
            <div className="mt-3 max-h-48 overflow-y-auto border border-neutral-200 rounded-lg p-3 space-y-2">
              {teamMembers.slice(0, 10).map((member) => (
                <button
                  key={member.id}
                  type="button"
                  onClick={() => setUsername(member.windowsUsername)}
                  className="w-full text-left text-xs p-2 hover:bg-red-50 rounded transition-colors"
                >
                  <div className="font-semibold text-neutral-800">{member.name}</div>
                  <div className="text-neutral-600">{member.windowsUsername}</div>
                </button>
              ))}
            </div>
          </details>
        </div>

        {/* Footer */}
        <p className="text-center text-sm text-neutral-600 mt-6">
          © 2025 SISU GRB • Sistema Interno de Gestión de Salas
        </p>
      </div>
    </div>
  );
}