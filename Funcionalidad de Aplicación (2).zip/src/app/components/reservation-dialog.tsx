import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Room, User, Reservation, api } from '../services/api';
import { toast } from 'sonner';
import { Loader2, Clock, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface ReservationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room: Room;
  currentUser: User;
  selectedDate: Date;
  existingReservations: Reservation[];
  onReservationCreated: (reservation: Reservation) => void;
}

export function ReservationDialog({
  open,
  onOpenChange,
  room,
  currentUser,
  selectedDate,
  existingReservations,
  onReservationCreated,
}: ReservationDialogProps) {
  const [purpose, setPurpose] = useState('');
  const [startTime, setStartTime] = useState('08:30');
  const [endTime, setEndTime] = useState('09:30');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validaciones
    if (!purpose.trim()) {
      toast.error('Por favor ingresa el motivo de la reserva');
      return;
    }

    // Validar horario de operación (8:30 AM - 6:00 PM)
    const [startHour, startMinute] = startTime.split(':').map(Number);
    const [endHour, endMinute] = endTime.split(':').map(Number);

    const startTotalMinutes = startHour * 60 + startMinute;
    const endTotalMinutes = endHour * 60 + endMinute;
    const operationStart = 8 * 60 + 30; // 8:30 AM
    const operationEnd = 18 * 60; // 6:00 PM

    if (startTotalMinutes < operationStart || endTotalMinutes > operationEnd) {
      toast.error('El horario debe estar entre 8:30 AM y 6:00 PM');
      return;
    }

    if (startTotalMinutes >= endTotalMinutes) {
      toast.error('La hora de inicio debe ser anterior a la hora de fin');
      return;
    }

    // Validar duración mínima (30 minutos)
    const durationMinutes = endTotalMinutes - startTotalMinutes;
    if (durationMinutes < 30) {
      toast.error('La reserva debe ser de al menos 30 minutos');
      return;
    }

    // Validar conflictos con otras reservas
    const hasConflict = existingReservations.some((reservation) => {
      const existingStart = new Date(reservation.startTime);
      const existingEnd = new Date(reservation.endTime);
      
      const newStart = new Date(selectedDate);
      newStart.setHours(startHour, startMinute, 0, 0);
      
      const newEnd = new Date(selectedDate);
      newEnd.setHours(endHour, endMinute, 0, 0);

      // Verificar si hay solapamiento
      return (
        (newStart >= existingStart && newStart < existingEnd) ||
        (newEnd > existingStart && newEnd <= existingEnd) ||
        (newStart <= existingStart && newEnd >= existingEnd)
      );
    });

    if (hasConflict) {
      toast.error('Ya existe una reserva en ese horario');
      return;
    }

    try {
      setLoading(true);

      // Crear DateTime para startTime
      const startDateTime = new Date(selectedDate);
      startDateTime.setHours(startHour, startMinute, 0, 0);

      // Crear DateTime para endTime
      const endDateTime = new Date(selectedDate);
      endDateTime.setHours(endHour, endMinute, 0, 0);

      const newReservation = await api.createReservation({
        roomId: room.id,
        userId: currentUser.id,
        startTime: startDateTime.toISOString(),
        endTime: endDateTime.toISOString(),
        purpose: purpose.trim(),
      });

      toast.success('Reserva creada exitosamente', {
        description: `${room.name} - ${format(selectedDate, 'd/MM/yyyy')} de ${startTime} a ${endTime}`,
      });

      // Reset form
      setPurpose('');
      setStartTime('08:30');
      setEndTime('09:30');

      onReservationCreated(newReservation);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error al crear la reserva';
      toast.error('Error', {
        description: errorMessage,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] border-2 border-gray-300">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-900">Reservar {room.name}</DialogTitle>
          <DialogDescription className="sr-only">
            Formulario para crear una nueva reserva de sala
          </DialogDescription>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <CalendarIcon className="h-4 w-4" />
              <span>{format(selectedDate, "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Clock className="h-4 w-4" />
              <span>Horario disponible: 8:30 AM - 6:00 PM</span>
            </div>
            {existingReservations.length > 0 && (
              <p className="text-sm text-blue-600 font-medium pt-2">
                💡 Puedes hacer múltiples reservas mientras no se solapen los horarios
              </p>
            )}
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Usuario */}
          <div className="space-y-2">
            <Label className="text-gray-700 font-semibold">Reservado por</Label>
            <Input
              value={`${currentUser.displayName} (${currentUser.team?.name || 'Sin equipo'})`}
              disabled
              className="bg-gray-50 border-gray-300"
            />
          </div>

          {/* Motivo */}
          <div className="space-y-2">
            <Label htmlFor="purpose" className="text-gray-700 font-semibold">
              Motivo de la reserva <span className="text-red-600">*</span>
            </Label>
            <Textarea
              id="purpose"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="Ej: Reunión de equipo, Capacitación, etc."
              rows={3}
              required
              className="resize-none border-gray-300 focus:border-red-600 focus:ring-red-600"
            />
          </div>

          {/* Horarios */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime" className="text-gray-700 font-semibold">
                Hora de inicio <span className="text-red-600">*</span>
              </Label>
              <Input
                id="startTime"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                min="08:30"
                max="18:00"
                step="900"
                required
                className="border-gray-300 focus:border-red-600 focus:ring-red-600"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endTime" className="text-gray-700 font-semibold">
                Hora de fin <span className="text-red-600">*</span>
              </Label>
              <Input
                id="endTime"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                min="08:30"
                max="18:00"
                step="900"
                required
                className="border-gray-300 focus:border-red-600 focus:ring-red-600"
              />
            </div>
          </div>

          {/* Reservas existentes para ese día */}
          {existingReservations.length > 0 && (
            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-3">
              <p className="text-xs font-semibold text-blue-900 mb-2">
                Reservas existentes para este día:
              </p>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {existingReservations.map((reservation) => (
                  <div key={reservation.id} className="text-xs text-blue-800">
                    {format(new Date(reservation.startTime), 'HH:mm')} - 
                    {format(new Date(reservation.endTime), 'HH:mm')} - {reservation.purpose}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Botones */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-gray-300 hover:bg-gray-100"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creando...
                </>
              ) : (
                'Confirmar Reserva'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}