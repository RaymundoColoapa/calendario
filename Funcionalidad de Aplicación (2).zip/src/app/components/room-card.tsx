import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Badge } from "@/app/components/ui/badge";
import { Button } from "@/app/components/ui/button";
import { Users, Calendar, Settings } from "lucide-react";
import { Room, RoomStatus } from "@/app/types";

interface RoomCardProps {
  room: Room;
  onViewDetails: (room: Room) => void;
  onChangeStatus: (roomId: string, status: RoomStatus) => void;
}

const statusConfig = {
  available: {
    label: "Disponible",
    color: "bg-green-500 hover:bg-green-600",
  },
  occupied: {
    label: "Ocupado",
    color: "bg-red-500 hover:bg-red-600",
  },
  maintenance: {
    label: "Mantenimiento",
    color: "bg-yellow-500 hover:bg-yellow-600",
  },
};

export function RoomCard({ room, onViewDetails, onChangeStatus }: RoomCardProps) {
  const config = statusConfig[room.status];

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle>{room.name}</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">{room.location}</p>
          </div>
          <Badge className={config.color}>{config.label}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Users className="size-4" />
            <span>{room.capacity} personas</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1">
          {room.amenities.map((amenity) => (
            <Badge key={amenity} variant="outline" className="text-xs">
              {amenity}
            </Badge>
          ))}
        </div>

        {room.currentReservation && (
          <div className="bg-muted p-3 rounded-md">
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="size-4" />
              <div>
                <p className="font-medium">{room.currentReservation.title}</p>
                <p className="text-xs text-muted-foreground">
                  {room.currentReservation.startTime} - {room.currentReservation.endTime}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => onViewDetails(room)}>
            <Calendar className="size-4 mr-2" />
            Ver Calendario
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => {
              const statuses: RoomStatus[] = ["available", "occupied", "maintenance"];
              const currentIndex = statuses.indexOf(room.status);
              const nextStatus = statuses[(currentIndex + 1) % statuses.length];
              onChangeStatus(room.id, nextStatus);
            }}
          >
            <Settings className="size-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
