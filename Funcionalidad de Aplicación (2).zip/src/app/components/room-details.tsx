import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/app/components/ui/dialog";
import { Button } from "@/app/components/ui/button";
import { Calendar } from "@/app/components/ui/calendar";
import { Badge } from "@/app/components/ui/badge";
import { ScrollArea } from "@/app/components/ui/scroll-area";
import { Separator } from "@/app/components/ui/separator";
import { Room, Reservation } from "@/app/types";
import { Users, MapPin, Clock, Plus } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface RoomDetailsProps {
  room: Room | null;
  reservations: Reservation[];
  onClose: () => void;
  onAddReservation: (room: Room, date: Date) => void;
}

export function RoomDetails({ room, reservations, onClose, onAddReservation }: RoomDetailsProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  if (!room) return null;

  const roomReservations = reservations.filter((r) => r.roomId === room.id);
  const selectedDateReservations = selectedDate
    ? roomReservations.filter(
        (r) => format(r.date, "yyyy-MM-dd") === format(selectedDate, "yyyy-MM-dd")
      )
    : [];

  return (
    <Dialog open={!!room} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl">{room.name}</DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Left Column - Room Info */}
          <div className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="size-4" />
                <span>{room.location}</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Users className="size-4" />
                <span>Capacidad: {room.capacity} personas</span>
              </div>
            </div>

            <div>
              <p className="font-medium mb-2">Equipamiento:</p>
              <div className="flex flex-wrap gap-2">
                {room.amenities.map((amenity) => (
                  <Badge key={amenity} variant="secondary">
                    {amenity}
                  </Badge>
                ))}
              </div>
            </div>

            <Separator />

            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="font-medium">Calendario</p>
                <Button
                  size="sm"
                  onClick={() => selectedDate && onAddReservation(room, selectedDate)}
                >
                  <Plus className="size-4 mr-2" />
                  Nueva Reserva
                </Button>
              </div>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                locale={es}
                className="rounded-md border"
              />
            </div>
          </div>

          {/* Right Column - Reservations */}
          <div className="space-y-4">
            <div>
              <p className="font-medium mb-3">
                Reservas del {selectedDate ? format(selectedDate, "d 'de' MMMM", { locale: es }) : ""}
              </p>

              <ScrollArea className="h-[500px] pr-4">
                {selectedDateReservations.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Clock className="size-12 mx-auto mb-2 opacity-50" />
                    <p>No hay reservas para este día</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {selectedDateReservations
                      .sort((a, b) => a.startTime.localeCompare(b.startTime))
                      .map((reservation) => (
                        <div
                          key={reservation.id}
                          className="border rounded-lg p-4 space-y-2 hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-medium">{reservation.title}</h4>
                              <p className="text-sm text-muted-foreground">
                                {reservation.startTime} - {reservation.endTime}
                              </p>
                            </div>
                            <Badge variant="outline">{reservation.attendees.length} asistentes</Badge>
                          </div>

                          {reservation.description && (
                            <p className="text-sm text-muted-foreground">{reservation.description}</p>
                          )}

                          <div className="pt-2 border-t">
                            <p className="text-sm">
                              <span className="font-medium">Organizador:</span> {reservation.organizer}
                            </p>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </ScrollArea>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
