import { useEffect } from 'react';
import { CheckCircle2, PlayCircle, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { DemoDiagnostics } from '../utils/demo-diagnostics';

interface DemoModeWelcomeProps {
  onClose: () => void;
}

export function DemoModeWelcome({ onClose }: DemoModeWelcomeProps) {
  // Ejecutar diagnóstico al montar el componente
  useEffect(() => {
    console.log('🎮 Modo Demo Activado - Ejecutando diagnóstico...');
    DemoDiagnostics.runFullDiagnostic();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl space-y-6">
        {/* Logo y Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-white px-8 py-6 rounded-lg shadow-xl">
              <img 
                src={sisuLogo} 
                alt="SISU GRB Logo" 
                className="h-24 w-auto object-contain mx-auto"
              />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-gray-900">
              Sistema de Reservas SISU GRB
            </h1>
            <p className="text-gray-600 font-medium">¡Bienvenido! Elige cómo quieres usar la aplicación</p>
          </div>
        </div>

        {/* Alerta de backend no disponible */}
        <Alert variant="default" className="border-orange-300 bg-orange-50">
          <AlertCircle className="h-5 w-5 text-orange-600" />
          <AlertTitle className="text-orange-900 font-bold">Backend no desplegado</AlertTitle>
          <AlertDescription className="text-orange-800">
            El servidor backend de Supabase no está desplegado aún. Para probarlo ahora, usa el <strong>Modo Demo</strong>.
            Para usar el sistema en producción, necesitas desplegar la función Edge primero.
          </AlertDescription>
        </Alert>

        {/* Grid de opciones */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Opción 1: Modo Demo */}
          <Card className="shadow-lg border-2 border-purple-300 bg-white hover:shadow-xl transition-shadow">
            <CardHeader className="space-y-3">
              <div className="flex items-center justify-center">
                <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center">
                  <PlayCircle className="h-8 w-8 text-purple-600" />
                </div>
              </div>
              <CardTitle className="text-center text-2xl text-purple-900">Modo Demo</CardTitle>
              <CardDescription className="text-center text-base">
                Prueba la aplicación ahora mismo con datos de ejemplo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Beneficios */}
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Funciona inmediatamente</strong> - No requiere backend
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Datos de prueba incluidos</strong> - Usuarios, salas y reservas de ejemplo
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Prueba todas las funciones</strong> - Crear, cancelar, gestionar mantenimiento
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Ideal para demostración</strong> - Muestra la app a tu equipo
                  </p>
                </div>
              </div>

              {/* Selector de usuario demo */}
              <div className="space-y-3">
                <p className="text-sm font-semibold text-gray-900 flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Selecciona un usuario de demostración:
                </p>
                <div className="space-y-2">
                  {demoUsers.map(user => (
                    <button
                      key={user.id}
                      onClick={() => setSelectedUser(user)}
                      className={`w-full p-3 rounded-lg border-2 text-left transition-all ${
                        selectedUser?.id === user.id
                          ? 'border-purple-600 bg-purple-50'
                          : 'border-gray-200 hover:border-purple-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-gray-900">{user.displayName}</p>
                          <p className="text-xs text-gray-600">{user.team?.name}</p>
                        </div>
                        {user.canManageMaintenance && (
                          <span className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded font-medium">
                            Admin
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <Button 
                onClick={handleStartDemo}
                disabled={!selectedUser}
                className="w-full bg-purple-600 hover:bg-purple-700 h-12 text-base font-semibold"
              >
                <PlayCircle className="h-5 w-5 mr-2" />
                Iniciar Modo Demo
              </Button>
            </CardContent>
          </Card>

          {/* Opción 2: Modo Real */}
          <Card className="shadow-lg border-2 border-red-300 bg-white hover:shadow-xl transition-shadow">
            <CardHeader className="space-y-3">
              <div className="flex items-center justify-center">
                <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center">
                  <Globe className="h-8 w-8 text-red-600" />
                </div>
              </div>
              <CardTitle className="text-center text-2xl text-red-900">Modo Producción</CardTitle>
              <CardDescription className="text-center text-base">
                Conecta con el backend real de Supabase
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Requisitos */}
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Base de datos real</strong> - Todos los datos persisten en Supabase
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Multi-usuario</strong> - Hasta 50 usuarios simultáneos
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Sincronización en tiempo real</strong> - Cambios visibles para todos
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <strong>Login con Azure AD</strong> - Autenticación corporativa
                  </p>
                </div>
              </div>

              {/* Requisito previo */}
              <Alert className="bg-yellow-50 border-yellow-300">
                <AlertCircle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-900 text-xs">
                  <strong>⚠️ Requisito previo:</strong> Debes haber desplegado la Edge Function en Supabase.
                  Lee el archivo <code className="bg-yellow-200 px-1">INSTRUCCIONES_DESPLIEGUE.md</code> para más detalles.
                </AlertDescription>
              </Alert>

              <Button 
                onClick={onRealModeSelected}
                className="w-full bg-red-600 hover:bg-red-700 h-12 text-base font-semibold"
              >
                <Globe className="h-5 w-5 mr-2" />
                Conectar con Supabase
              </Button>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-blue-900 font-medium mb-1">
                  💡 Comandos de despliegue:
                </p>
                <pre className="text-xs text-blue-800 bg-blue-100 p-2 rounded overflow-x-auto">
                  {`supabase login
supabase link --project-ref daowqmfdusubyicuuowy
supabase functions deploy make-server-f5c6167b --no-verify-jwt`}
                </pre>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center space-y-2">
          <p className="text-sm text-gray-600">
            Gestión de Salas de Juntas - Pisos 1, 2 y 3
          </p>
          <p className="text-xs text-gray-500">
            Horario: Lunes a Viernes, 8:30 AM - 6:00 PM
          </p>
        </div>
      </div>
    </div>
  );
}