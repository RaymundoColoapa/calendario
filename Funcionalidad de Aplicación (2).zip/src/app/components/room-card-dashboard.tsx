import { Room, Reservation, User } from '../services/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Users, MapPin, Calendar as CalendarIcon, Clock, AlertTriangle } from 'lucide-react';
import { ReservationDialog } from './reservation-dialog';
import { useState } from 'react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface RoomCardProps {
  room: Room;
  reservations: Reservation[];
  currentUser: User;
  selectedDate: Date;
  onReservationCreated: (reservation: Reservation) => void;
  disabled?: boolean;
}

export function RoomCard({
  room,
  reservations,
  currentUser,
  selectedDate,
  onReservationCreated,
  disabled = false,
}: RoomCardProps) {
  const [dialogOpen, setDialogOpen] = useState(false);

  // Calcular reserva actual y próxima reserva
  const now = new Date();
  const currentReservation = reservations.find(r => {
    const start = new Date(r.startTime);
    const end = new Date(r.endTime);
    return now >= start && now <= end && r.status === 'Active';
  });

  const nextReservation = !currentReservation ? reservations.find(r => {
    const start = new Date(r.startTime);
    return start > now && r.status === 'Active';
  }) : undefined;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Libre':
        return 'bg-gray-500 text-white font-semibold px-3 py-1';
      case 'Ocupado':
        return 'bg-red-600 text-white font-semibold px-3 py-1';
      case 'Mantenimiento':
        return 'bg-yellow-500 text-white font-semibold px-3 py-1';
      default:
        return 'bg-gray-400 text-white font-semibold px-3 py-1';
    }
  };

  const getFloorName = (floor: number) => {
    if (floor === 3) return 'Piso 3 - Capacitación';
    return `Piso ${floor}`;
  };

  return (
    <>
      <Card className="hover:shadow-lg transition-shadow border-2 border-gray-300 bg-white">
        <CardHeader className="pb-3 bg-gray-100 border-b-2 border-gray-300">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-lg font-bold text-gray-900">{room.name}</CardTitle>
              <CardDescription className="flex items-center gap-1 mt-1 text-gray-600">
                <MapPin className="h-3 w-3" />
                {getFloorName(room.floor)}
              </CardDescription>
            </div>
            <Badge className={getStatusColor(room.status)}>
              {room.status}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4 pt-4">
          {/* Capacidad */}
          <div className="flex items-center gap-2 text-sm font-medium text-gray-700 bg-gray-50 p-3 rounded-md border border-gray-200">
            <Users className="h-4 w-4 text-gray-600" />
            <span>Capacidad: <strong className="text-gray-900">{room.capacity} personas</strong></span>
          </div>

          {/* Reserva Actual */}
          {currentReservation && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 space-y-1">
              <p className="text-xs font-semibold text-red-900 flex items-center gap-1">
                <Clock className="h-3 w-3" />
                EN USO AHORA
              </p>
              <p className="text-sm text-red-800">{currentReservation.purpose}</p>
              <p className="text-xs text-red-700">
                {format(new Date(currentReservation.startTime), 'HH:mm')} - 
                {format(new Date(currentReservation.endTime), 'HH:mm')}
              </p>
              {currentReservation.user && (
                <p className="text-xs text-red-600">
                  Por: {currentReservation.user.displayName}
                </p>
              )}
            </div>
          )}

          {/* Próxima Reserva */}
          {!currentReservation && nextReservation && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-1">
              <p className="text-xs font-semibold text-blue-900 flex items-center gap-1">
                <CalendarIcon className="h-3 w-3" />
                PRÓXIMA RESERVA
              </p>
              <p className="text-sm text-blue-800">{nextReservation.purpose}</p>
              <p className="text-xs text-blue-700">
                {format(new Date(nextReservation.startTime), 'HH:mm')} - 
                {format(new Date(nextReservation.endTime), 'HH:mm')}
              </p>
              {nextReservation.user && (
                <p className="text-xs text-blue-600">
                  Por: {nextReservation.user.displayName}
                </p>
              )}
            </div>
          )}

          {/* Estado de Mantenimiento */}
          {room.status === 'Mantenimiento' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 space-y-1">
              <p className="text-xs font-semibold text-yellow-900 flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                EN MANTENIMIENTO
              </p>
              <p className="text-xs text-yellow-700">
                Esta sala no está disponible temporalmente
              </p>
            </div>
          )}

          {/* Botón de Reservar */}
          <Button
            onClick={() => setDialogOpen(true)}
            disabled={disabled || room.status === 'Mantenimiento'}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold disabled:bg-gray-400"
            size="lg"
          >
            {room.status === 'Mantenimiento' ? 'EN MANTENIMIENTO' : 'RESERVAR SALA'}
          </Button>

          {/* Nota sobre disponibilidad */}
          {room.status === 'Ocupado' && (
            <p className="text-xs text-center text-gray-600 italic">
              Ocupada ahora, pero puedes reservar para otros horarios
            </p>
          )}

          {/* Lista de Reservas del Día */}
          {reservations.length > 0 && (
            <div className="pt-3 border-t border-gray-200">
              <p className="text-xs font-semibold text-gray-700 mb-2 flex items-center justify-between">
                <span>Reservas para {format(selectedDate, 'd/MM/yyyy')}:</span>
                <Badge className="bg-blue-600 text-white text-xs">{reservations.length}</Badge>
              </p>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {reservations.map((reservation) => (
                  <div
                    key={reservation.id}
                    className="text-xs bg-gray-50 rounded p-2 space-y-1"
                  >
                    <p className="font-medium text-gray-900">
                      {format(new Date(reservation.startTime), 'HH:mm')} - 
                      {format(new Date(reservation.endTime), 'HH:mm')}
                    </p>
                    <p className="text-gray-700">{reservation.purpose}</p>
                    {reservation.user && (
                      <p className="text-gray-600">
                        {reservation.user.displayName} ({reservation.user.team?.name})
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diálogo de Reserva */}
      <ReservationDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        room={room}
        currentUser={currentUser}
        selectedDate={selectedDate}
        existingReservations={reservations}
        onReservationCreated={(newReservation) => {
          setDialogOpen(false);
          onReservationCreated(newReservation);
        }}
      />
    </>
  );
}