// Herramienta de diagnóstico y corrección automática del modo demo
import { DemoStorage, generateDemoReservations } from '../services/demo-data';

export class DemoDiagnostics {
  /**
   * Ejecuta un diagnóstico completo y repara problemas automáticamente
   */
  static runFullDiagnostic() {
    console.log('🔍 ========== DIAGNÓSTICO DEL MODO DEMO ==========');
    
    const isDemoMode = DemoStorage.isDemoMode();
    console.log('📊 Modo Demo:', isDemoMode ? '✅ ACTIVO' : '❌ INACTIVO');
    
    if (!isDemoMode) {
      console.log('⚠️ El modo demo no está activo. Actívalo con:');
      console.log('   DemoDiagnostics.activateDemoMode()');
      return;
    }
    
    // Verificar reservas
    const reservations = DemoStorage.getReservations();
    console.log(`📋 Total de reservas: ${reservations.length}`);
    
    // Verificar reservas de HOY
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString().split('T')[0];
    
    const todayReservations = reservations.filter(r => {
      const resDate = new Date(r.startTime);
      resDate.setHours(0, 0, 0, 0);
      return resDate.toISOString().split('T')[0] === todayStr;
    });
    
    console.log(`📅 Reservas para HOY (${todayStr}): ${todayReservations.length}`);
    
    if (todayReservations.length > 0) {
      console.table(todayReservations.map(r => ({
        ID: r.id,
        Sala: `Piso ${r.room?.floor || r.roomId}`,
        Usuario: r.user?.displayName || 'Desconocido',
        Inicio: new Date(r.startTime).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
        Fin: new Date(r.endTime).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
        Estado: r.status,
      })));
    } else {
      console.log('ℹ️ No hay reservas para hoy');
    }
    
    // Verificar reservas viejas (no de hoy)
    const oldReservations = reservations.filter(r => {
      const resDate = new Date(r.startTime);
      resDate.setHours(0, 0, 0, 0);
      return resDate.toISOString().split('T')[0] !== todayStr;
    });
    
    if (oldReservations.length > 0) {
      console.warn(`⚠️ PROBLEMA DETECTADO: ${oldReservations.length} reservas de días pasados/futuros encontradas`);
      console.warn('   Estas reservas pueden causar problemas. Se recomienda limpiarlas.');
      console.log('   Ejecuta: DemoDiagnostics.cleanOldReservations()');
    }
    
    // Verificar usuario actual
    const currentUser = DemoStorage.getCurrentUser();
    if (currentUser) {
      console.log('👤 Usuario actual:', currentUser.displayName);
      console.log('   Equipo:', currentUser.team?.name);
      console.log('   Admin:', currentUser.canManageMaintenance ? '✅ SÍ' : '❌ NO');
    } else {
      console.warn('⚠️ No hay usuario seleccionado');
    }
    
    // Verificar mantenimiento
    const maintenance = DemoStorage.getMaintenance();
    if (maintenance.length > 0) {
      console.log('🔧 Salas en mantenimiento:', maintenance);
    } else {
      console.log('🔧 Salas en mantenimiento: Ninguna');
    }
    
    console.log('');
    console.log('💡 COMANDOS DISPONIBLES:');
    console.log('   DemoDiagnostics.activateDemoMode()     - Activar modo demo limpio');
    console.log('   DemoDiagnostics.resetToDefaults()      - Reset completo con datos frescos');
    console.log('   DemoDiagnostics.cleanOldReservations() - Limpiar reservas viejas');
    console.log('   DemoDiagnostics.showAvailableSlots()   - Ver horarios disponibles');
    console.log('   DemoDiagnostics.clearAllReservations() - Borrar TODAS las reservas');
    console.log('========================================');
  }
  
  /**
   * Activa el modo demo correctamente con datos frescos
   */
  static activateDemoMode() {
    console.log('🚀 Activando modo demo...');
    DemoStorage.enableDemoMode();
    console.log('✅ Modo demo activado con datos frescos');
    console.log('🔄 Recargando página...');
    setTimeout(() => window.location.reload(), 500);
  }
  
  /**
   * Reset completo - Borra todo y reinicializa
   */
  static resetToDefaults() {
    console.log('🔄 Reseteando modo demo a valores por defecto...');
    
    // Desactivar y reactivar
    DemoStorage.disableDemoMode();
    DemoStorage.enableDemoMode();
    
    console.log('✅ Reset completo exitoso');
    console.log('📋 Reservas de ejemplo cargadas:');
    
    const reservations = DemoStorage.getReservations();
    console.table(reservations.map(r => ({
      Sala: r.room?.name || `Sala ${r.roomId}`,
      Usuario: r.user?.displayName,
      Inicio: new Date(r.startTime).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      Fin: new Date(r.endTime).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    })));
    
    console.log('🔄 Recargando página...');
    setTimeout(() => window.location.reload(), 500);
  }
  
  /**
   * Limpia solo las reservas que no son de hoy
   */
  static cleanOldReservations() {
    console.log('🧹 Limpiando reservas viejas...');
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString().split('T')[0];
    
    const allReservations = DemoStorage.getReservations();
    const todayReservations = allReservations.filter(r => {
      const resDate = new Date(r.startTime);
      resDate.setHours(0, 0, 0, 0);
      return resDate.toISOString().split('T')[0] === todayStr;
    });
    
    const removed = allReservations.length - todayReservations.length;
    
    DemoStorage.saveReservations(todayReservations);
    
    console.log(`✅ ${removed} reservas viejas eliminadas`);
    console.log(`📋 ${todayReservations.length} reservas de hoy conservadas`);
    console.log('🔄 Recargando página...');
    setTimeout(() => window.location.reload(), 500);
  }
  
  /**
   * Muestra los horarios disponibles para cada sala HOY
   */
  static showAvailableSlots() {
    console.log('📅 ========== HORARIOS DISPONIBLES HOY ==========');
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString().split('T')[0];
    
    const allReservations = DemoStorage.getReservations();
    const todayReservations = allReservations.filter(r => {
      const resDate = new Date(r.startTime);
      resDate.setHours(0, 0, 0, 0);
      return resDate.toISOString().split('T')[0] === todayStr && r.status === 'Active';
    });
    
    const rooms = [
      { id: 1, name: 'Sala Piso 1', capacity: 10 },
      { id: 2, name: 'Sala Piso 2', capacity: 10 },
      { id: 3, name: 'Sala Piso 3', capacity: 30 },
    ];
    
    rooms.forEach(room => {
      console.log(`\n🏢 ${room.name} (${room.capacity} personas)`);
      
      const roomReservations = todayReservations.filter(r => r.roomId === room.id);
      
      if (roomReservations.length === 0) {
        console.log('   ✅ COMPLETAMENTE LIBRE (8:30 AM - 6:00 PM)');
      } else {
        console.log('   📋 Reservas:');
        roomReservations.forEach(r => {
          const start = new Date(r.startTime);
          const end = new Date(r.endTime);
          console.log(`      🔴 ${start.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} - ${end.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} (${r.user?.displayName})`);
        });
        
        // Calcular huecos disponibles
        const sortedRes = roomReservations.sort((a, b) => 
          new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
        );
        
        console.log('   ✅ Horarios disponibles:');
        
        // Antes de la primera reserva
        const firstStart = new Date(sortedRes[0].startTime);
        if (firstStart.getHours() > 8 || (firstStart.getHours() === 8 && firstStart.getMinutes() > 30)) {
          console.log(`      ✅ 8:30 AM - ${firstStart.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`);
        }
        
        // Entre reservas
        for (let i = 0; i < sortedRes.length - 1; i++) {
          const end = new Date(sortedRes[i].endTime);
          const nextStart = new Date(sortedRes[i + 1].startTime);
          
          if (end < nextStart) {
            console.log(`      ✅ ${end.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} - ${nextStart.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`);
          }
        }
        
        // Después de la última reserva
        const lastEnd = new Date(sortedRes[sortedRes.length - 1].endTime);
        if (lastEnd.getHours() < 18) {
          console.log(`      ✅ ${lastEnd.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} - 6:00 PM`);
        }
      }
    });
    
    console.log('\n================================================');
  }
  
  /**
   * Borra TODAS las reservas (para empezar completamente limpio)
   */
  static clearAllReservations() {
    console.log('🗑️ Borrando TODAS las reservas...');
    DemoStorage.saveReservations([]);
    console.log('✅ Todas las reservas eliminadas');
    console.log('🔄 Recargando página...');
    setTimeout(() => window.location.reload(), 500);
  }
  
  /**
   * Desactiva completamente el modo demo
   */
  static deactivateDemoMode() {
    console.log('🛑 Desactivando modo demo...');
    DemoStorage.disableDemoMode();
    console.log('✅ Modo demo desactivado');
    console.log('🔄 Recargando página...');
    setTimeout(() => window.location.reload(), 500);
  }
}

// Exponer globalmente para fácil acceso desde consola
(window as any).DemoDiagnostics = DemoDiagnostics;
