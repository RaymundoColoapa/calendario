import { useState, useEffect } from 'react';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';
import { RoomDashboard } from './components/room-dashboard';
import { MyReservations } from './components/my-reservations';
import { MaintenancePanel } from './components/maintenance-panel';
import { AutoLogin } from './components/auto-login';
import { DemoModeWelcome } from './components/demo-mode-welcome';
import { AdminDebugPanel } from './components/admin-debug-panel';
import { Room, User, Reservation, api } from './services/api';
import { DemoStorage } from './services/demo-data';
import { DemoDiagnostics } from './utils/demo-diagnostics';
import { Button } from './components/ui/button';
import { LogOut, Loader2, Wifi, WifiOff, PlayCircle } from 'lucide-react';
import { projectId } from '/utils/supabase/info';
import sisuLogo from "figma:asset/d875d2f03e4289fd214b7d63b8b8af2cfbe1db24.png";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [maintenanceRooms, setMaintenanceRooms] = useState<Set<number>>(new Set());
  const [isOnline, setIsOnline] = useState(true);
  const [showModeSelection, setShowModeSelection] = useState(false);

  // Cargar usuario y verificar conexión
  useEffect(() => {
    // 🔧 AUTO-LIMPIEZA: Si está en modo demo, verificar versión de datos
    if (DemoStorage.isDemoMode()) {
      const dataVersion = localStorage.getItem('sisugrb_demo_version');
      const CURRENT_VERSION = '2.0'; // Incrementar cuando cambies la estructura de datos
      
      console.log('🎮 Modo Demo detectado');
      console.log(`📦 Versión de datos: ${dataVersion || 'ninguna'} (esperada: ${CURRENT_VERSION})`);
      
      // Si no hay versión o es antigua, limpiar datos
      if (dataVersion !== CURRENT_VERSION) {
        console.warn('⚠️ Datos de versión antigua detectados. Limpiando...');
        localStorage.removeItem('sisugrb_demo_reservations');
        localStorage.removeItem('sisugrb_demo_maintenance');
        localStorage.setItem('sisugrb_demo_version', CURRENT_VERSION);
        console.log('✅ Datos limpiados y versión actualizada. Recargando...');
        toast.info('🔄 Actualizando modo demo...', { duration: 1500 });
        setTimeout(() => window.location.reload(), 500);
        return;
      }
      
      const reservations = DemoStorage.getReservations();
      console.log(`📊 Reservas en modo demo: ${reservations.length}`);
      console.log('✅ Datos al día. Continuando...');
    }
    
    loadInitialData();
    
    // Verificar conexión cada 30 segundos
    const interval = setInterval(checkConnection, 30000);
    return () => clearInterval(interval);
  }, []);

  // Recargar reservas cuando cambie la fecha
  useEffect(() => {
    if (currentUser) {
      loadReservations();
    }
  }, [selectedDate, currentUser]);

  // Actualizar estado de las salas basado en reservaciones y mantenimiento
  useEffect(() => {
    updateRoomStatuses();
  }, [reservations, maintenanceRooms]);

  const checkConnection = async () => {
    const online = await api.checkBackendHealth();
    setIsOnline(online);
    if (!online && currentUser) {
      toast.error('Conexión perdida con el servidor', {
        description: 'Intentando reconectar...',
      });
    }
  };

  const loadInitialData = async () => {
    try {
      // Verificar conexión
      console.log('🔍 Verificando conexión con Supabase...');
      const online = await api.checkBackendHealth();
      setIsOnline(online);

      if (!online) {
        console.error('❌ No se puede conectar con Supabase');
        console.error('📍 URL esperada:', `https://${projectId}.supabase.co/functions/v1/make-server-f5c6167b/health`);
        console.error('💡 Solución: Debes desplegar la Edge Function en Supabase');
        console.error('📖 Lee el archivo INSTRUCCIONES_DESPLIEGUE.md para más información');
        
        toast.error('⚠️ Servidor Backend No Desplegado', {
          description: 'La aplicación necesita que despliegues la Edge Function en Supabase. Revisa INSTRUCCIONES_DESPLIEGUE.md',
          duration: 15000,
        });
        setLoading(false);
        return;
      }

      console.log('✅ Conexión con Supabase exitosa');

      // Cargar usuario guardado
      const savedUser = await api.getCurrentUser();
      if (savedUser) {
        setCurrentUser(savedUser);
        await loadRooms();
        await loadReservations();
        await loadMaintenance();
      }
    } catch (error) {
      console.error('❌ Error cargando datos iniciales:', error);
      setIsOnline(false);
      toast.error('Error al conectar con el servidor', {
        description: 'Revisa la consola (F12) para más detalles',
        duration: 10000,
      });
    } finally {
      setLoading(false);
    }
  };

  const loadRooms = async () => {
    try {
      const roomsData = await api.getRooms();
      setRooms(roomsData);
    } catch (error) {
      console.error('Error cargando salas:', error);
      toast.error('Error al cargar salas');
    }
  };

  const loadReservations = async () => {
    try {
      const dateStr = selectedDate.toISOString().split('T')[0];
      const reservationsData = await api.getReservations(dateStr);
      setReservations(reservationsData);
    } catch (error) {
      console.error('Error cargando reservas:', error);
      const errorMessage = error instanceof Error ? error.message : 'Error al cargar reservas';
      
      // Si el error es de conexión, mostrar un mensaje más amigable
      if (errorMessage.includes('servidor') || errorMessage.includes('fetch')) {
        toast.error('⚠️ No se puede conectar con el servidor', {
          description: 'Verifica que la función de Supabase esté desplegada. Consulta la consola para más detalles.',
          duration: 10000,
        });
      } else {
        toast.error('Error al cargar reservas', {
          description: errorMessage,
        });
      }
    }
  };

  const loadMaintenance = async () => {
    try {
      const maintenanceData = await api.getMaintenanceRooms();
      setMaintenanceRooms(new Set(maintenanceData));
    } catch (error) {
      console.error('Error cargando mantenimiento:', error);
    }
  };

  const updateRoomStatuses = () => {
    const now = new Date();
    const updatedRooms = rooms.map(room => {
      // Si la sala está en mantenimiento, sobreescribir el estado
      if (maintenanceRooms.has(room.id)) {
        return {
          ...room,
          status: 'Mantenimiento' as const,
          currentReservation: undefined,
          nextReservation: undefined
        } as Room;
      }

      const roomReservations = reservations.filter(r => 
        r.roomId === room.id && 
        r.status === 'Active'
      );

      // Buscar reserva actual (en curso ahora)
      const currentReservation = roomReservations.find(r => {
        const start = new Date(r.startTime);
        const end = new Date(r.endTime);
        return now >= start && now <= end;
      });

      // Buscar próxima reserva (futura)
      const futureReservations = roomReservations
        .filter(r => new Date(r.startTime) > now)
        .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
      
      const nextReservation = futureReservations[0];

      return {
        ...room,
        status: currentReservation ? 'Ocupado' : 'Libre',
        currentReservation,
        nextReservation
      } as Room;
    });

    setRooms(updatedRooms);
  };

  const handleLogin = async (user: User) => {
    try {
      // Login a través del API
      const loggedUser = await api.loginUser(user.id);
      setCurrentUser(loggedUser);
      
      // Cargar datos
      await loadRooms();
      await loadReservations();
      await loadMaintenance();
      
      toast.success(`¡Bienvenido, ${loggedUser.displayName}!`, {
        description: `Equipo: ${loggedUser.team?.name}`,
        duration: 3000,
      });
    } catch (error) {
      console.error('Error en login:', error);
      toast.error('Error al iniciar sesión');
    }
  };

  const handleLogout = () => {
    api.logoutUser();
    setCurrentUser(null);
    setRooms([]);
    setReservations([]);
    setMaintenanceRooms(new Set());
    toast.info('Sesión cerrada');
  };

  const handleReservationCreated = async (newReservation: Reservation) => {
    try {
      if (!currentUser) return;

      // Crear reserva en el servidor
      await api.createReservation({
        roomId: newReservation.roomId,
        userId: currentUser.id,
        startTime: newReservation.startTime,
        endTime: newReservation.endTime,
        purpose: newReservation.purpose,
      });

      // Recargar reservas
      await loadReservations();
      toast.success('Reserva creada exitosamente');
    } catch (error: any) {
      console.error('Error creando reserva:', error);
      toast.error(error.message || 'Error al crear reserva');
    }
  };

  const handleReservationCancelled = async (reservationId: number) => {
    try {
      if (!currentUser) return;

      // Cancelar reserva en el servidor
      await api.cancelReservation(reservationId, currentUser.id);

      // Recargar reservas
      await loadReservations();
      toast.success('Reserva cancelada exitosamente');
    } catch (error: any) {
      console.error('Error cancelando reserva:', error);
      toast.error(error.message || 'Error al cancelar reserva');
    }
  };

  const handleMaintenanceToggle = async (roomId: number, inMaintenance: boolean) => {
    try {
      if (!currentUser) return;

      // Actualizar mantenimiento en el servidor
      await api.toggleMaintenance(roomId, inMaintenance, currentUser.id);

      // Recargar mantenimiento
      await loadMaintenance();
      await loadRooms();
      
      toast.success(
        inMaintenance 
          ? 'Sala puesta en mantenimiento' 
          : 'Sala liberada de mantenimiento'
      );
    } catch (error: any) {
      console.error('Error actualizando mantenimiento:', error);
      toast.error(error.message || 'Error al actualizar mantenimiento');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-red-600 mx-auto" />
          <p className="text-gray-600 font-medium">Cargando Sistema de Reservas SISU GRB...</p>
        </div>
      </div>
    );
  }

  // Mostrar pantalla de login si no hay usuario
  if (!currentUser) {
    return (
      <>
        <AutoLogin onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  // Filtrar reservaciones por fecha seleccionada
  const dateStr = selectedDate.toISOString().split('T')[0];
  const reservationsForDate = reservations.filter(r => {
    const reservationDate = new Date(r.startTime).toISOString().split('T')[0];
    return reservationDate === dateStr && r.status === 'Active';
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Indicador de Modo Demo */}
      {DemoStorage.isDemoMode() && (
        <div className="bg-purple-600 text-white py-3 px-4 shadow-md">
          <div className="flex items-center justify-between max-w-7xl mx-auto">
            <div className="flex items-center gap-2">
              <PlayCircle className="h-5 w-5" />
              <span className="font-medium">
                MODO DEMO ACTIVO - Datos solo en este navegador
              </span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  const reservations = DemoStorage.getReservations();
                  console.log(`📊 Reservas actuales: ${reservations.length}`);
                  if (reservations.length > 0) {
                    console.table(reservations.map(r => ({
                      ID: r.id,
                      Sala: r.room?.name || `Sala ${r.roomId}`,
                      Usuario: r.user?.displayName,
                      Inicio: new Date(r.startTime).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
                      Fin: new Date(r.endTime).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
                      Estado: r.status
                    })));
                  } else {
                    console.log('✅ No hay reservas. Todas las salas están libres.');
                  }
                }}
                className="text-sm underline hover:text-purple-100"
              >
                Ver Reservas
              </button>
              <button
                onClick={() => {
                  if (confirm('¿Borrar TODAS las reservas y empezar desde cero?\n\nEsto dejará las 3 salas completamente libres.')) {
                    localStorage.removeItem('sisugrb_demo_reservations');
                    localStorage.removeItem('sisugrb_demo_maintenance');
                    toast.success('✅ Todas las reservas borradas. Todas las salas están libres.');
                    setTimeout(() => window.location.reload(), 800);
                  }
                }}
                className="bg-white/20 hover:bg-white/30 px-4 py-1.5 rounded font-semibold text-sm transition-colors"
              >
                🗑️ Borrar Todas las Reservas
              </button>
              <button
                onClick={() => {
                  if (confirm('¿Salir del modo demo?\n\nPerderás todos los datos de prueba.')) {
                    DemoStorage.disableDemoMode();
                    window.location.reload();
                  }
                }}
                className="underline hover:text-purple-100 text-sm"
              >
                Salir del Modo Demo
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Header */}
      <header className="bg-white border-b-4 border-red-600 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img 
                src={sisuLogo} 
                alt="SISU GRB Logo" 
                className="h-16 w-auto object-contain"
              />
              <div className="border-l-2 border-gray-300 pl-4">
                <h1 className="text-xl font-bold text-gray-900">
                  Sistema de Reservas de Salas
                </h1>
                <p className="text-sm text-gray-600">Gestión de Salas de Juntas</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {/* Indicador de conexión */}
              <div className="flex items-center gap-2">
                {isOnline ? (
                  <Wifi className="h-5 w-5 text-green-600" title="Conectado" />
                ) : (
                  <WifiOff className="h-5 w-5 text-red-600" title="Sin conexión" />
                )}
              </div>
              
              <div className="text-right">
                <p className="text-sm font-semibold text-gray-900">{currentUser.displayName}</p>
                <p className="text-xs text-red-600 font-medium">
                  {currentUser.team?.name}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="text-gray-700 hover:text-red-600 hover:border-red-600"
              >
                <LogOut className="h-4 w-4 mr-1" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          {/* Dashboard de Salas */}
          <RoomDashboard
            rooms={rooms}
            reservations={reservationsForDate}
            currentUser={currentUser}
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
            onReservationCreated={handleReservationCreated}
          />

          {/* Mis Reservas */}
          <MyReservations
            currentUser={currentUser}
            reservations={reservations.filter(r => r.userId === currentUser.id)}
            onReservationCancelled={handleReservationCancelled}
          />

          {/* Panel de Mantenimiento - Solo para usuarios con permiso */}
          {currentUser.canManageMaintenance && (
            <MaintenancePanel
              rooms={rooms}
              onMaintenanceToggle={handleMaintenanceToggle}
            />
          )}
        </div>
      </main>

      {/* Admin Debug Panel - Botón flotante para todos */}
      <AdminDebugPanel />

      <Toaster />
    </div>
  );
}