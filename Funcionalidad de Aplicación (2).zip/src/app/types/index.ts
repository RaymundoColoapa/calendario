export type RoomStatus = "available" | "occupied" | "maintenance";

export type ServiceType = "Cafés" | "Aguas" | "Galletas" | "Refrescos" | "IdeaShare";

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  team: string; // Agregar equipo/departamento
  windowsUsername: string; // Usuario de Windows para autenticación real
}

export interface Reservation {
  id: string;
  roomId: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  date: Date;
  attendees: string[];
  organizer: string;
  organizerEmail: string;
  organizerWindowsUsername: string; // Usuario Windows del organizador
  services?: ServiceType[];
}

export interface Room {
  id: string;
  name: string;
  location: string;
  capacity: number;
  status: RoomStatus;
  amenities: string[];
  currentReservation?: {
    title: string;
    startTime: string;
    endTime: string;
    organizer: string;
  };
  maintenanceInfo?: {
    startTime: string;
    endTime: string;
  };
}