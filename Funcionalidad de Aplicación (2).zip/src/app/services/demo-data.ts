// Datos de demostración para probar la app sin backend
import { User, Team, Room, Reservation } from './api';

export const demoTeams: Team[] = [
  { id: 1, name: 'Operaciones', description: 'Equipo de Operaciones', color: '#3B82F6' },
  { id: 2, name: 'Ventas', description: 'Equipo de Ventas', color: '#10B981' },
  { id: 3, name: 'Tecnología', description: 'Equipo de Tecnología', color: '#8B5CF6' },
  { id: 4, name: 'Administración', description: 'Equipo de Administración', color: '#F59E0B' },
];

export const demoUsers: User[] = [
  {
    id: 1,
    username: 'azuread\\mgonzalez',
    displayName: 'María González',
    email: 'mgonzalez@sisugrb.com',
    teamId: 1,
    team: demoTeams[0],
    isActive: true,
    canManageMaintenance: false,
  },
  {
    id: 2,
    username: 'azuread\\jperez',
    displayName: 'Juan Pérez',
    email: 'jperez@sisugrb.com',
    teamId: 2,
    team: demoTeams[1],
    isActive: true,
    canManageMaintenance: false,
  },
  {
    id: 3,
    username: 'azuread\\alopez',
    displayName: 'Ana López',
    email: 'alopez@sisugrb.com',
    teamId: 3,
    team: demoTeams[2],
    isActive: true,
    canManageMaintenance: false,
  },
  {
    id: 4,
    username: 'azuread\\jlpimienta',
    displayName: 'José Luis Pimienta',
    email: 'jlpimienta@sisugrb.com',
    teamId: 4,
    team: demoTeams[3],
    isActive: true,
    canManageMaintenance: true, // Admin
  },
];

export const demoRooms: Room[] = [
  {
    id: 1,
    name: 'Sala Piso 1',
    floor: 1,
    capacity: 10,
    status: 'Libre',
  },
  {
    id: 2,
    name: 'Sala Piso 2',
    floor: 2,
    capacity: 10,
    status: 'Libre',
  },
  {
    id: 3,
    name: 'Sala Piso 3 - Capacitación',
    floor: 3,
    capacity: 30,
    status: 'Libre',
  },
];

// Generar reservas de ejemplo para hoy
const today = new Date();
today.setHours(0, 0, 0, 0);

export const generateDemoReservations = (): Reservation[] => {
  // ⚠️ CAMBIADO: NO generar reservas automáticamente para evitar conflictos
  // El usuario puede crear sus propias reservas de prueba
  return [];
  
  /* RESERVAS DE EJEMPLO DESACTIVADAS - Descomentar si las necesitas
  const reservations: Reservation[] = [];
  let idCounter = 1;

  // Reserva pasada - Sala Piso 1 (María González, 9:00-10:00)
  const res1Start = new Date(today);
  res1Start.setHours(9, 0, 0, 0);
  const res1End = new Date(today);
  res1End.setHours(10, 0, 0, 0);
  
  reservations.push({
    id: idCounter++,
    roomId: 1,
    userId: 1,
    user: demoUsers[0],
    room: demoRooms[0],
    startTime: res1Start.toISOString(),
    endTime: res1End.toISOString(),
    purpose: 'Reunión de planificación mensual',
    status: 'Active',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  });

  // Reserva futura - Sala Piso 3 (José Luis, 15:00-16:00)
  const res2Start = new Date(today);
  res2Start.setHours(15, 0, 0, 0);
  const res2End = new Date(today);
  res2End.setHours(16, 0, 0, 0);
  
  reservations.push({
    id: idCounter++,
    roomId: 3,
    userId: 4,
    user: demoUsers[3],
    room: demoRooms[2],
    startTime: res2Start.toISOString(),
    endTime: res2End.toISOString(),
    purpose: 'Capacitación de nuevos productos',
    status: 'Active',
    createdAt: new Date().toISOString(),
  });

  return reservations;
  */
};

// Storage keys
export const DEMO_MODE_KEY = 'sisugrb_demo_mode';
export const DEMO_USERS_KEY = 'sisugrb_demo_users';
export const DEMO_RESERVATIONS_KEY = 'sisugrb_demo_reservations';
export const DEMO_MAINTENANCE_KEY = 'sisugrb_demo_maintenance';
export const DEMO_CURRENT_USER_KEY = 'sisugrb_demo_current_user';

export class DemoStorage {
  static isDemoMode(): boolean {
    return localStorage.getItem(DEMO_MODE_KEY) === 'true';
  }

  static enableDemoMode() {
    localStorage.setItem(DEMO_MODE_KEY, 'true');
    // Inicializar datos de demo
    this.saveUsers(demoUsers);
    this.saveReservations(generateDemoReservations());
    this.saveMaintenance([]);
  }

  static disableDemoMode() {
    localStorage.removeItem(DEMO_MODE_KEY);
    localStorage.removeItem(DEMO_USERS_KEY);
    localStorage.removeItem(DEMO_RESERVATIONS_KEY);
    localStorage.removeItem(DEMO_MAINTENANCE_KEY);
    localStorage.removeItem(DEMO_CURRENT_USER_KEY);
  }

  static saveUsers(users: User[]) {
    localStorage.setItem(DEMO_USERS_KEY, JSON.stringify(users));
  }

  static getUsers(): User[] {
    const data = localStorage.getItem(DEMO_USERS_KEY);
    return data ? JSON.parse(data) : demoUsers;
  }

  static saveReservations(reservations: Reservation[]) {
    localStorage.setItem(DEMO_RESERVATIONS_KEY, JSON.stringify(reservations));
  }

  static getReservations(): Reservation[] {
    const data = localStorage.getItem(DEMO_RESERVATIONS_KEY);
    return data ? JSON.parse(data) : generateDemoReservations();
  }

  static saveMaintenance(roomIds: number[]) {
    localStorage.setItem(DEMO_MAINTENANCE_KEY, JSON.stringify(roomIds));
  }

  static getMaintenance(): number[] {
    const data = localStorage.getItem(DEMO_MAINTENANCE_KEY);
    return data ? JSON.parse(data) : [];
  }

  static saveCurrentUser(user: User | null) {
    if (user) {
      localStorage.setItem(DEMO_CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(DEMO_CURRENT_USER_KEY);
    }
  }

  static getCurrentUser(): User | null {
    const data = localStorage.getItem(DEMO_CURRENT_USER_KEY);
    return data ? JSON.parse(data) : null;
  }
}