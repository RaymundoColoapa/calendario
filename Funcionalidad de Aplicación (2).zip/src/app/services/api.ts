import { projectId, publicAnonKey } from '/utils/supabase/info';
import { DemoStorage, demoRooms, demoUsers, demoTeams } from './demo-data';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-f5c6167b/api`;

// Flag para detectar si el backend está disponible
let backendAvailable: boolean | null = null;

// Helper para manejar errores de fetch
const handleFetchError = (error: any, operation: string) => {
  console.error(`❌ Error en ${operation}:`, error);
  
  if (error instanceof TypeError && error.message.includes('fetch')) {
    throw new Error(`No se puede conectar con el servidor. Por favor verifica que:\n1. Tienes conexión a internet\n2. El servidor Supabase está desplegado\n3. La URL del servidor es correcta`);
  }
  
  throw error;
};

// Helper para verificar si estamos en modo demo
const isDemoMode = (): boolean => {
  return DemoStorage.isDemoMode();
};

export interface User {
  id: number;
  username?: string;
  windowsUsername?: string;
  displayName: string;
  email?: string;
  teamId: number;
  team?: Team;
  isActive?: boolean;
  role?: string;
  canManageMaintenance?: boolean; // Permiso para gestionar mantenimiento
}

export interface Team {
  id: number;
  name: string;
  description?: string;
  color?: string;
}

export interface Room {
  id: number;
  name: string;
  floor: number;
  capacity: number;
  status: 'Libre' | 'Ocupado' | 'Mantenimiento';
  currentReservation?: Reservation;
  nextReservation?: Reservation;
}

export interface Reservation {
  id: number;
  roomId: number;
  userId: number;
  user?: User;
  room?: Room;
  startTime: string;
  endTime: string;
  purpose: string;
  status: 'Active' | 'Completed' | 'Cancelled';
  createdAt?: string;
}

export interface CreateReservationDto {
  roomId: number;
  startTime: string;
  endTime: string;
  purpose: string;
}

export const api = {
  // ==================== USERS ====================
  getCurrentUser: async (): Promise<User | null> => {
    if (isDemoMode()) {
      return DemoStorage.getCurrentUser();
    }
    
    // Obtener desde localStorage (sesión local)
    const savedUser = localStorage.getItem('sisugrb_current_user');
    if (savedUser) {
      return JSON.parse(savedUser);
    }
    return null;
  },

  // Auto-login con Windows/Azure AD
  autoLogin: async (windowsUsername: string, displayName: string, email?: string): Promise<User> => {
    if (isDemoMode()) {
      throw new Error('Auto-login no disponible en modo demo. Por favor selecciona un usuario.');
    }
    
    const response = await fetch(`${API_BASE_URL}/users/auto-login`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ windowsUsername, displayName, email }),
    });
    
    if (!response.ok) {
      throw new Error('Error al iniciar sesión automáticamente');
    }
    
    const user = await response.json();
    localStorage.setItem('sisugrb_current_user', JSON.stringify(user));
    return user;
  },

  getUsers: async (): Promise<User[]> => {
    if (isDemoMode()) {
      return DemoStorage.getUsers();
    }
    
    const response = await fetch(`${API_BASE_URL}/users`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener usuarios');
    }
    
    return response.json();
  },

  loginUser: async (userId: number): Promise<User> => {
    // Buscar usuario en la lista
    const users = await api.getUsers();
    const user = users.find(u => u.id === userId);
    
    if (!user) {
      throw new Error('Usuario no encontrado');
    }
    
    if (isDemoMode()) {
      DemoStorage.saveCurrentUser(user);
    } else {
      localStorage.setItem('sisugrb_current_user', JSON.stringify(user));
    }
    
    return user;
  },

  updateUserTeam: async (userId: number, teamId: number): Promise<User> => {
    if (isDemoMode()) {
      throw new Error('Actualización de equipo no disponible en modo demo');
    }
    
    const response = await fetch(`${API_BASE_URL}/users/${userId}/team`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ teamId }),
    });
    
    if (!response.ok) {
      throw new Error('Error al actualizar equipo');
    }
    
    const user = await response.json();
    localStorage.setItem('sisugrb_current_user', JSON.stringify(user));
    return user;
  },

  logoutUser: () => {
    if (isDemoMode()) {
      DemoStorage.saveCurrentUser(null);
    } else {
      localStorage.removeItem('sisugrb_current_user');
    }
  },

  // ==================== ROOMS ====================
  getRooms: async (): Promise<Room[]> => {
    if (isDemoMode()) {
      return demoRooms;
    }
    
    const response = await fetch(`${API_BASE_URL}/rooms`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener salas');
    }
    
    return response.json();
  },

  getRoomById: async (id: number): Promise<Room> => {
    const response = await fetch(`${API_BASE_URL}/rooms/${id}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener sala');
    }
    
    return response.json();
  },

  updateRoomStatus: async (id: number, status: 'Libre' | 'Ocupado' | 'Mantenimiento'): Promise<void> => {
    const response = await fetch(`${API_BASE_URL}/rooms/${id}/status`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ status }),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al actualizar estado de la sala');
    }
  },

  // ==================== RESERVATIONS ====================
  getReservations: async (date?: string): Promise<Reservation[]> => {
    if (isDemoMode()) {
      const allReservations = DemoStorage.getReservations();
      
      if (!date) {
        return allReservations;
      }
      
      // Filtrar por fecha
      return allReservations.filter(r => {
        const reservationDate = new Date(r.startTime).toISOString().split('T')[0];
        return reservationDate === date;
      });
    }
    
    let url = `${API_BASE_URL}/reservations`;
    if (date) {
      url += `?date=${date}`;
    }
    
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener reservas');
    }
    
    return response.json();
  },

  createReservation: async (data: CreateReservationDto & { userId: number }): Promise<Reservation> => {
    if (isDemoMode()) {
      // Validar conflictos de horarios
      const existingReservations = DemoStorage.getReservations();
      const startTime = new Date(data.startTime);
      const endTime = new Date(data.endTime);
      
      console.log('🔍 Validando nueva reserva:', {
        sala: data.roomId,
        inicio: startTime.toLocaleString('es-ES'),
        fin: endTime.toLocaleString('es-ES'),
        totalReservas: existingReservations.length
      });
      
      // Filtrar solo reservas activas de la misma sala
      const activeReservationsInRoom = existingReservations.filter(r => 
        r.roomId === data.roomId && r.status === 'Active'
      );
      
      console.log(`📋 Reservas activas en sala ${data.roomId}:`, activeReservationsInRoom.map(r => ({
        id: r.id,
        usuario: r.user?.displayName,
        inicio: new Date(r.startTime).toLocaleString('es-ES'),
        fin: new Date(r.endTime).toLocaleString('es-ES'),
        status: r.status
      })));
      
      const conflictingReservation = activeReservationsInRoom.find(r => {
        const rStart = new Date(r.startTime);
        const rEnd = new Date(r.endTime);
        
        // Verificar solapamiento
        const hasOverlap = (startTime < rEnd && endTime > rStart);
        
        if (hasOverlap) {
          console.log('❌ Conflicto detectado con reserva:', {
            id: r.id,
            usuario: r.user?.displayName,
            inicio: rStart.toLocaleString('es-ES'),
            fin: rEnd.toLocaleString('es-ES')
          });
        }
        
        return hasOverlap;
      });
      
      if (conflictingReservation) {
        const rStart = new Date(conflictingReservation.startTime);
        const rEnd = new Date(conflictingReservation.endTime);
        throw new Error(
          `Ya existe una reserva en ese horario.\n` +
          `Sala ocupada por: ${conflictingReservation.user?.displayName}\n` +
          `Horario: ${rStart.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} - ${rEnd.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`
        );
      }
      
      // Verificar que no esté en mantenimiento
      const maintenanceRooms = DemoStorage.getMaintenance();
      if (maintenanceRooms.includes(data.roomId)) {
        throw new Error('La sala está en mantenimiento');
      }
      
      // Crear nueva reserva
      const users = DemoStorage.getUsers();
      const user = users.find(u => u.id === data.userId);
      const room = demoRooms.find(r => r.id === data.roomId);
      
      const newReservation: Reservation = {
        id: Math.max(...existingReservations.map(r => r.id), 0) + 1,
        roomId: data.roomId,
        userId: data.userId,
        user: user,
        room: room,
        startTime: data.startTime,
        endTime: data.endTime,
        purpose: data.purpose,
        status: 'Active',
        createdAt: new Date().toISOString(),
      };
      
      const updatedReservations = [...existingReservations, newReservation];
      DemoStorage.saveReservations(updatedReservations);
      
      console.log('✅ Reserva creada exitosamente en modo demo:', {
        id: newReservation.id,
        sala: room?.name,
        usuario: user?.displayName,
        horario: `${startTime.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} - ${endTime.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`
      });
      
      return newReservation;
    }
    
    const response = await fetch(`${API_BASE_URL}/reservations`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al crear reserva');
    }
    
    return response.json();
  },

  cancelReservation: async (id: number, userId: number): Promise<void> => {
    if (isDemoMode()) {
      const reservations = DemoStorage.getReservations();
      const reservation = reservations.find(r => r.id === id);
      
      if (!reservation) {
        throw new Error('Reserva no encontrada');
      }
      
      if (reservation.userId !== userId) {
        throw new Error('No tienes permiso para cancelar esta reserva');
      }
      
      // Marcar como cancelada
      const updatedReservations = reservations.map(r => 
        r.id === id ? { ...r, status: 'Cancelled' as const } : r
      );
      
      DemoStorage.saveReservations(updatedReservations);
      console.log('✅ Reserva cancelada en modo demo:', id);
      return;
    }
    
    const response = await fetch(`${API_BASE_URL}/reservations/${id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId }),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al cancelar reserva');
    }
  },

  getMyReservations: async (userId: number): Promise<Reservation[]> => {
    if (isDemoMode()) {
      const allReservations = DemoStorage.getReservations();
      return allReservations.filter(r => r.userId === userId);
    }
    
    const response = await fetch(`${API_BASE_URL}/reservations/user/${userId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener mis reservas');
    }
    
    return response.json();
  },

  // ==================== MAINTENANCE ====================
  getMaintenanceRooms: async (): Promise<number[]> => {
    if (isDemoMode()) {
      return DemoStorage.getMaintenance();
    }
    
    const response = await fetch(`${API_BASE_URL}/maintenance`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener mantenimiento');
    }
    
    return response.json();
  },

  toggleMaintenance: async (roomId: number, inMaintenance: boolean, userId: number): Promise<void> => {
    if (isDemoMode()) {
      // Verificar permisos
      const user = DemoStorage.getCurrentUser();
      if (!user?.canManageMaintenance) {
        throw new Error('No tienes permiso para gestionar mantenimiento');
      }
      
      const maintenanceRooms = DemoStorage.getMaintenance();
      
      let updated: number[];
      if (inMaintenance) {
        // Agregar a mantenimiento
        if (!maintenanceRooms.includes(roomId)) {
          updated = [...maintenanceRooms, roomId];
        } else {
          updated = maintenanceRooms;
        }
      } else {
        // Quitar de mantenimiento
        updated = maintenanceRooms.filter(id => id !== roomId);
      }
      
      DemoStorage.saveMaintenance(updated);
      console.log('✅ Mantenimiento actualizado en modo demo:', { roomId, inMaintenance });
      return;
    }
    
    const response = await fetch(`${API_BASE_URL}/maintenance/toggle`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ roomId, inMaintenance, userId }),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al actualizar mantenimiento');
    }
  },

  // ==================== TEAMS ====================
  getTeams: async (): Promise<Team[]> => {
    if (isDemoMode()) {
      return demoTeams;
    }
    
    // Por ahora no lo necesitamos, los usuarios ya tienen su equipo
    return [];
  },

  // ==================== HEALTH CHECK ====================
  checkBackendHealth: async (): Promise<boolean> => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f5c6167b/health`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  },
};

// Exportar también como función standalone para compatibilidad
export const checkBackendHealth = api.checkBackendHealth;