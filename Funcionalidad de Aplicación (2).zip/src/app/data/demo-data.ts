import { User, Room, Reservation, Team } from '../services/api';

// EQUIPOS DE SISU GRB
export const DEMO_TEAMS: Team[] = [
  {
    id: 1,
    name: 'Equipo de Suscripción',
    description: 'Análisis y evaluación de riesgos',
    color: '#3B82F6'
  },
  {
    id: 2,
    name: 'Equipo de Reclamaciones',
    description: 'Gestión de siniestros',
    color: '#EF4444'
  },
  {
    id: 3,
    name: 'Equipo Financiero',
    description: 'Contabilidad y finanzas',
    color: '#10B981'
  },
  {
    id: 4,
    name: 'Equipo Comercial',
    description: 'Ventas y desarrollo de negocio',
    color: '#F59E0B'
  },
  {
    id: 5,
    name: 'Equipo de Operaciones',
    description: 'Gestión operativa',
    color: '#8B5CF6'
  },
  {
    id: 6,
    name: 'Equipo Legal',
    description: 'Asesoría legal y compliance',
    color: '#EC4899'
  },
  {
    id: 7,
    name: 'Equipo de Actuaría',
    description: 'Análisis actuarial y estadístico',
    color: '#14B8A6'
  },
  {
    id: 8,
    name: 'Equipo de Tecnología',
    description: 'Desarrollo y sistemas',
    color: '#6366F1'
  },
  {
    id: 9,
    name: 'Servicios',
    description: 'Mantenimiento y soporte',
    color: '#F97316'
  }
];

// USUARIOS DE DEMO (Solo 3 usuarios con formato Active Directory correcto)
export const DEMO_USERS: User[] = [
  {
    id: 1,
    username: 'azuread\\rcoloapa',
    displayName: 'Raymundo Coloapa Frago',
    email: 'rcoloapa@sisugrb.com',
    team: {
      id: 1,
      name: 'Tecnología',
      color: '#3B82F6'
    },
    role: 'Jr. Desarrollador'
  },
  {
    id: 2,
    username: 'azuread\\mblanco',
    displayName: 'Mario Blanco',
    email: 'mblanco@sisugrb.com',
    team: {
      id: 1,
      name: 'Tecnología',
      color: '#3B82F6'
    },
    role: 'Subgerente de TI'
  },
  {
    id: 3,
    username: 'azuread\\mmeza',
    displayName: 'Margarita Meza',
    email: 'mmeza@sisugrb.com',
    team: {
      id: 1,
      name: 'Tecnología',
      color: '#3B82F6'
    },
    role: 'Sr. Analista'
  },
  {
    id: 4,
    username: 'azuread\\jlpimienta',
    displayName: 'José Luis Pimienta',
    email: 'jlpimienta@sisugrb.com',
    team: {
      id: 9,
      name: 'Servicios',
      color: '#F97316'
    },
    role: 'Supervisor de Mantenimiento'
  }
];

// SALAS DE SISU GRB
export const DEMO_ROOMS: Room[] = [
  {
    id: 1,
    name: 'Sala Piso 1',
    capacity: 10,
    floor: 1,
    status: 'Libre',
    currentReservation: undefined,
    nextReservation: undefined
  },
  {
    id: 2,
    name: 'Sala Piso 2',
    capacity: 10,
    floor: 2,
    status: 'Libre',
    currentReservation: undefined,
    nextReservation: undefined
  },
  {
    id: 3,
    name: 'Sala Piso 3 - Capacitación',
    capacity: 30,
    floor: 3,
    status: 'Libre',
    currentReservation: undefined,
    nextReservation: undefined
  }
];

// RESERVAS INICIALES DE DEMO (iniciar vacío, solo usuarios reales pueden crear reservas)
export const DEMO_RESERVATIONS: Reservation[] = [];