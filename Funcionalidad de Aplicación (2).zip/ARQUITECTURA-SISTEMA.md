# 🏗️ ARQUITECTURA DEL SISTEMA - SISU GRB

Este documento explica cómo funciona tu aplicación de gestión de salas por dentro.

---

## 📊 Diagrama General

```
┌─────────────────────────────────────────────────────────────────┐
│                      USUARIO FINAL                               │
│                   (Empleado de SISU GRB)                         │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ Windows Authentication
                         │ (SISUGRB\usuario)
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                     NAVEGADOR WEB                                │
│                  http://localhost:5173                           │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │               FRONTEND (React + TypeScript)                 │ │
│  │                                                              │ │
│  │  • App.tsx (Componente principal)                          │ │
│  │  • room-card-large.tsx (Tarjetas de salas)                 │ │
│  │  • quick-reservation-form.tsx (Formulario de reservas)     │ │
│  │  • api.ts (Cliente API)                                    │ │
│  │                                                              │ │
│  │  Tecnologías:                                               │ │
│  │  ✓ React 18                                                 │ │
│  │  ✓ TypeScript                                               │ │
│  │  ✓ Tailwind CSS v4                                          │ │
│  │  ✓ Vite (Build tool)                                        │ │
│  └────────────────────────────────────────────────────────────┘ │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ HTTP/REST API
                         │ fetch() con credentials: 'include'
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                 BACKEND (.NET 8 Web API)                         │
│                  http://localhost:5000/api                       │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                      CONTROLLERS                            │ │
│  │                                                              │ │
│  │  ┌──────────────────┐  ┌──────────────────┐               │ │
│  │  │ UsersController  │  │ RoomsController  │               │ │
│  │  │                  │  │                  │               │ │
│  │  │ GET /current     │  │ GET /rooms       │               │ │
│  │  │ GET /users       │  │ GET /rooms/{id}  │               │ │
│  │  │ GET /teams       │  │ POST /reserv.    │               │ │
│  │  │                  │  │ DELETE /reserv.  │               │ │
│  │  └──────────────────┘  └──────────────────┘               │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                    ENTITY FRAMEWORK CORE                    │ │
│  │                      (AppDbContext)                          │ │
│  │                                                              │ │
│  │  DbSet<User>         DbSet<Team>                            │ │
│  │  DbSet<Room>         DbSet<Reservation>                     │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  Tecnologías:                                                    │
│  ✓ ASP.NET Core 8.0                                             │
│  ✓ Entity Framework Core                                        │
│  ✓ Windows Authentication (Negotiate)                           │
│  ✓ Swagger/OpenAPI                                              │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ ADO.NET / Entity Framework
                         │ Connection String
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│              SQL SERVER EXPRESS 2022                             │
│            Database: SisuGrbRoomReservations                     │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                         TABLAS                              │ │
│  │                                                              │ │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │ │
│  │  │   Users     │  │    Teams    │  │    Rooms    │        │ │
│  │  │─────────────│  │─────────────│  │─────────────│        │ │
│  │  │ Id          │  │ Id          │  │ Id          │        │ │
│  │  │ Windows...  │  │ Name        │  │ Name        │        │ │
│  │  │ DisplayName │  │ Color       │  │ Floor       │        │ │
│  │  │ Email       │  │             │  │ Capacity    │        │ │
│  │  │ TeamId   ───┼──┼→            │  │ Status      │        │ │
│  │  │ IsActive    │  │             │  │             │        │ │
│  │  └─────────────┘  └─────────────┘  └─────────────┘        │ │
│  │                                                              │ │
│  │  ┌──────────────────────────────────────┐                  │ │
│  │  │          Reservations                │                  │ │
│  │  │──────────────────────────────────────│                  │ │
│  │  │ Id                                   │                  │ │
│  │  │ RoomId        ───────────────────────┼──→ Rooms.Id     │ │
│  │  │ UserId        ───────────────────────┼──→ Users.Id     │ │
│  │  │ StartTime                            │                  │ │
│  │  │ EndTime                              │                  │ │
│  │  │ Purpose                              │                  │ │
│  │  │ Status (Active/Completed/Cancelled)  │                  │ │
│  │  │ CreatedAt                            │                  │ │
│  │  └──────────────────────────────────────┘                  │ │
│  │                                                              │ │
│  └────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Flujo de Datos - Ejemplo: Crear una Reserva

```
1. USUARIO hace click en "Reservar" en una sala
   │
   ▼
2. FRONTEND (React)
   │ - Abre modal QuickReservationForm
   │ - Usuario llena: horario, propósito
   │ - Click en "Confirmar Reserva"
   │
   ▼
3. FRONTEND llama a la API
   │
   fetch('http://localhost:5000/api/rooms/reservations', {
     method: 'POST',
     credentials: 'include',  ← Envía cookie de Windows Auth
     body: JSON.stringify({
       roomId: 1,
       startTime: '2026-02-11T10:00:00',
       endTime: '2026-02-11T11:00:00',
       purpose: 'Reunión de equipo'
     })
   })
   │
   ▼
4. BACKEND (.NET) recibe la petición
   │
   RoomsController.CreateReservation()
   │ 
   │ ① Obtiene usuario actual desde Windows (HttpContext.User.Identity.Name)
   │    → "SISUGRB\jperez"
   │
   │ ② Busca el usuario en la base de datos
   │    → SELECT * FROM Users WHERE WindowsUsername = 'SISUGRB\jperez'
   │
   │ ③ Valida que la sala exista
   │    → SELECT * FROM Rooms WHERE Id = 1
   │
   │ ④ Valida horario de operación (8:30 AM - 6:00 PM, Lunes-Viernes)
   │
   │ ⑤ Valida que no haya conflictos de horario
   │    → SELECT * FROM Reservations 
   │      WHERE RoomId = 1 
   │      AND Status = 'Active'
   │      AND (StartTime < '11:00' AND EndTime > '10:00')
   │
   │ ⑥ Si todo OK, crea la reserva
   │    → INSERT INTO Reservations (RoomId, UserId, StartTime, EndTime, Purpose, Status)
   │      VALUES (1, 5, '2026-02-11 10:00', '2026-02-11 11:00', 'Reunión...', 'Active')
   │
   │ ⑦ Actualiza el estado de la sala si es necesario
   │    → UPDATE Rooms SET Status = 'Ocupado' WHERE Id = 1
   │
   ▼
5. SQL SERVER ejecuta las queries
   │ - Inserta la reserva
   │ - Actualiza la sala
   │ - Confirma la transacción
   │
   ▼
6. BACKEND responde al FRONTEND
   │
   {
     "id": 42,
     "roomId": 1,
     "userId": 5,
     "user": {
       "displayName": "Juan Pérez",
       "team": { "name": "Desarrollo", "color": "#EF4444" }
     },
     "startTime": "2026-02-11T10:00:00",
     "endTime": "2026-02-11T11:00:00",
     "purpose": "Reunión de equipo",
     "status": "Active",
     "createdAt": "2026-02-11T09:45:00"
   }
   │
   ▼
7. FRONTEND actualiza la UI
   │ - Cierra el modal
   │ - Agrega la reserva a la lista
   │ - Actualiza el contador de la sala
   │ - Muestra toast de éxito ✅
   │
   ▼
8. USUARIO ve la reserva confirmada
```

---

## 🔐 Autenticación de Windows - ¿Cómo funciona?

```
Usuario abre la app en el navegador
   │
   ▼
Browser envía credenciales de Windows automáticamente
   │ (Negotiate/NTLM Authentication)
   │
   ▼
Backend .NET recibe el usuario
   │
   HttpContext.User.Identity.Name
   │ → "SISUGRB\jperez"
   │
   ▼
Backend busca en la base de datos
   │
   SELECT * FROM Users WHERE WindowsUsername = 'SISUGRB\jperez'
   │
   ▼
Si existe → Usuario autenticado ✅
Si NO existe → Error 401 Unauthorized ❌
```

**Ventajas de Windows Authentication:**
- ✅ **Sin contraseñas**: Usa las credenciales de Windows
- ✅ **Single Sign-On**: Una sola autenticación para todo
- ✅ **Seguro**: Integrado con Active Directory de la empresa
- ✅ **Auditable**: Siempre sabes quién hizo qué

---

## 📁 Estructura de Archivos del Proyecto

```
/
├── 📁 src/                               ← FRONTEND
│   ├── 📁 app/
│   │   ├── App.tsx                       ← Componente principal
│   │   ├── 📁 components/
│   │   │   ├── room-card-large.tsx       ← Tarjeta de sala individual
│   │   │   ├── quick-reservation-form.tsx← Formulario de reserva
│   │   │   ├── room-details.tsx          ← Detalles de sala
│   │   │   └── 📁 ui/                    ← Componentes shadcn/ui
│   │   │       ├── button.tsx
│   │   │       ├── dialog.tsx
│   │   │       ├── calendar.tsx
│   │   │       └── ... (40+ componentes)
│   │   ├── 📁 services/
│   │   │   └── api.ts                    ← Cliente API (llamadas fetch)
│   │   ├── 📁 types/
│   │   │   └── index.ts                  ← Tipos TypeScript
│   │   └── 📁 data/
│   │       └── mock-data.ts              ← Datos de prueba (ELIMINAR después)
│   ├── 📁 styles/
│   │   ├── index.css                     ← Estilos globales
│   │   └── theme.css                     ← Tema de colores SISU GRB
│   └── main.tsx                          ← Entry point de React
│
├── 📁 backend-dotnet/                    ← BACKEND
│   ├── 📁 Controllers/
│   │   ├── UsersController.cs            ← Endpoints de usuarios
│   │   └── RoomsController.cs            ← Endpoints de salas y reservas
│   ├── 📁 Models/
│   │   ├── User.cs                       ← Modelo de usuario
│   │   ├── Team.cs                       ← Modelo de equipo
│   │   ├── Room.cs                       ← Modelo de sala
│   │   └── Reservation.cs                ← Modelo de reserva
│   ├── 📁 Data/
│   │   └── AppDbContext.cs               ← Contexto de Entity Framework
│   ├── 📁 SQL/
│   │   └── 01-create-database.sql        ← Script de creación de BD
│   ├── Program.cs                        ← Configuración de .NET
│   └── appsettings.json                  ← Connection string y config
│
├── package.json                          ← Dependencias de Node.js
├── vite.config.ts                        ← Configuración de Vite
└── tsconfig.json                         ← Configuración de TypeScript
```

---

## 🌐 API Endpoints Disponibles

### **Usuarios**

| Método | Endpoint | Descripción | Autenticación |
|--------|----------|-------------|---------------|
| GET | `/api/users/current` | Obtener usuario actual (Windows Auth) | ✅ Requerida |
| GET | `/api/users` | Listar todos los usuarios activos | ✅ Requerida |
| GET | `/api/users/teams` | Listar todos los equipos | ✅ Requerida |

### **Salas**

| Método | Endpoint | Descripción | Autenticación |
|--------|----------|-------------|---------------|
| GET | `/api/rooms` | Listar todas las salas con estado actual | ✅ Requerida |
| GET | `/api/rooms/{id}` | Obtener detalles de una sala específica | ✅ Requerida |
| PUT | `/api/rooms/{id}/status` | Cambiar estado (Libre/Ocupado/Mantenimiento) | ✅ Requerida |

### **Reservas**

| Método | Endpoint | Descripción | Autenticación |
|--------|----------|-------------|---------------|
| GET | `/api/rooms/reservations` | Todas las reservas (filtro por fecha opcional) | ✅ Requerida |
| GET | `/api/rooms/reservations/my` | Mis reservas (usuario actual) | ✅ Requerida |
| POST | `/api/rooms/reservations` | Crear nueva reserva | ✅ Requerida |
| DELETE | `/api/rooms/reservations/{id}` | Cancelar reserva (solo organizador) | ✅ Requerida |

---

## 🔒 Validaciones de Negocio

El backend implementa estas reglas automáticamente:

### **Horario de Operación**
- ⏰ **Lunes a Viernes**: 8:30 AM - 6:00 PM
- ❌ **Fines de semana**: No permitido
- ❌ **Fuera de horario**: No permitido

### **Validaciones de Reserva**
- ✅ Sala debe existir y estar activa
- ✅ Usuario debe existir en la base de datos
- ✅ No puede haber conflictos de horario
- ✅ Hora de inicio < Hora de fin
- ✅ Duración mínima: 30 minutos
- ✅ Duración máxima: 4 horas

### **Cancelación de Reserva**
- ✅ Solo el organizador puede cancelar
- ✅ No se puede cancelar reservas completadas
- ✅ Al cancelar, la sala vuelve a estado "Libre"

---

## 🚀 Tecnologías Utilizadas

### **Frontend**
- **React 18**: Framework UI
- **TypeScript**: Tipado estático
- **Tailwind CSS v4**: Estilos utility-first
- **Vite**: Build tool y dev server
- **shadcn/ui**: Componentes UI pre-construidos
- **Lucide React**: Iconos
- **Sonner**: Notificaciones toast

### **Backend**
- **ASP.NET Core 8.0**: Framework web
- **Entity Framework Core**: ORM
- **SQL Server Express**: Base de datos
- **Windows Authentication**: Autenticación integrada
- **Swagger/OpenAPI**: Documentación de API

---

## 🔄 Ciclo de Vida de la Aplicación

### **Inicio de la Aplicación**

```
1. Usuario ejecuta: start-sisugrb-local.bat
   │
   ├─→ Verifica que SQL Server esté corriendo
   │   └─→ Si no, lo inicia
   │
   ├─→ Inicia Backend .NET (http://localhost:5000)
   │   ├─→ Carga configuración de appsettings.json
   │   ├─→ Conecta con SQL Server
   │   ├─→ Configura Windows Authentication
   │   └─→ Inicia API y Swagger
   │
   ├─→ Inicia Frontend React (http://localhost:5173)
   │   ├─→ Compila código TypeScript
   │   ├─→ Inicia Vite dev server
   │   └─→ Abre navegador
   │
   └─→ Usuario ve la app en el navegador
       └─→ Windows Auth automática
           └─→ Carga salas y reservas
```

### **Uso Normal**

```
Usuario interactúa con la UI
   │
   ├─→ Ver salas
   │   └─→ GET /api/rooms
   │       └─→ Muestra estado en tiempo real
   │
   ├─→ Hacer reserva
   │   └─→ POST /api/rooms/reservations
   │       ├─→ Validaciones en backend
   │       ├─→ Guarda en SQL Server
   │       └─→ Actualiza UI
   │
   └─→ Cancelar reserva
       └─→ DELETE /api/rooms/reservations/{id}
           ├─→ Verifica permisos (solo organizador)
           ├─→ Marca como cancelada en BD
           └─→ Libera la sala
```

---

## 📊 Modelo de Datos (Relaciones)

```
Teams ────┐
     1    │
     ↑    │
     │    │
     │ N  │
   Users ─┴──────┐
     1           │
     ↑           │
     │           │
     │ N         │ N
 Reservations ───┴→ Rooms
                       1
```

**Explicación:**
- Un **Team** tiene muchos **Users**
- Un **User** puede tener muchas **Reservations**
- Una **Room** puede tener muchas **Reservations**
- Una **Reservation** pertenece a un **User** y una **Room**

---

## 💡 Próximas Mejoras Posibles

### **Fase 2: Funcionalidad Avanzada**
- [ ] Sistema de notificaciones (recordatorios de reservas)
- [ ] Reservas recurrentes (diarias, semanales)
- [ ] Panel de administración
- [ ] Reportes y estadísticas de uso
- [ ] Integración con Outlook Calendar

### **Fase 3: Deployment**
- [ ] Publicar backend como Windows Service
- [ ] Configurar IIS para hosting
- [ ] Crear instalador MSI
- [ ] Configurar red local (LAN access)
- [ ] Backup automático de base de datos

---

**¿Tienes preguntas sobre la arquitectura?**
Consulta los archivos de documentación específicos para más detalles.

---

*Sistema diseñado para SISU GRB • Gestión Inteligente de Salas de Juntas*
