# ⚡ Inicio Rápido - Despliegue en 10 Minutos

## 🎯 Objetivo
Desplegar el sistema SISU GRB en producción para 50 usuarios simultáneos.

---

## 📦 Opción 1: Script Automático (Windows)

### ¡La forma más rápida!

```batch
# Ejecutar este archivo:
deploy-backend.bat
```

El script automáticamente:
1. ✅ Verifica instalación de Supabase CLI
2. ✅ Inicia sesión en Supabase
3. ✅ Vincula tu proyecto
4. ✅ Configura variables de entorno
5. ✅ Despliega el backend
6. ✅ Verifica que funcione

**Tiempo estimado:** 5 minutos

---

## 🖐️ Opción 2: Manual (Todas las plataformas)

### Paso 1: Instalar Supabase CLI (1 minuto)

```bash
npm install -g supabase
```

### Paso 2: Login y vincular (1 minuto)

```bash
supabase login
supabase link --project-ref daowqmfdusubyicuuowy
```

### Paso 3: Configurar secrets (2 minutos)

```bash
supabase secrets set SUPABASE_URL="https://daowqmfdusubyicuuowy.supabase.co"
supabase secrets set SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRhb3dxbWZkdXN1YnlpY3V1b3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg3MTM5OTMsImV4cCI6MjA1NDI4OTk5M30.oGsN88CQKfGTKWPzCemCRWgvuPSukNRZe_K31YSy7_c"

# Obtén estos valores del Dashboard de Supabase:
supabase secrets set SUPABASE_SERVICE_ROLE_KEY="TU_SERVICE_ROLE_KEY"
supabase secrets set SUPABASE_DB_URL="TU_DATABASE_URL"
```

**Dónde encontrar las claves:**
- Dashboard → Settings → API → `service_role` (secret)
- Dashboard → Settings → Database → Connection String → URI

### Paso 4: Desplegar backend (1 minuto)

```bash
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

### Paso 5: Verificar (30 segundos)

Abre en el navegador:
```
https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/health
```

Deberías ver:
```json
{ "status": "ok", "message": "SISU GRB API funcionando" }
```

✅ **¡Backend listo!**

---

## 🌐 Desplegar Frontend

### Opción A: Vercel (Recomendado)

1. Ve a [vercel.com](https://vercel.com)
2. Click "New Project"
3. Importa tu repositorio Git
4. Configuración automática detectada
5. Click "Deploy"
6. ¡Listo en 2 minutos!

### Opción B: Netlify

1. Ve a [netlify.com](https://netlify.com)
2. Arrastra la carpeta después de `npm run build`
3. O conecta tu repositorio Git
4. Deploy automático
5. ¡Listo!

### Opción C: Manual

```bash
npm run build
# Copia la carpeta 'dist' a tu servidor web
```

---

## ✅ Verificación Rápida

### 1. Backend funcionando
```bash
curl https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/health
```

### 2. Frontend funcionando
- Abre la URL de tu aplicación
- Verifica ícono WiFi verde en la esquina superior derecha

### 3. Funcionalidad básica
- [ ] Login con tu nombre
- [ ] Ver las 3 salas
- [ ] Crear una reserva
- [ ] Ver "Mis Reservas"
- [ ] Cancelar la reserva

---

## 🚨 Problemas Comunes

### "Failed to fetch"
**Solución:** El backend no está desplegado. Ejecuta:
```bash
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

### "CORS error"
**Solución:** Re-despliega el backend con el comando de arriba.

### No aparecen las salas
**Solución:** Verifica la consola del navegador (F12). Debe mostrar conexión exitosa.

### Error de autenticación
**Solución:** Verifica que las claves en `/utils/supabase/info.tsx` sean correctas.

---

## 📊 Checklist Mínimo para Producción

- [ ] Backend desplegado y health check OK
- [ ] Frontend desplegado y accesible
- [ ] Ícono de conexión verde
- [ ] Puedes crear y cancelar reservas
- [ ] Funciona en móvil

---

## 🎯 Después del Despliegue

### Compartir con el equipo
```
URL de la aplicación: https://tu-app.vercel.app
Usuario: Ingresa tu nombre y email
Salas disponibles: 3 (Piso 1, 2, y 3)
Horario: Lunes a Viernes, 8:30 AM - 6:00 PM
```

### Monitoreo
```bash
# Ver logs en tiempo real:
supabase functions logs make-server-f5c6167b --follow
```

### Actualizar código
```bash
# Después de hacer cambios en el backend:
supabase functions deploy make-server-f5c6167b --no-verify-jwt

# Frontend se actualiza automáticamente si usas Vercel/Netlify con Git
```

---

## 📚 Documentación Completa

Para más detalles, consulta:
- **Guía completa:** `GUIA-DESPLIEGUE-COMPLETA.md`
- **Troubleshooting:** `GUIA-DESPLIEGUE-COMPLETA.md#troubleshooting`
- **Configuración de producción:** `GUIA-DESPLIEGUE-COMPLETA.md#producción`

---

## 💡 Consejos

1. **Usa el script automático** si estás en Windows (más fácil)
2. **Vercel es la opción más rápida** para el frontend
3. **Guarda las URLs** del backend y frontend
4. **Monitorea los logs** la primera semana
5. **Prueba desde móvil** antes de compartir con el equipo

---

## 🎉 ¡Listo!

Tu aplicación debería estar funcionando en:
- ✅ Laptops (Windows, Mac, Linux)
- ✅ Celulares (Android, iOS)
- ✅ Tablets
- ✅ 50+ usuarios simultáneos sin problemas

**URLs importantes:**
- **Backend:** `https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b`
- **Frontend:** `https://tu-aplicacion.vercel.app` (o tu URL)
- **Dashboard:** `https://supabase.com/dashboard/project/daowqmfdusubyicuuowy`

---

**¿Necesitas ayuda?** Consulta la [Guía Completa](GUIA-DESPLIEGUE-COMPLETA.md) con instrucciones detalladas y troubleshooting.
