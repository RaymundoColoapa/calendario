# 🚀 Instrucciones de Despliegue - Sistema SISU GRB

## ⚠️ PROBLEMA ACTUAL

El error **"Failed to fetch"** indica que el **backend NO está desplegado** en Supabase todavía. El código del servidor existe en este proyecto, pero necesita ser desplegado a Supabase Edge Functions.

## 📋 Pasos para Desplegar el Backend

### 1. **Instalar Supabase CLI**

```bash
# En Windows (PowerShell como Administrador)
scoop install supabase

# O con npm
npm install -g supabase
```

### 2. **Iniciar Sesión en Supabase**

```bash
supabase login
```

Esto abrirá tu navegador para autenticarte con tu cuenta de Supabase.

### 3. **Vincular tu Proyecto**

```bash
# En la carpeta raíz de tu proyecto
supabase link --project-ref daowqmfdusubyicuuowy
```

### 4. **Desplegar la Edge Function**

```bash
# Desplegar la función del servidor
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

La opción `--no-verify-jwt` es importante porque estamos usando el `publicAnonKey` para autenticación.

### 5. **Verificar el Despliegue**

Una vez desplegado, puedes verificar que funciona visitando:

```
https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/health
```

Deberías recibir:
```json
{
  "status": "ok",
  "message": "SISU GRB API funcionando"
}
```

---

## 🔧 Configuración de Secrets en Supabase

El backend necesita las siguientes variables de entorno configuradas en Supabase:

```bash
# Configurar secrets
supabase secrets set SUPABASE_URL=https://daowqmfdusubyicuuowy.supabase.co
supabase secrets set SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=<tu-service-role-key>
supabase secrets set SUPABASE_DB_URL=<tu-db-url>
```

**IMPORTANTE:** El `SUPABASE_SERVICE_ROLE_KEY` se encuentra en:
- Dashboard de Supabase → Settings → API → `service_role` key (secret)

---

## 🌐 Alternativa: Desplegar desde el Dashboard de Supabase

Si prefieres usar la interfaz web:

1. Ve a tu proyecto en https://supabase.com/dashboard
2. Click en **Edge Functions** en el menú lateral
3. Click en **"New Function"**
4. Nombra la función: `make-server-f5c6167b`
5. Copia el contenido de `/supabase/functions/server/index.tsx`
6. También necesitas copiar `/supabase/functions/server/kv_store.tsx` como un módulo
7. Click en **Deploy**

---

## 📱 Verificación Post-Despliegue

Una vez desplegado el backend:

1. **Abre la aplicación** en tu navegador
2. **Verifica el indicador de conexión** (ícono WiFi en la esquina superior derecha)
   - 🟢 Verde = Conectado
   - 🔴 Rojo = Sin conexión

3. **Revisa la consola del navegador** (F12)
   - Busca mensajes de error
   - Verifica que no haya errores de CORS

4. **Prueba crear un usuario**
   - Login con tu nombre y email
   - Debería crear tu usuario automáticamente

5. **Prueba crear una reserva**
   - Selecciona una sala y horario
   - Si funciona, el backend está correctamente configurado

---

## 🐛 Troubleshooting

### Error: "Failed to fetch"
**Causa:** El backend no está desplegado o la URL es incorrecta  
**Solución:** Sigue los pasos de despliegue arriba

### Error: "CORS"
**Causa:** La función no tiene los headers CORS correctos  
**Solución:** Verifica que el servidor tenga `app.use('*', cors({ origin: '*' }))`

### Error: "No authorized"
**Causa:** La clave `publicAnonKey` es incorrecta  
**Solución:** Verifica que `/utils/supabase/info.tsx` tenga la clave correcta

### Error: "Timeout"
**Causa:** La función tarda demasiado en responder  
**Solución:** Verifica los logs en Supabase Dashboard → Edge Functions → Logs

---

## 📊 Monitoreo Post-Despliegue

### Ver Logs del Servidor

```bash
# Ver logs en tiempo real
supabase functions logs make-server-f5c6167b
```

O desde el Dashboard:
- Edge Functions → `make-server-f5c6167b` → Logs

### Endpoints Disponibles

Una vez desplegado, estos endpoints estarán activos:

```
GET  /health                              # Health check
GET  /api/users                           # Listar usuarios
POST /api/users/auto-login                # Auto-login
GET  /api/rooms                           # Listar salas
GET  /api/reservations?date=YYYY-MM-DD    # Listar reservas
POST /api/reservations                    # Crear reserva
DELETE /api/reservations/:id              # Cancelar reserva
GET  /api/maintenance                     # Salas en mantenimiento
POST /api/maintenance/toggle              # Toggle mantenimiento
GET  /api/debug/reservations              # Ver todas las reservas (debug)
DELETE /api/reservations/admin/clear-all  # Limpiar reservas (debug)
```

---

## 🎯 Checklist de Despliegue

- [ ] Supabase CLI instalado
- [ ] Sesión iniciada en Supabase
- [ ] Proyecto vinculado
- [ ] Edge Function desplegada
- [ ] Secrets configurados
- [ ] Health check respondiendo OK
- [ ] Aplicación frontend puede conectarse
- [ ] Usuarios pueden registrarse
- [ ] Reservas se pueden crear y cancelar
- [ ] Panel de mantenimiento funciona (para usuarios autorizados)

---

## 🔒 Seguridad

**IMPORTANTE - ANTES DE PRODUCCIÓN:**

1. **Proteger el endpoint de limpieza de reservas**
   - Cambiar la clave `sisugrb-admin-2026` por algo más seguro
   - O mejor, crear un sistema de autenticación de admin real

2. **Configurar Row Level Security (RLS)** en Supabase
   - Solo los dueños pueden cancelar sus reservas
   - Solo usuarios autorizados pueden gestionar mantenimiento

3. **Cambiar las claves de API** si fueron expuestas públicamente

4. **Habilitar SSL/HTTPS** para todas las conexiones

---

## 📞 Soporte

Si tienes problemas:

1. **Revisa los logs** del servidor en Supabase Dashboard
2. **Revisa la consola del navegador** (F12 → Console)
3. **Verifica la conexión a internet**
4. **Comprueba que las credenciales de Supabase sean correctas**

---

## 🎉 Una vez Todo Funcione

¡Felicidades! Tu sistema de reservas está en producción. Ahora puedes:

- ✅ Agregar más usuarios
- ✅ Crear y cancelar reservas
- ✅ Gestionar mantenimiento de salas
- ✅ Ver el estado en tiempo real de las salas
- ✅ Usar desde laptops y celulares (responsive)

**Para 50 usuarios simultáneos**, Supabase puede manejar la carga sin problemas con la configuración actual.
