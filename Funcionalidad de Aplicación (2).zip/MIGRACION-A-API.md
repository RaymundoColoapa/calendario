# 🔄 GUÍA DE MIGRACIÓN: De localStorage a API .NET

Esta guía te ayudará a convertir tu aplicación React actual (que usa datos mock y localStorage) para que use el backend .NET con SQL Server.

---

## 📝 Resumen de Cambios Necesarios

### Archivos que necesitamos modificar:
1. ✅ `/src/app/services/api.ts` - **YA CREADO** ✨
2. ⏳ `/src/app/App.tsx` - Actualizar para usar API
3. ⏳ `/src/app/components/quick-reservation-form.tsx` - Conectar con API
4. ⏳ `/src/app/components/room-card-large.tsx` - Actualizar cambios de estado
5. ⏳ `/src/app/components/windows-login.tsx` - Eliminar (ya no se necesita con Windows Auth)

---

## 🎯 PASO 1: Actualizar App.tsx

El cambio principal es eliminar `localStorage` y `mockData`, y usar la API real.

### Cambios a realizar:

**ANTES:**
```typescript
const [currentUser, setCurrentUser] = useState<TeamMember | null>(null);
const [isAuthenticated, setIsAuthenticated] = useState(false);

useEffect(() => {
  const savedUser = localStorage.getItem("sisugrb_windows_user");
  // ... código de localStorage
}, []);
```

**DESPUÉS:**
```typescript
const [currentUser, setCurrentUser] = useState<User | null>(null);
const [isAuthenticated, setIsAuthenticated] = useState(false);
const [isLoading, setIsLoading] = useState(true);

useEffect(() => {
  loadInitialData();
}, []);

const loadInitialData = async () => {
  try {
    setIsLoading(true);
    
    // 1. Cargar usuario actual (Windows Auth automática)
    const user = await api.getCurrentUser();
    setCurrentUser(user);
    setIsAuthenticated(true);
    
    // 2. Cargar salas con sus reservas
    const roomsData = await api.getRooms();
    setRooms(roomsData);
    
    // 3. Cargar todas las reservas del día
    const today = new Date().toISOString().split('T')[0];
    const reservationsData = await api.getReservations(today);
    setReservations(reservationsData);
    
    // 4. Cargar usuarios para autocompletado
    const usersData = await api.getUsers();
    setTeamMembers(usersData);
    
    toast.success(`Bienvenido/a, ${user.displayName}!`);
  } catch (error) {
    console.error('Error al cargar datos:', error);
    toast.error('Error al conectar con el servidor. Verifica que el backend esté corriendo.');
    setIsAuthenticated(false);
  } finally {
    setIsLoading(false);
  }
};
```

### Eliminar la pantalla de login

Como ahora usamos Windows Authentication, el usuario ya está autenticado automáticamente:

**ELIMINAR:**
```typescript
if (!isAuthenticated || !currentUser) {
  return <WindowsLogin teamMembers={teamMembers} onLogin={handleLogin} />;
}
```

**REEMPLAZAR con:**
```typescript
if (isLoading) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-neutral-100 via-neutral-200 to-neutral-300">
      <div className="text-center">
        <img src={logo} alt="SISU GRB Logo" className="h-20 w-auto mx-auto mb-4" />
        <p className="text-lg text-neutral-700">Cargando...</p>
      </div>
    </div>
  );
}

if (!isAuthenticated || !currentUser) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-neutral-100 via-neutral-200 to-neutral-300">
      <div className="text-center">
        <img src={logo} alt="SISU GRB Logo" className="h-20 w-auto mx-auto mb-4" />
        <p className="text-lg text-red-600 font-semibold">Error de autenticación</p>
        <p className="text-neutral-700 mt-2">
          No se pudo autenticar tu usuario de Windows.
          <br />
          Contacta al administrador del sistema.
        </p>
      </div>
    </div>
  );
}
```

---

## 🎯 PASO 2: Actualizar handleAddReservation

**ANTES (localStorage):**
```typescript
const handleAddReservation = (reservation: Omit<Reservation, "id">) => {
  const newReservation: Reservation = {
    ...reservation,
    id: `r${Date.now()}`,
  };
  setReservations((prev) => [...prev, newReservation]);
  toast.success(`Reserva confirmada para ${reservation.organizer}`);
  setSelectedRoomForReservation(null);
};
```

**DESPUÉS (API):**
```typescript
const handleAddReservation = async (reservationData: CreateReservationDto) => {
  try {
    const newReservation = await api.createReservation(reservationData);
    
    // Actualizar estado local
    setReservations((prev) => [...prev, newReservation]);
    
    // Actualizar la sala para reflejar la nueva reserva
    const updatedRooms = await api.getRooms();
    setRooms(updatedRooms);
    
    toast.success(`Reserva confirmada!`);
    setSelectedRoomForReservation(null);
  } catch (error: any) {
    toast.error(error.message || 'Error al crear la reserva');
  }
};
```

---

## 🎯 PASO 3: Actualizar handleCancelReservation

**ANTES (localStorage):**
```typescript
const handleCancelReservation = (reservationId: string, roomId: string) => {
  setReservations((prev) => prev.filter((r) => r.id !== reservationId));
  setRooms((prev) =>
    prev.map((room) => {
      if (room.id === roomId && room.currentReservation) {
        const { currentReservation, ...rest } = room;
        return { ...rest, status: "available" as RoomStatus };
      }
      return room;
    })
  );
  toast.success("Reserva cancelada exitosamente");
  setReservationToCancel(null);
};
```

**DESPUÉS (API):**
```typescript
const handleCancelReservation = async (reservationId: number) => {
  try {
    await api.cancelReservation(reservationId);
    
    // Actualizar estado local
    setReservations((prev) => prev.filter((r) => r.id !== reservationId));
    
    // Recargar salas para actualizar estados
    const updatedRooms = await api.getRooms();
    setRooms(updatedRooms);
    
    toast.success("Reserva cancelada exitosamente");
    setReservationToCancel(null);
  } catch (error: any) {
    toast.error(error.message || 'Error al cancelar la reserva');
  }
};
```

---

## 🎯 PASO 4: Actualizar handleChangeStatus

**ANTES (solo local):**
```typescript
const handleChangeStatus = (roomId: string, newStatus: RoomStatus, ...) => {
  setRooms((prev) =>
    prev.map((room) => {
      if (room.id === roomId) {
        return { ...room, status: newStatus };
      }
      return room;
    })
  );
  toast.success(`Estado actualizado...`);
};
```

**DESPUÉS (con API):**
```typescript
const handleChangeStatus = async (
  roomId: number, 
  newStatus: 'Libre' | 'Ocupado' | 'Mantenimiento'
) => {
  try {
    await api.updateRoomStatus(roomId, newStatus);
    
    // Actualizar estado local
    setRooms((prev) =>
      prev.map((room) => {
        if (room.id === roomId) {
          return { ...room, status: newStatus };
        }
        return room;
      })
    );
    
    const statusText = {
      'Libre': 'Disponible',
      'Ocupado': 'Ocupado',
      'Mantenimiento': 'En Mantenimiento'
    };
    
    toast.success(`Estado actualizado a: ${statusText[newStatus]}`);
  } catch (error: any) {
    toast.error(error.message || 'Error al actualizar el estado');
  }
};
```

---

## 🎯 PASO 5: Actualizar quick-reservation-form.tsx

Este componente necesita enviar datos en el formato que espera la API.

**Cambios en el submit:**

**ANTES:**
```typescript
onSubmit({
  roomId: room.id,
  organizer: currentUser.name,
  organizerEmail: currentUser.email,
  organizerWindowsUsername: currentUser.windowsUsername,
  date: new Date().toISOString().split('T')[0],
  startTime,
  endTime,
  title: purpose,
  services: selectedServices,
});
```

**DESPUÉS:**
```typescript
onSubmit({
  roomId: room.id,
  startTime: `${new Date().toISOString().split('T')[0]}T${startTime}:00`,
  endTime: `${new Date().toISOString().split('T')[0]}T${endTime}:00`,
  purpose,
  // El usuario actual se obtiene automáticamente en el backend
});
```

---

## 🎯 PASO 6: Actualizar Tipos

Modificar `/src/app/types/index.ts` para que coincida con la API:

**AGREGAR:**
```typescript
export interface User {
  id: number;
  windowsUsername: string;
  displayName: string;
  email: string;
  teamId: number;
  team?: Team;
  isActive: boolean;
}

export interface Team {
  id: number;
  name: string;
  color: string;
}

export interface Room {
  id: number;
  name: string;
  floor: number;
  capacity: number;
  status: 'Libre' | 'Ocupado' | 'Mantenimiento';
  currentReservation?: Reservation;
  nextReservation?: Reservation;
}

export interface Reservation {
  id: number;
  roomId: number;
  userId: number;
  user?: User;
  room?: Room;
  startTime: string; // formato ISO
  endTime: string;   // formato ISO
  purpose: string;
  status: 'Active' | 'Completed' | 'Cancelled';
  createdAt: string;
}
```

---

## 🎯 PASO 7: Eliminar archivos innecesarios

Una vez que todo funcione con la API, puedes eliminar:

1. ❌ `/src/app/data/mock-data.ts` - Ya no se necesitan datos de prueba
2. ❌ `/src/app/components/windows-login.tsx` - Windows Auth es automática
3. ❌ Cualquier referencia a `localStorage` para usuarios

---

## 🔄 Flujo de Datos Actualizado

### ANTES (con localStorage):
```
Usuario → Ingresa datos manualmente
       ↓
localStorage guarda usuario
       ↓
mockData muestra salas
       ↓
Reservas se guardan en estado React (se pierden al refrescar)
```

### DESPUÉS (con API):
```
Windows Auth automática → Backend obtiene usuario de Windows
                       ↓
               API devuelve datos del usuario
                       ↓
         Frontend carga salas desde SQL Server
                       ↓
    Reservas se guardan en SQL Server (persistentes)
                       ↓
         Cambios se sincronizan en tiempo real
```

---

## ✅ Checklist de Migración

Antes de considerar la migración completa:

- [ ] Backend .NET corriendo en `http://localhost:5000`
- [ ] SQL Server con base de datos creada
- [ ] Usuario de Windows agregado a tabla `Users`
- [ ] Servicio API creado (`/src/app/services/api.ts`)
- [ ] `App.tsx` actualizado con `loadInitialData()`
- [ ] Funciones de reserva actualizadas para usar API
- [ ] Formulario de reserva actualizado
- [ ] Tipos TypeScript actualizados
- [ ] Componente de login eliminado o comentado
- [ ] Probado crear reserva → Funciona ✅
- [ ] Probado cancelar reserva → Funciona ✅
- [ ] Probado cambiar estado de sala → Funciona ✅

---

## 🐛 Debugging

### Ver las llamadas a la API:

Agrega esto al principio de `api.ts`:

```typescript
const API_BASE_URL = 'http://localhost:5000/api';

// Helper para debug
const logApiCall = (method: string, url: string, data?: any) => {
  console.log(`🔵 API ${method}:`, url, data);
};

const logApiResponse = (url: string, data: any) => {
  console.log(`🟢 API Response:`, url, data);
};

const logApiError = (url: string, error: any) => {
  console.error(`🔴 API Error:`, url, error);
};
```

Luego en cada función:
```typescript
export const api = {
  getCurrentUser: async (): Promise<User> => {
    const url = `${API_BASE_URL}/users/current`;
    logApiCall('GET', url);
    
    const response = await fetch(url, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      logApiError(url, response.statusText);
      throw new Error('No autenticado');
    }
    
    const data = await response.json();
    logApiResponse(url, data);
    return data;
  },
  // ... resto de funciones
};
```

Esto te permitirá ver en la consola del navegador (F12) todas las llamadas y respuestas de la API.

---

## 🎯 Próximo Paso

Una vez completada esta migración, podrás:
1. ✅ Autenticación automática con Windows
2. ✅ Datos persistentes en SQL Server
3. ✅ Múltiples usuarios usando la aplicación al mismo tiempo
4. ✅ Auditoría de quién hizo cada reserva
5. ✅ Horarios y reglas de negocio validados en el backend

¿Listo para empezar? ¡Comienza con el **PASO 1** actualizando `App.tsx`!
