# 🚀 Cómo Iniciar la Aplicación SISU GRB - Sistema de Reservas de Salas

## 📋 Requisitos Previos

✅ SQL Server Express instalado y corriendo
✅ Base de datos `SisuGrbRoomReservations` creada
✅ Tablas creadas (Users, Teams, Rooms, Reservations)
✅ Tu usuario agregado en la tabla Users con tu usuario de Windows
✅ Visual Studio 2022 instalado
✅ Node.js instalado (v18 o superior)

---

## 🎯 PASO 1: Iniciar el Backend (.NET)

### Opción A: Desde Visual Studio (Recomendado)

1. **Abrir Visual Studio 2022**

2. **Abrir el proyecto backend:**
   - File → Open → Project/Solution
   - Navegar a: `C:\SISU-GRB\Backend\SisuGrb.RoomReservations\SisuGrb.RoomReservations.csproj`
   - Click en "Open"

3. **Iniciar el servidor:**
   - Presionar **F5** (o click en el botón verde "Play")
   - Esperar a que se abra Swagger en el navegador: `http://localhost:5000/swagger`

4. **Verificar que funciona:**
   - En Swagger, buscar **GET /api/users/current**
   - Click en "Try it out" → "Execute"
   - Deberías ver tus datos de usuario

✅ **El backend está corriendo - DEJAR ESTA VENTANA ABIERTA**

---

## 🎨 PASO 2: Iniciar el Frontend (React)

### 2.1 - Abrir Command Prompt (CMD)

1. Presionar la tecla **Windows**
2. Escribir: `cmd`
3. Presionar **Enter**

### 2.2 - Navegar a la carpeta del proyecto

En CMD, copiar y pegar este comando (ajustar la ruta según donde esté TU proyecto):

```cmd
cd "C:\Users\RaymundoColoapaFrago\OneDrive - SISU GLOBAL REINSURANCE BROKER\Escritorio\Proyecto SISUGRB_Figma"
```

Presionar **Enter**

### 2.3 - Iniciar el servidor de desarrollo

```cmd
npm run dev
```

Presionar **Enter**

Deberías ver algo como:

```
  VITE v6.x.x  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

✅ **El frontend está corriendo - DEJAR ESTA VENTANA ABIERTA**

---

## 🌐 PASO 3: Abrir la Aplicación en el Navegador

1. Abrir tu navegador (Chrome, Edge, etc.)
2. Ir a: **`http://localhost:5173`**

✅ **¡Deberías ver la aplicación de reservas de salas SISU GRB!** 🎉

---

## 🏢 Características de la Aplicación

### ✅ Salas Disponibles

- **Piso 1** - Capacidad: 10 personas
- **Piso 2** - Capacidad: 10 personas  
- **Piso 3 - Capacitación** - Capacidad: 30 personas

### ✅ Funcionalidades

- ✅ Reservar salas con fecha y hora
- ✅ Ver disponibilidad en tiempo real
- ✅ Cancelar solo tus propias reservas
- ✅ Ver el equipo de cada usuario
- ✅ Horario: 8:30 AM - 6:00 PM (Lunes a Viernes)
- ✅ Estados: Libre, Ocupado, Mantenimiento
- ✅ Autenticación automática con Windows (azuread)

---

## 🔧 Solución de Problemas

### Problema: "npm no se reconoce como comando"

**Solución:** Instalar Node.js desde https://nodejs.org/ (versión LTS)

---

### Problema: "Error de autenticación" en el frontend

**Verificar:**

1. ✅ El backend está corriendo (Visual Studio presionado F5)
2. ✅ Swagger funciona en `http://localhost:5000/swagger`
3. ✅ El endpoint GET /api/users/current devuelve tus datos
4. ✅ Tu usuario está en la base de datos con el formato: `azuread\raymundocoloapafrago`

---

### Problema: "No se pudo conectar al servidor"

**Solución:**

1. Verificar que Visual Studio esté abierto con el backend corriendo
2. Ir a `http://localhost:5000/swagger` - debe funcionar
3. Si no funciona, revisar que SQL Server Express esté corriendo

---

### Problema: Usuario no encontrado

**Solución:**

Ejecutar en SQL Server Management Studio:

```sql
-- Ver tu usuario exacto
SELECT * FROM Users WHERE WindowsUsername LIKE '%tu_nombre%';

-- Si no existe, agregarlo (ajustar según tu info):
INSERT INTO Users (WindowsUsername, FullName, Email, TeamId, IsActive)
VALUES (
    'azuread\raymundocoloapafrago',  -- Tu usuario EXACTO de Windows
    'Raymundo Coloapa',
    'raymundo_coloapa@ermv.com.mx',
    8,  -- Tu TeamId
    1
);
```

---

## 📊 Resumen Visual

```
┌─────────────────────────────────────┐
│  VISUAL STUDIO                      │
│  Backend .NET corriendo             │
│  Puerto: http://localhost:5000      │
│  Presionar F5 ✅                    │
└─────────────────────────────────────┘
                ↓
┌─────────────────────────────────────┐
│  CMD (Command Prompt)               │
│  Frontend React corriendo           │
│  Comando: npm run dev               │
│  Puerto: http://localhost:5173 ✅   │
└─────────────────────────────────────┘
                ↓
┌─────────────────────────────────────┐
│  NAVEGADOR                          │
│  http://localhost:5173              │
│  Aplicación funcionando ✅          │
└─────────────────────────────────────┘
```

---

## 🎯 Checklist Final

**Antes de usar la aplicación, verifica:**

- [ ] SQL Server Express está corriendo
- [ ] Base de datos `SisuGrbRoomReservations` existe
- [ ] Tablas creadas (Users, Teams, Rooms, Reservations)
- [ ] Mi usuario está en la tabla Users con formato `azuread\miusuario`
- [ ] Visual Studio abierto con backend corriendo (F5)
- [ ] Swagger funciona en http://localhost:5000/swagger
- [ ] CMD abierto con `npm run dev` ejecutado
- [ ] Navegador abierto en http://localhost:5173
- [ ] Veo mi nombre en la esquina superior derecha de la app

---

## 📞 Soporte

Si tienes problemas:

1. Verificar que ambas ventanas (Visual Studio y CMD) estén abiertas
2. Revisar la consola del navegador (F12) para ver errores
3. Verificar que tu usuario esté en la base de datos con el formato correcto

---

¡Listo para usar! 🎉

**SISU Global Reinsurance Broker**  
Sistema de Reservas de Salas v1.0
