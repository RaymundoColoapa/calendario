# ❓ PREGUNTAS FRECUENTES - SISU GRB

## 🎯 ACCESO Y USO

### **P1: ¿Cómo acceden mis 50 usuarios a la aplicación?**
**R:** 
1. Les compartes la URL (ej: `https://sisu-grb.vercel.app`)
2. Cada persona abre la URL en su navegador (celular o laptop)
3. Seleccionan su nombre de la lista
4. ¡Listo! Ya pueden reservar

**NO necesitan instalar nada, NO necesitan crear cuenta.**

---

### **P2: ¿Funciona SIN INTERNET?**
**R:** NO. Necesita conexión a internet porque:
- Los datos están en la nube (Supabase)
- Sincroniza entre todos los dispositivos
- Si pierdes internet, verás el icono WiFi rojo
- Al reconectar, todo se actualiza automáticamente

---

### **P3: ¿Puedo usar en celular Y laptop al mismo tiempo?**
**R:** ¡SÍ! Ejemplo:
- Reservas en tu laptop en la oficina
- Sales a comer
- Abres en tu celular → ves TU reserva
- Puedes cancelarla desde el celular
- Todo sincronizado

---

### **P4: ¿Cuántas personas pueden estar usando al MISMO TIEMPO?**
**R:** **50+ personas sin problema**. Pueden:
- 25 personas viendo reservas
- 10 personas creando reservas
- 5 personas cancelando
- Todo al mismo tiempo, sin conflictos

---

## 💾 DATOS Y SINCRONIZACIÓN

### **P5: ¿Dónde se guardan las reservas?**
**R:** En la nube (Supabase PostgreSQL)
- NO en tu celular
- NO en tu navegador
- En un servidor en la nube 24/7
- Con backups automáticos diarios

---

### **P6: Si borro el app del celular, ¿pierdo mis reservas?**
**R:** **NO**. Las reservas están en la nube. Si:
- Cambias de celular
- Borras el navegador
- Formateas la computadora
- Tus reservas siguen ahí

---

### **P7: ¿Qué tan rápido se sincroniza?**
**R:** 
- Pedro reserva en laptop → Ana lo ve en celular en **2-5 segundos**
- No necesitan recargar la página
- Es automático

---

### **P8: ¿Qué pasa si dos personas reservan la MISMA sala al MISMO TIEMPO?**
**R:** El servidor detecta el conflicto:
- La primera persona que envía la reserva → ✅ Se guarda
- La segunda persona → ❌ Mensaje: "Ya existe una reserva en ese horario"
- Debe seleccionar otro horario

---

## 🔒 SEGURIDAD Y PERMISOS

### **P9: ¿Puedo cancelar la reserva de otra persona?**
**R:** **NO**. Solo puedes cancelar TUS propias reservas.
- El sistema verifica que seas el dueño
- Si intentas cancelar otra reserva → Error

---

### **P10: ¿Quién puede poner salas en mantenimiento?**
**R:** **Solo José Luis Pimienta** (Supervisor de Mantenimiento)
- Los demás usuarios NO ven el panel de mantenimiento
- Solo José Luis tiene ese permiso

---

### **P11: ¿Es segura la aplicación?**
**R:** SÍ:
- ✅ Conexión HTTPS encriptada
- ✅ Base de datos segura (Supabase)
- ✅ Permisos por usuario
- ✅ Backups automáticos
- ✅ Certificada y auditada (SOC 2)

---

### **P12: ¿Pueden hackear la base de datos?**
**R:** Muy difícil. Supabase tiene:
- Encriptación de datos
- Firewall
- Monitoreo 24/7
- Certificación SOC 2 Type II
- Usado por miles de empresas

---

## 👥 USUARIOS

### **P13: ¿Cómo agrego más usuarios?**
**R:** Editas el código del servidor:
1. Abres `/supabase/functions/server/index.tsx`
2. Agregas el nuevo usuario en `INITIAL_USERS`:
```typescript
{
  id: 5,
  username: 'azuread\\nuevouser',
  displayName: 'Nuevo Usuario',
  email: 'nuevo@sisugrb.com',
  teamId: 1,
  team: { id: 1, name: 'Tecnología', color: '#3B82F6' },
  role: 'Rol del Usuario'
}
```
3. Guardas y subes a Vercel
4. El nuevo usuario aparece en login

---

### **P14: ¿Puedo tener 100 usuarios en lugar de 50?**
**R:** ¡SÍ! El plan gratuito soporta hasta 100 usuarios sin problema.
- Sigue siendo GRATIS
- Misma funcionalidad
- Misma velocidad

---

### **P15: ¿Los usuarios necesitan contraseña?**
**R:** NO (actualmente). Es login simple:
- Seleccionas tu nombre
- Entras directamente

**Si quieres agregar contraseñas:**
- Se puede implementar con Supabase Auth
- Cada usuario tendría email + contraseña
- Más seguro pero más complejo

---

## 🏢 SALAS

### **P16: ¿Cómo agrego más salas?**
**R:** Similar a usuarios:
1. Abres `/supabase/functions/server/index.tsx`
2. Agregas la nueva sala en `INITIAL_ROOMS`:
```typescript
{
  id: 4,
  name: 'Sala Piso 4',
  capacity: 15,
  floor: 4,
  status: 'Libre'
}
```
3. Guardas y subes a Vercel

---

### **P17: ¿Puedo cambiar el horario de 8:30 AM - 6:00 PM?**
**R:** SÍ, pero es solo visual actualmente.
- Editas el texto en el frontend
- Si quieres validación estricta, se puede agregar al backend

---

### **P18: ¿Puedo tener salas en diferentes ubicaciones? (Ejemplo: Oficina CDMX y Oficina Guadalajara)**
**R:** ¡SÍ! Puedes:
- Nombrar las salas: "CDMX - Piso 1", "GDL - Piso 1"
- Agregar filtros por ubicación
- La base de datos soporta múltiples ubicaciones

---

## 💰 COSTOS

### **P19: ¿Cuándo tendré que pagar?**
**R:** Cuando superes el plan gratuito:
- Más de 500 MB de datos (~100,000+ reservas)
- Más de 500 usuarios activos/mes
- Más de 5 GB de ancho de banda/mes

Para 50 usuarios haciendo ~2,000 reservas/mes = **GRATIS SIEMPRE**

---

### **P20: Si en el futuro tengo 200 usuarios, ¿cuánto cuesta?**
**R:** $25 USD/mes (plan Pro de Supabase)
- Incluye:
  - 8 GB base de datos
  - 100 GB ancho de banda
  - 2 millones de peticiones/mes
  - Soporte prioritario

---

### **P21: ¿Vercel cobra algo?**
**R:** NO para tu caso:
- Plan gratuito incluye:
  - 100 GB ancho de banda/mes
  - Dominio .vercel.app gratis
  - HTTPS gratis
  - Deploy ilimitados

---

## 🚀 DEPLOY Y HOSTING

### **P22: ¿Qué es Vercel?**
**R:** Es una plataforma para alojar aplicaciones web:
- Gratis para proyectos pequeños
- Deploy en 5 minutos
- Te da una URL permanente
- Actualización automática

---

### **P23: ¿Puedo usar mi propio dominio? (Ejemplo: reservas.sisugrb.com)**
**R:** ¡SÍ! Con Vercel:
1. Compras el dominio (GoDaddy, Namecheap)
2. En Vercel → Settings → Domains
3. Agregas tu dominio
4. Configuras DNS
5. ¡Listo! Tu app en `reservas.sisugrb.com`

**Costo del dominio:** ~$10-15 USD/año

---

### **P24: ¿La aplicación está 24/7?**
**R:** SÍ:
- Supabase: 99.9% uptime (casi siempre activo)
- Vercel: 99.99% uptime
- Si hay un problema, se recupera automáticamente

---

### **P25: ¿Qué pasa si Vercel o Supabase se caen?**
**R:** 
- **Supabase cae (muy raro):**
  - Verás mensaje "Sin conexión"
  - Cuando regrese, se sincroniza automáticamente
  - Los datos NO se pierden

- **Vercel cae (muy raro):**
  - La app no carga
  - Cuando regrese, todo funciona normal

**Ambos tienen 99.9%+ uptime = muy confiables**

---

## 📱 CELULAR Y APP

### **P26: ¿Es una app nativa o web?**
**R:** Es una **Progressive Web App (PWA)**:
- Abres en el navegador
- Puedes agregarla a pantalla de inicio
- Parece una app nativa
- Pero NO está en App Store o Google Play

---

### **P27: ¿Por qué no está en App Store / Google Play?**
**R:** Porque no lo necesitas:
- Las PWA funcionan igual de bien
- No requieren aprobación de Apple/Google
- No requieren actualización manual
- Gratis (publicar en tiendas cuesta $99-$300/año)

**Si en el futuro quieres app nativa, se puede hacer**

---

### **P28: ¿Funciona en iPhone antiguo?**
**R:** SÍ, si tiene:
- iOS 13 o superior
- Safari o Chrome actualizado

**Para Android:**
- Android 7.0 o superior
- Chrome actualizado

---

## 🔧 MANTENIMIENTO

### **P29: ¿Quién mantiene la aplicación?**
**R:** 
- **Supabase:** Se mantiene solo (backups, seguridad, etc.)
- **Vercel:** Se mantiene solo
- **Tú:** Solo si quieres agregar nuevas funcionalidades

**No requiere mantenimiento diario**

---

### **P30: ¿Cómo actualizo la aplicación?**
**R:** 
1. Haces cambios en el código
2. Subes a Vercel (git push o arrastra)
3. Vercel actualiza automáticamente
4. Todos los usuarios ven la nueva versión (sin hacer nada)

---

### **P31: ¿Los backups son automáticos?**
**R:** SÍ:
- Supabase hace backup diario automático
- Retiene backups por 7 días (plan gratis)
- Plan pago: retiene 30 días

---

### **P32: ¿Puedo descargar mis datos?**
**R:** SÍ:
1. Entras al panel de Supabase
2. Table Editor → Select all
3. Export → CSV
4. Tienes todas tus reservas en Excel

---

## 🎨 PERSONALIZACIÓN

### **P33: ¿Puedo cambiar los colores?**
**R:** SÍ:
1. Editas `/src/styles/theme.css`
2. Cambias los colores
3. Subes a Vercel
4. Todos ven el nuevo diseño

---

### **P34: ¿Puedo cambiar el logo?**
**R:** SÍ:
1. Reemplazas la imagen del logo
2. Actualizas la referencia en el código
3. Subes a Vercel

---

### **P35: ¿Puedo agregar mi idioma? (Inglés, etc.)**
**R:** SÍ, pero requiere trabajo:
- Agregar traducciones en el código
- Botón para cambiar idioma
- Se puede hacer con i18n

---

## 📊 REPORTES Y ANALYTICS

### **P36: ¿Puedo ver estadísticas? (Sala más usada, etc.)**
**R:** Actualmente NO, pero se puede agregar:
- Gráficas de uso
- Sala más popular
- Usuario con más reservas
- Horarios pico

**Todo es posible con la base de datos**

---

### **P37: ¿Puedo exportar un reporte de reservas?**
**R:** SÍ:
1. Panel de Supabase → Table Editor
2. Filtras por fecha
3. Export → CSV
4. Abres en Excel

---

## 🐛 TROUBLESHOOTING

### **P38: La app no carga**
**R:** Verifica:
1. ¿Tienes internet? (WiFi o datos)
2. ¿La URL es correcta?
3. ¿Vercel está activo? (status.vercel.com)
4. ¿Supabase está activo? (status.supabase.com)

---

### **P39: No veo las reservas actualizadas**
**R:** 
1. Espera 5 segundos (sincronización)
2. Recarga la página (F5)
3. Verifica conexión (icono WiFi verde)

---

### **P40: Me sale "Error al crear reserva"**
**R:** Posibles causas:
- Ya hay una reserva en ese horario
- Datos incompletos (falta hora o motivo)
- Sin conexión a internet
- Sala en mantenimiento

**Verifica el mensaje de error específico**

---

## 🎓 ENTRENAMIENTO

### **P41: ¿Necesito entrenar a mi equipo?**
**R:** Muy poco:
1. Explica cómo acceder (URL)
2. Cómo seleccionar su nombre
3. Cómo reservar (muy intuitivo)
4. Cómo cancelar

**Total: 5 minutos por persona**

---

### **P42: ¿Hay manual de usuario?**
**R:** Este archivo y los otros documentos:
- `RESUMEN-COMPLETO-SUPABASE.md`
- `INSTRUCCIONES-DEPLOYMENT.md`
- `PREGUNTAS-FRECUENTES.md` (este)

---

## 🚀 FUTURO

### **P43: ¿Qué más se puede agregar en el futuro?**
**R:** Ideas:
- 📧 Notificaciones por email
- 📱 Notificaciones push (celular)
- 🔄 Reservas recurrentes
- 📸 Subir fotos de salas
- 📊 Dashboard con gráficas
- 🌐 Multi-idioma
- 👥 Gestión de equipos
- 📅 Integración con Outlook/Google Calendar
- ⏰ Recordatorios automáticos

**TODO es posible**

---

### **P44: ¿Cuánto cuesta agregar nuevas funcionalidades?**
**R:** Depende de la complejidad:
- Notificaciones email: Puede requerir servicio externo (~$5-10 USD/mes)
- Notificaciones push: Servicio como OneSignal (~$0-10 USD/mes)
- Reportes: Incluido en Supabase
- Multi-idioma: Solo código, gratis

---

### **P45: ¿Puedo integrar con Microsoft Teams o Slack?**
**R:** ¡SÍ! Se puede:
- Enviar notificación a Teams cuando alguien reserva
- Comando en Slack para ver disponibilidad
- Requiere configuración de webhooks

---

## 📞 SOPORTE

### **P46: ¿Dónde obtengo soporte técnico?**
**R:** 
- **Supabase:** support.supabase.com (en inglés)
- **Vercel:** vercel.com/support (en inglés)
- **Tu código:** Revisar documentación aquí

---

### **P47: ¿Supabase tiene soporte en español?**
**R:** NO oficial, pero:
- Documentación clara en inglés
- Google Translate funciona bien
- Comunidad en Discord (español también)

---

### **P48: ¿Qué hago si tengo un error crítico?**
**R:** 
1. Revisa logs en Supabase
2. Revisa logs en Vercel
3. Revisa consola del navegador (F12)
4. Busca el mensaje de error en Google

---

## 🎯 RESUMEN

### **P49: ¿Vale la pena Supabase + Vercel vs SQL Server local?**
**R:** ¡SÍ! Porque:

| Supabase + Vercel | SQL Server Local |
|-------------------|------------------|
| ✅ Acceso desde cualquier lugar | ❌ Solo en oficina |
| ✅ Celular y laptop | ❌ Solo laptop |
| ✅ Gratis | ❌ Licencias caras |
| ✅ Backups automáticos | ⚠️ Tú haces backups |
| ✅ Sin mantenimiento | ❌ Requiere IT |
| ✅ Escalable | ⚠️ Limitado |

---

### **P50: ¿Es esta la ÚNICA forma de hacerlo?**
**R:** NO, pero es la MEJOR para ti porque:
- ✅ Funciona en celular + laptop
- ✅ Gratis para 50 usuarios
- ✅ No requiere .NET ni SQL Server
- ✅ React puro (lo que pediste)
- ✅ Deploy en 10 minutos
- ✅ Sincronización automática

**Alternativas:**
- Firebase (similar, de Google)
- AWS Amplify (más complejo, más caro)
- MongoDB Atlas (NoSQL, diferente)

**Pero Supabase es el más fácil y adecuado** 🏆

---

# 🎉 ¿MÁS PREGUNTAS?

Si tienes más dudas, revisa:
- `RESUMEN-COMPLETO-SUPABASE.md` - Información completa
- `INSTRUCCIONES-DEPLOYMENT.md` - Cómo deployar
- Documentación de Supabase: https://supabase.com/docs
- Documentación de Vercel: https://vercel.com/docs

---

¡Disfruta tu aplicación! 🚀
