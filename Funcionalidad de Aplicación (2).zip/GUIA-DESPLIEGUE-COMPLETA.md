# 🚀 Guía Completa de Despliegue - Sistema SISU GRB

## 📋 Índice
1. [Pre-requisitos](#pre-requisitos)
2. [Despliegue del Backend (Supabase)](#despliegue-del-backend)
3. [Despliegue del Frontend](#despliegue-del-frontend)
4. [Verificación Post-Despliegue](#verificación)
5. [Configuración para Producción](#producción)
6. [Troubleshooting](#troubleshooting)

---

## 🎯 Pre-requisitos {#pre-requisitos}

### Lo que necesitas antes de empezar:

✅ **Cuenta de Supabase** activa (gratis)
- Proyecto ID: `daowqmfdusubyicuuowy`
- URL: `https://daowqmfdusubyicuuowy.supabase.co`

✅ **Node.js** instalado (v18 o superior)
```bash
# Verificar instalación
node --version
npm --version
```

✅ **Git** instalado (para desplegar el frontend)
```bash
git --version
```

✅ **Supabase CLI** instalado
```bash
# Opción 1: Con npm (recomendado)
npm install -g supabase

# Opción 2: Con Scoop (Windows)
scoop install supabase

# Verificar instalación
supabase --version
```

---

## 🔧 Despliegue del Backend (Supabase Edge Functions) {#despliegue-del-backend}

### Paso 1: Iniciar sesión en Supabase CLI

```bash
supabase login
```

Esto abrirá tu navegador para autenticarte. **Autoriza la aplicación**.

### Paso 2: Vincular tu proyecto

```bash
# Ejecutar desde la carpeta raíz de tu proyecto
supabase link --project-ref daowqmfdusubyicuuowy
```

**Si te pide password:** Es tu contraseña de la base de datos de Supabase. La puedes encontrar en:
- Dashboard de Supabase → Settings → Database → Database Password

### Paso 3: Configurar variables de entorno (Secrets)

El backend necesita estas variables. Configúralas ejecutando:

```bash
# URL de tu proyecto Supabase
supabase secrets set SUPABASE_URL="https://daowqmfdusubyicuuowy.supabase.co"

# Anon Key (pública) - Obtener de: Dashboard → Settings → API → anon/public
supabase secrets set SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRhb3dxbWZkdXN1YnlpY3V1b3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg3MTM5OTMsImV4cCI6MjA1NDI4OTk5M30.oGsN88CQKfGTKWPzCemCRWgvuPSukNRZe_K31YSy7_c"

# Service Role Key (secreta) - Obtener de: Dashboard → Settings → API → service_role
supabase secrets set SUPABASE_SERVICE_ROLE_KEY="TU_SERVICE_ROLE_KEY_AQUI"

# Database URL - Obtener de: Dashboard → Settings → Database → Connection String → URI
supabase secrets set SUPABASE_DB_URL="TU_DATABASE_URL_AQUI"
```

**⚠️ IMPORTANTE:** 
- La `SERVICE_ROLE_KEY` es secreta, nunca la expongas en el frontend
- La `DATABASE_URL` tiene formato: `postgresql://postgres:[PASSWORD]@[HOST]:6543/postgres`

### Paso 4: Desplegar la Edge Function

```bash
# Desplegar el servidor completo
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

**Explicación de opciones:**
- `make-server-f5c6167b` es el nombre de la función
- `--no-verify-jwt` permite usar el `publicAnonKey` sin verificación JWT adicional

**Tiempo estimado:** 1-2 minutos

### Paso 5: Verificar el despliegue del backend

Abre en tu navegador:
```
https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/health
```

**Respuesta esperada:**
```json
{
  "status": "ok",
  "message": "SISU GRB API funcionando"
}
```

✅ **Si ves esto, tu backend está funcionando correctamente!**

---

## 🌐 Despliegue del Frontend {#despliegue-del-frontend}

Tienes 3 opciones para desplegar el frontend:

### Opción 1: Vercel (Recomendado - Más fácil)

1. **Ir a [vercel.com](https://vercel.com)** y crear una cuenta (gratis)

2. **Conectar tu repositorio Git:**
   - Click en "New Project"
   - Importa tu repositorio (GitHub, GitLab, Bitbucket)
   - Vercel detectará automáticamente que es un proyecto Vite

3. **Configurar el proyecto:**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

4. **Deploy!**
   - Click en "Deploy"
   - Espera 2-3 minutos
   - ¡Tu aplicación estará en vivo!

**URL de ejemplo:** `https://tu-proyecto.vercel.app`

### Opción 2: Netlify

1. **Ir a [netlify.com](https://netlify.com)** y crear una cuenta

2. **Drag & Drop o conectar Git:**
   - Opción A: Arrastra la carpeta `dist` después de ejecutar `npm run build`
   - Opción B: Conecta tu repositorio Git

3. **Configuración:**
   - Build command: `npm run build`
   - Publish directory: `dist`

4. **Deploy**

**URL de ejemplo:** `https://tu-proyecto.netlify.app`

### Opción 3: GitHub Pages

1. **Preparar el proyecto:**

Edita `vite.config.ts` y agrega:
```typescript
export default defineConfig({
  base: '/nombre-repositorio/',
  // ... resto de configuración
})
```

2. **Instalar gh-pages:**
```bash
npm install --save-dev gh-pages
```

3. **Agregar scripts en `package.json`:**
```json
{
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

4. **Desplegar:**
```bash
npm run deploy
```

**URL de ejemplo:** `https://tu-usuario.github.io/nombre-repositorio/`

### Opción 4: Build manual para servidor propio

Si tienes un servidor web (IIS, Apache, Nginx):

1. **Construir el proyecto:**
```bash
npm run build
```

2. **Copiar la carpeta `dist`** a tu servidor web

3. **Configurar el servidor** para servir archivos estáticos y redirigir todo a `index.html`

---

## ✅ Verificación Post-Despliegue {#verificación}

### 1. Verificar conexión Backend-Frontend

Una vez desplegado, abre tu aplicación y verifica:

#### En la esquina superior derecha:
- 🟢 **Ícono WiFi verde** = Conectado a Supabase ✅
- 🔴 **Ícono WiFi rojo** = Sin conexión ❌

#### Consola del navegador (F12):
```javascript
// No deberías ver estos errores:
❌ Failed to fetch
❌ CORS error
❌ Network error

// Deberías ver:
✅ "Conectado a API"
✅ "Usuario cargado"
```

### 2. Probar funcionalidad principal

#### Test 1: Auto-login
1. Abre la aplicación
2. Si estás en Windows con Azure AD, debería auto-loguearte
3. Si no, ingresa nombre y email manualmente
4. Verifica que aparezca tu nombre arriba a la derecha

#### Test 2: Ver salas
1. Las 3 salas deberían aparecer:
   - ✅ Sala Piso 1 (10 personas)
   - ✅ Sala Piso 2 (10 personas)
   - ✅ Sala Piso 3 - Capacitación (30 personas)

2. Todas deberían mostrar estado "Libre"

#### Test 3: Crear reserva
1. Click en cualquier sala
2. Selecciona fecha y horario
3. Ingresa el propósito
4. Click en "Reservar"
5. **Debe crearse sin errores**

#### Test 4: Ver tus reservas
1. Click en "Mis Reservas" (ícono de calendario arriba)
2. Deberías ver la reserva que acabas de crear

#### Test 5: Cancelar reserva
1. En "Mis Reservas", click en "Cancelar"
2. Confirma la cancelación
3. La reserva debe desaparecer

### 3. Probar desde móvil

1. Abre la URL en tu celular
2. Verifica que el diseño sea responsive
3. Prueba crear y cancelar reservas

---

## 🔒 Configuración para Producción {#producción}

### Seguridad

#### 1. Cambiar clave de admin

En `/supabase/functions/server/index.tsx`, línea 537:
```typescript
// ❌ Cambiar esto antes de producción:
if (adminKey !== 'sisugrb-admin-2026') {

// ✅ Por algo más seguro:
if (adminKey !== 'TU_CLAVE_SUPER_SEGURA_AQUI') {
```

#### 2. Habilitar Row Level Security (RLS) en Supabase

1. Ve al Dashboard de Supabase
2. SQL Editor
3. Ejecuta:

```sql
-- Habilitar RLS en la tabla kv_store
ALTER TABLE kv_store_f5c6167b ENABLE ROW LEVEL SECURITY;

-- Política: Solo el propietario puede ver sus datos
CREATE POLICY "Users can view their own data"
  ON kv_store_f5c6167b
  FOR SELECT
  USING (true);

-- Política: Solo el propietario puede modificar sus datos
CREATE POLICY "Users can update their own data"
  ON kv_store_f5c6167b
  FOR UPDATE
  USING (true);
```

#### 3. Configurar CORS (si es necesario)

Si solo quieres permitir tu dominio:

En `/supabase/functions/server/index.tsx`:
```typescript
// Cambiar:
app.use('*', cors({ origin: '*', credentials: true }));

// Por:
app.use('*', cors({ 
  origin: 'https://tu-dominio.com', 
  credentials: true 
}));
```

### Performance

#### 1. Habilitar caché

En `/src/app/services/api.ts`, considera agregar caché para salas y usuarios:
```typescript
// Implementar caché simple con tiempo de expiración
const cache = new Map();
const CACHE_TTL = 60000; // 1 minuto
```

#### 2. Comprimir assets

En `vite.config.ts`:
```typescript
export default defineConfig({
  build: {
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true, // Remover console.logs en producción
      }
    }
  }
})
```

### Monitoreo

#### Ver logs del servidor en tiempo real:

```bash
supabase functions logs make-server-f5c6167b --follow
```

O desde el Dashboard:
- Edge Functions → `make-server-f5c6167b` → Logs

#### Métricas importantes a monitorear:

- **Latencia de respuesta** (debe ser < 500ms)
- **Tasa de errores** (debe ser < 1%)
- **Uso de memoria** (Supabase te alerta si hay problemas)
- **Conexiones simultáneas** (tu plan gratuito soporta hasta 100)

---

## 🐛 Troubleshooting {#troubleshooting}

### Error: "Failed to fetch"

**Síntoma:** El frontend no puede conectarse al backend

**Causas posibles:**
1. ❌ El backend no está desplegado
2. ❌ La URL en `/utils/supabase/info.tsx` es incorrecta
3. ❌ Problema de CORS

**Solución:**
```bash
# 1. Verificar que el backend funcione:
curl https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/health

# 2. Re-desplegar el backend:
supabase functions deploy make-server-f5c6167b --no-verify-jwt

# 3. Verificar los logs:
supabase functions logs make-server-f5c6167b
```

---

### Error: "CORS policy blocked"

**Síntoma:** Error de CORS en la consola del navegador

**Solución:**
1. Verifica que el servidor tenga los headers CORS correctos
2. En `/supabase/functions/server/index.tsx`, línea 9 debe tener:
```typescript
app.use('*', cors({ origin: '*', credentials: true }));
```

3. Re-despliega:
```bash
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

---

### Error: "No autorizado" o 403

**Síntoma:** Error de autorización al hacer peticiones

**Causas:**
1. ❌ `publicAnonKey` incorrecta
2. ❌ Usuario no tiene permisos

**Solución:**
1. Verifica `/utils/supabase/info.tsx`:
```typescript
export const publicAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

2. Compara con: Dashboard → Settings → API → `anon public` key

3. Si es diferente, actualiza y re-despliega el frontend

---

### Error: "Conflicto de horario detectado" (falso positivo)

**Síntoma:** No puedes crear reservas aunque no haya conflicto real

**Solución:**
```bash
# Limpiar todas las reservas usando la consola del navegador (F12):
const response = await fetch('https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/api/reservations/admin/clear-all', {
  method: 'DELETE',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ adminKey: 'sisugrb-admin-2026' })
});
console.log(await response.json());
```

O usa el botón "Limpiar Reservas" en el panel de admin (arriba a la derecha, ícono de herramienta).

---

### El frontend no muestra las salas

**Síntoma:** Pantalla en blanco o sin salas

**Solución:**
1. Abre la consola (F12)
2. Busca errores
3. Verifica que el backend esté respondiendo:
```javascript
// En la consola del navegador:
fetch('https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b/api/rooms')
  .then(r => r.json())
  .then(console.log);
```

Deberías ver:
```json
[
  { "id": 1, "name": "Sala Piso 1", "capacity": 10, ... },
  { "id": 2, "name": "Sala Piso 2", "capacity": 10, ... },
  { "id": 3, "name": "Sala Piso 3 - Capacitación", "capacity": 30, ... }
]
```

---

### Lentitud o timeouts

**Síntoma:** La aplicación tarda mucho en responder

**Posibles causas:**
1. Cold start de Edge Functions (primera petición tarda más)
2. Demasiadas reservas en la base de datos
3. Conexión lenta

**Soluciones:**
1. **Warming:** Hacer una petición periódica cada 5 minutos
2. **Limpiar datos viejos:** Ejecutar el script de limpieza mensualmente
3. **Optimizar queries:** Agregar índices en Supabase

---

### Error al desplegar desde CLI

**Síntoma:** `supabase functions deploy` falla

**Solución:**
```bash
# 1. Verificar que estás logueado:
supabase projects list

# 2. Si no aparece tu proyecto, volver a vincular:
supabase link --project-ref daowqmfdusubyicuuowy

# 3. Verificar que los archivos existan:
ls -la supabase/functions/server/

# 4. Intentar con más detalles:
supabase functions deploy make-server-f5c6167b --no-verify-jwt --debug
```

---

## 📊 Endpoints del API

Una vez desplegado, estos endpoints estarán disponibles:

### Base URL
```
https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b
```

### Salas
- `GET /api/rooms` - Listar todas las salas
- `GET /api/rooms/:id` - Obtener sala por ID
- `PUT /api/rooms/:id/status` - Cambiar estado de sala

### Usuarios
- `GET /api/users` - Listar usuarios
- `POST /api/users/auto-login` - Auto-login con Windows/Azure AD
- `PUT /api/users/:id/team` - Cambiar equipo de usuario
- `GET /api/teams` - Listar equipos/departamentos

### Reservas
- `GET /api/reservations` - Listar reservas (opcional: `?date=YYYY-MM-DD`)
- `GET /api/reservations/user/:userId` - Reservas de un usuario
- `POST /api/reservations` - Crear reserva
- `DELETE /api/reservations/:id` - Cancelar reserva
- `GET /api/debug/reservations` - Ver todas las reservas (debug)
- `DELETE /api/reservations/admin/clear-all` - Limpiar todas (requiere clave admin)

### Mantenimiento
- `GET /api/maintenance` - Salas en mantenimiento
- `POST /api/maintenance/toggle` - Activar/desactivar mantenimiento

### Salud
- `GET /health` - Health check del servidor

---

## 🎯 Checklist Final de Despliegue

Marca cada ítem cuando lo completes:

### Backend
- [ ] Supabase CLI instalado
- [ ] Sesión iniciada (`supabase login`)
- [ ] Proyecto vinculado
- [ ] Secrets configurados (4 variables)
- [ ] Edge Function desplegada
- [ ] Health check responde OK
- [ ] Logs del servidor sin errores

### Frontend
- [ ] Proyecto construido (`npm run build`)
- [ ] Desplegado en plataforma (Vercel/Netlify/otro)
- [ ] URL accesible desde navegador
- [ ] Funciona en escritorio
- [ ] Funciona en móvil
- [ ] Indicador de conexión verde

### Funcionalidad
- [ ] Auto-login funciona
- [ ] Se muestran las 3 salas
- [ ] Puedes crear reservas
- [ ] Puedes ver tus reservas
- [ ] Puedes cancelar tus reservas
- [ ] Panel de mantenimiento funciona (usuarios autorizados)

### Seguridad (Producción)
- [ ] Clave de admin cambiada
- [ ] RLS habilitado en Supabase
- [ ] CORS configurado apropiadamente
- [ ] Service Role Key no expuesta en frontend
- [ ] Console.logs removidos en producción

### Performance
- [ ] Respuesta < 500ms en promedio
- [ ] Sin errores en logs
- [ ] Funciona con 50 usuarios simultáneos
- [ ] Caché configurado (opcional)

---

## 🎉 ¡Listo para Producción!

Si completaste todos los pasos, tu aplicación está lista para ser usada por el equipo de SISU GRB.

### URLs Importantes

**Frontend:** `TU_URL_DE_VERCEL_O_NETLIFY`
**Backend:** `https://daowqmfdusubyicuuowy.supabase.co/functions/v1/make-server-f5c6167b`
**Dashboard Supabase:** `https://supabase.com/dashboard/project/daowqmfdusubyicuuowy`

### Próximos Pasos

1. **Compartir la URL** con el equipo
2. **Configurar auto-login** con Azure AD en producción
3. **Monitorear logs** la primera semana
4. **Recopilar feedback** de usuarios
5. **Iterar y mejorar** según necesidades

---

## 📞 Soporte y Documentación

- **Documentación del sistema:** Ver archivos `*.md` en la raíz del proyecto
- **Guía de usuario:** `INSTRUCCIONES-USUARIOS.md`
- **Modo demo:** `MODO_DEMO.md`
- **Limpieza de datos:** `COMO-LIMPIAR-RESERVAS.md`

---

## 💡 Tips Adicionales

### Para desarrollo local:
```bash
npm run dev
```

### Para probar el backend localmente:
```bash
supabase functions serve make-server-f5c6167b
```

### Para ver logs en tiempo real:
```bash
supabase functions logs make-server-f5c6167b --follow
```

### Para actualizar el backend después de cambios:
```bash
supabase functions deploy make-server-f5c6167b --no-verify-jwt
```

---

**¡Éxito con tu despliegue!** 🚀

Si tienes problemas, revisa la sección de [Troubleshooting](#troubleshooting) o consulta los logs del servidor.
