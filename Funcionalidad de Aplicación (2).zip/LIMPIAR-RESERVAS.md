# 🗑️ CÓMO LIMPIAR RESERVAS VIEJAS

## 🔧 PROBLEMA ARREGLADO:

La detección de conflictos ahora **solo compara reservas del mismo día**.

Antes comparaba reservas de cualquier día, causando conflictos falsos.

---

## ✅ SOLUCIÓN APLICADA:

### **1. Filtro por fecha mejorado**

Ahora el sistema:
1. Toma la fecha de la nueva reserva (Ej: 2026-02-17)
2. Busca solo reservas de ESA fecha
3. Compara horarios solo con esas reservas
4. Ignora reservas de otros días

### **2. Logging detallado**

En los logs del servidor verás:
```
🔍 Buscando conflictos para fecha: 2026-02-17
📋 Reservas existentes para 2026-02-17: 2
⚠️ Conflicto detectado con reserva: {
  existing: "10:00:00 AM - 11:00:00 AM",
  new: "10:30:00 AM - 11:30:00 AM"
}
```

---

## 🗑️ LIMPIAR RESERVAS ANTIGUAS

Si todavía tienes reservas viejas causando problemas, puedes limpiarlas:

### **Opción 1: Usar la consola del navegador (F12)**

1. Abre la consola (F12)
2. Pega este código:

```javascript
// Limpiar TODAS las reservas
fetch('https://czbdjnjywggqkxsbmnmc.supabase.co/functions/v1/make-server-f5c6167b/api/reservations/admin/clear-all', {
  method: 'DELETE',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6YmRqbmp5d2dncWt4c2Jtbm1jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkyMjE4MzQsImV4cCI6MjA1NDc5NzgzNH0.Fpp3XPZh0_1wZr8mQ6KVKUpzqvqC7omewW5gPd1VVYI',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ adminKey: 'sisugrb-admin-2026' })
})
.then(res => res.json())
.then(data => {
  console.log('✅ Reservas eliminadas:', data);
  alert('Reservas eliminadas: ' + data.count);
  window.location.reload(); // Recarga la página
})
.catch(err => console.error('Error:', err));
```

3. Enter
4. Verás un alert con cuántas reservas se eliminaron
5. La página se recarga automáticamente

---

### **Opción 2: Desde Supabase directamente**

1. Ve a: https://app.supabase.com
2. Tu proyecto
3. Table Editor
4. Busca: `reservation:`
5. Selecciona todas las reservas viejas
6. Click "Delete"

---

## 🧪 PROBAR AHORA:

### **Después de limpiar:**

1. **Recarga la página**

2. **Intenta crear una reserva:**
   - Sala Piso 1
   - Hoy
   - Hora: 10:00 - 11:00
   - Motivo: "Prueba"
   
3. **Debería funcionar ✅**

4. **Intenta crear otra en el mismo horario:**
   - Sala Piso 1
   - Hoy
   - Hora: 10:00 - 11:00 (mismo horario)
   - Motivo: "Otra prueba"

5. **Debería dar error ❌** (correcto, hay conflicto)

6. **Intenta con horario diferente:**
   - Sala Piso 1
   - Hoy
   - Hora: 11:00 - 12:00 (diferente)
   - Motivo: "Tercera prueba"

7. **Debería funcionar ✅** (no hay conflicto)

---

## 📊 VERIFICAR EN LOS LOGS:

Abre los logs de Supabase:
https://app.supabase.com → Tu proyecto → Logs → Edge Functions

Deberías ver:
```
📥 Datos de reserva recibidos: {...}
✅ Validaciones pasadas - Room: Sala Piso 1 - User: Tu Nombre
🔍 Buscando conflictos para fecha: 2026-02-15
📋 Reservas existentes para 2026-02-15: 0
✅ Reserva creada exitosamente: 1739654321000
```

Si hay conflicto:
```
📋 Reservas existentes para 2026-02-15: 1
⚠️ Conflicto detectado con reserva: {
  existing: "10:00:00 - 11:00:00",
  new: "10:30:00 - 11:30:00"
}
❌ Conflicto de horario detectado
```

---

## ✅ CONFIRMACIÓN:

Una vez limpiadas las reservas viejas:
- ✅ No más conflictos falsos
- ✅ Puedes crear reservas normalmente
- ✅ Solo se detectan conflictos reales (mismo día, mismo horario)

---

## 🔐 SEGURIDAD DEL ENDPOINT DE LIMPIEZA:

El endpoint de limpieza requiere una clave admin:
```
adminKey: 'sisugrb-admin-2026'
```

Solo tú tienes esta clave, así que solo tú puedes limpiar las reservas.

---

## 💡 RECOMENDACIÓN:

Después de limpiar las reservas viejas, ya no deberías tener más problemas.

El nuevo código solo compara reservas del mismo día, así que:
- ✅ Reserva hoy a las 10:00 AM
- ✅ Reserva mañana a las 10:00 AM (mismo horario, diferente día)
- ❌ Reserva hoy a las 10:00 AM (cuando ya existe una a las 10:00 AM hoy)

---

¡Prueba ahora! 🚀
