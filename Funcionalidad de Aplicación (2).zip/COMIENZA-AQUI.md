# 🚀 ¡COMIENZA AQUÍ! - SISU GRB Room Reservations

¡Hola! Este es tu punto de partida para convertir tu aplicación React actual en una **aplicación de escritorio local** con backend .NET y SQL Server Express.

---

## 📍 ¿Dónde estás ahora?

✅ **Tienes funcionando:**
- ✅ Frontend React con diseño SISU GRB completo
- ✅ Sistema de reservas con mock data (datos de prueba)
- ✅ Autenticación simulada con localStorage
- ✅ Gestión de 3 salas (Piso 1, 2 y 3)
- ✅ Cancelación de reservas con validación de usuario

🎯 **Lo que vamos a lograr:**
- 🎯 Backend .NET corriendo localmente
- 🎯 Base de datos SQL Server Express
- 🎯 Autenticación automática con usuarios de Windows
- 🎯 Datos persistentes (no se pierden al cerrar)
- 🎯 Sistema listo para usar en la red local de SISU GRB

---

## 📚 Documentación Disponible

Tienes **3 guías** completas que te llevarán paso a paso:

### 1️⃣ **PASOS-INSTALACION-ESCRITORIO.md** 
📖 **¿Para qué?** Instalación completa desde cero
- Instalar SQL Server Express
- Crear la base de datos
- Configurar el proyecto .NET en Visual Studio
- Configurar el frontend React
- Ejecutar todo el sistema

👉 **Empieza aquí si es tu primera vez** configurando .NET + SQL Server

### 2️⃣ **MIGRACION-A-API.md**
📖 **¿Para qué?** Convertir tu código React actual para usar la API
- Actualizar App.tsx para usar API en lugar de localStorage
- Conectar formularios de reserva con el backend
- Actualizar funciones de cancelación
- Cambiar de mock data a datos reales

👉 **Úsalo después** de tener el backend funcionando

### 3️⃣ **backend-dotnet/COMENZAR-AQUI.md**
📖 **¿Para qué?** Referencia técnica del backend
- Estructura del código .NET
- Endpoints de la API
- Configuración de Windows Authentication
- Troubleshooting técnico

👉 **Referencia técnica** cuando necesites entender cómo funciona el backend

---

## 🗺️ RUTA RECOMENDADA

Sigue estos pasos EN ORDEN:

```
PASO 1: Instalar Software
  ↓
  📄 PASOS-INSTALACION-ESCRITORIO.md (FASE 1)
  • Instalar SQL Server Express
  • Instalar SQL Server Management Studio
  • Instalar Visual Studio 2022
  ↓
  
PASO 2: Configurar Base de Datos
  ↓
  📄 PASOS-INSTALACION-ESCRITORIO.md (FASE 2)
  • Crear base de datos
  • Ejecutar script SQL
  • Agregar tu usuario de Windows
  ↓
  
PASO 3: Configurar Backend .NET
  ↓
  📄 PASOS-INSTALACION-ESCRITORIO.md (FASE 3)
  • Crear proyecto en Visual Studio
  • Copiar archivos backend
  • Configurar connection string
  • Probar la API con Swagger
  ↓
  
PASO 4: Conectar Frontend
  ↓
  📄 MIGRACION-A-API.md
  • Actualizar App.tsx
  • Conectar formularios
  • Probar reservas
  ↓
  
PASO 5: Iniciar Todo
  ↓
  📄 Ejecutar: start-sisugrb-local.bat
  • Inicia SQL Server
  • Inicia Backend
  • Inicia Frontend
  • Abre navegador
  ↓
  
✅ ¡LISTO!
```

---

## ⚡ INICIO RÁPIDO (si ya tienes experiencia)

Si ya conoces .NET y SQL Server, puedes ir directo al grano:

```bash
# 1. Crear base de datos
Ejecutar: /backend-dotnet/SQL/01-create-database.sql en SSMS

# 2. Crear proyecto .NET
dotnet new webapi -n SisuGrb.RoomReservations
# Copiar archivos de /backend-dotnet/

# 3. Instalar paquetes
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools
dotnet add package Microsoft.AspNetCore.Authentication.Negotiate

# 4. Configurar connection string en appsettings.json
"Server=localhost\\SQLEXPRESS;Database=SisuGrbRoomReservations;..."

# 5. Iniciar backend
dotnet run --urls http://localhost:5000

# 6. En otra terminal, iniciar frontend
npm install
npm run dev

# 7. Abrir navegador
http://localhost:5173
```

---

## 🎯 TU SIGUIENTE ACCIÓN

**¿Primera vez con .NET + SQL Server?**
👉 Abre: `PASOS-INSTALACION-ESCRITORIO.md`
👉 Sigue la **FASE 1** completa

**¿Ya tienes todo instalado?**
👉 Abre: `backend-dotnet/COMENZAR-AQUI.md`
👉 Ve directo a crear el proyecto

**¿Backend ya funciona?**
👉 Abre: `MIGRACION-A-API.md`
👉 Actualiza tu código React

---

## 📦 Archivos Importantes

```
/
├── 📄 COMIENZA-AQUI.md                    ← ESTÁS AQUÍ
├── 📄 PASOS-INSTALACION-ESCRITORIO.md     ← Instalación completa
├── 📄 MIGRACION-A-API.md                  ← Migración de código React
├── 📄 start-sisugrb-local.bat             ← Script para iniciar todo
│
├── 📁 backend-dotnet/
│   ├── 📄 COMENZAR-AQUI.md                ← Guía técnica backend
│   ├── 📄 README.md                       ← Documentación API
│   ├── 📁 SQL/
│   │   └── 01-create-database.sql         ← Script de base de datos
│   ├── 📁 Controllers/                    ← Endpoints de la API
│   ├── 📁 Models/                         ← Modelos de datos
│   ├── 📁 Data/                           ← Entity Framework DbContext
│   └── Program.cs                         ← Configuración .NET
│
├── 📁 src/
│   ├── 📁 app/
│   │   ├── App.tsx                        ← Componente principal
│   │   ├── 📁 components/                 ← Componentes React
│   │   ├── 📁 services/
│   │   │   └── api.ts                     ← ✨ API Service (YA CREADO)
│   │   └── 📁 data/
│   │       └── mock-data.ts               ← Datos de prueba (se eliminará)
│   └── main.tsx
│
└── package.json
```

---

## 🎬 Video Mental del Proceso

Imagina esto:

1. **Instalas SQL Server** → Tu PC ahora tiene una base de datos profesional
2. **Creas el proyecto .NET** → El backend que procesa las reservas
3. **Ejecutas el script SQL** → Se crean las tablas: Users, Rooms, Reservations, Teams
4. **Agregas tu usuario** → Tu usuario de Windows `SISUGRB\tunombre` queda registrado
5. **Inicias el backend** → Visual Studio ejecuta el servidor en puerto 5000
6. **Inicias el frontend** → React se conecta al backend automáticamente
7. **Abres el navegador** → ¡La app detecta tu usuario de Windows automáticamente!
8. **Haces una reserva** → Se guarda en SQL Server (¡persiste para siempre!)
9. **Cierras y abres la app** → ¡Tus reservas siguen ahí!

---

## ❓ FAQ Rápido

**P: ¿Cuánto tiempo toma?**
R: Primera vez: 1-2 horas. Si ya conoces .NET: 30 minutos.

**P: ¿Necesito internet?**
R: Solo para descargar software (SQL Server, Visual Studio, Node.js). Después todo es local.

**P: ¿Se puede usar en múltiples computadoras?**
R: Sí! Configuras el SQL Server en una PC servidor, y las demás se conectan por red local.

**P: ¿Puedo seguir usando la versión actual mientras configuro?**
R: ¡Sí! Tu código actual NO se toca hasta que tengas el backend listo.

**P: ¿Qué pasa si me equivoco?**
R: Todo es reversible. Puedes eliminar la base de datos y el proyecto .NET sin afectar tu código React.

**P: ¿Necesito ser administrador de Windows?**
R: Sí, para instalar SQL Server y Visual Studio. Pero solo una vez.

---

## 🆘 ¿Necesitas Ayuda?

Si te atascas en algún paso:

1. 📖 Revisa la sección "🐛 Troubleshooting" en cada guía
2. 🔍 Busca el error exacto en la consola
3. 📝 Verifica la checklist de cada fase
4. 🎯 Asegúrate de seguir los pasos EN ORDEN

### Errores Comunes (con soluciones):

| Error | Solución Rápida |
|-------|----------------|
| "Cannot connect to SQL Server" | Verificar que SQL Server esté corriendo en services.msc |
| "401 Unauthorized" | Tu usuario Windows no está en la tabla Users |
| "Port 5000 already in use" | Cambiar puerto en launchSettings.json |
| "CORS policy error" | Verificar configuración de CORS en Program.cs |
| "npm install fails" | Ejecutar como administrador o usar `npm install --legacy-peer-deps` |

---

## ✅ Checklist Pre-Inicio

Antes de empezar, asegúrate de tener:

- [ ] Windows 10/11 (con permisos de administrador)
- [ ] Al menos 5 GB de espacio libre en disco
- [ ] Conexión a internet (para descargar software)
- [ ] Tu usuario de Windows debe seguir el formato: `SISUGRB\tunombre`
- [ ] Node.js ya instalado (si no, se instalará en FASE 1)

---

## 🎉 ¡Manos a la Obra!

**Cuando estés listo, abre:**

```
PASOS-INSTALACION-ESCRITORIO.md
```

Y comienza con la **FASE 1: Configurar SQL Server**

---

**💡 Consejo Final:**
No te apresures. Lee cada paso completamente ANTES de ejecutarlo. 
Es mejor ir despacio y hacerlo bien, que rápido y tener que corregir errores.

**¡Buena suerte! 🚀**

---

*Creado para SISU GRB • Sistema de Reservas de Salas de Juntas*
