# Backend .NET - Sistema de Reservas SISU GRB

## 🔧 Requisitos Previos

1. **.NET 8 SDK** instalado
2. **SQL Server Express** instalado
3. **Visual Studio 2022** o **VS Code**
4. **Git** (opcional)

## 📦 Crear el Proyecto

### Paso 1: Crear la Solución y Proyectos

Abre una terminal y ejecuta:

```bash
# Crear carpeta del proyecto
mkdir SisuGrb.RoomReservations
cd SisuGrb.RoomReservations

# Crear solución
dotnet new sln -n SisuGrb.RoomReservations

# Crear proyecto Web API
dotnet new webapi -n SisuGrb.RoomReservations.API

# Crear proyecto de Class Library para Core (Lógica de negocio)
dotnet new classlib -n SisuGrb.RoomReservations.Core

# Crear proyecto de Class Library para Data (Acceso a datos)
dotnet new classlib -n SisuGrb.RoomReservations.Data

# Agregar proyectos a la solución
dotnet sln add SisuGrb.RoomReservations.API/SisuGrb.RoomReservations.API.csproj
dotnet sln add SisuGrb.RoomReservations.Core/SisuGrb.RoomReservations.Core.csproj
dotnet sln add SisuGrb.RoomReservations.Data/SisuGrb.RoomReservations.Data.csproj

# Agregar referencias entre proyectos
cd SisuGrb.RoomReservations.API
dotnet add reference ../SisuGrb.RoomReservations.Core/SisuGrb.RoomReservations.Core.csproj
dotnet add reference ../SisuGrb.RoomReservations.Data/SisuGrb.RoomReservations.Data.csproj

cd ../SisuGrb.RoomReservations.Core
dotnet add reference ../SisuGrb.RoomReservations.Data/SisuGrb.RoomReservations.Data.csproj

cd ..
```

### Paso 2: Instalar Paquetes NuGet

```bash
# En el proyecto API
cd SisuGrb.RoomReservations.API
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools
dotnet add package Microsoft.AspNetCore.Authentication.Negotiate
dotnet add package Swashbuckle.AspNetCore

# En el proyecto Data
cd ../SisuGrb.RoomReservations.Data
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools
dotnet add package Microsoft.EntityFrameworkCore.Design

cd ..
```

### Paso 3: Copiar los Archivos de Configuración

Copia los archivos de este directorio (`/backend-dotnet`) a tu proyecto:

- `Models/` → Copiar a `SisuGrb.RoomReservations.Core/Models/`
- `DTOs/` → Copiar a `SisuGrb.RoomReservations.Core/DTOs/`
- `Interfaces/` → Copiar a `SisuGrb.RoomReservations.Core/Interfaces/`
- `Services/` → Copiar a `SisuGrb.RoomReservations.Core/Services/`
- `Data/` → Copiar a `SisuGrb.RoomReservations.Data/`
- `Controllers/` → Copiar a `SisuGrb.RoomReservations.API/Controllers/`
- `Program.cs` → Reemplazar en `SisuGrb.RoomReservations.API/Program.cs`
- `appsettings.json` → Reemplazar en `SisuGrb.RoomReservations.API/appsettings.json`

### Paso 4: Configurar la Base de Datos

1. Abre SQL Server Management Studio (SSMS)
2. Conéctate a tu instancia local: `localhost\SQLEXPRESS`
3. Ejecuta el script `database-schema.sql` ubicado en `/backend-dotnet/SQL/`
4. Ejecuta el script `database-seed.sql` para poblar datos iniciales

### Paso 5: Actualizar Connection String

Edita `appsettings.json` en el proyecto API y ajusta la cadena de conexión:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=SisuGrbRoomReservations;Integrated Security=true;TrustServerCertificate=True;"
  }
}
```

### Paso 6: Ejecutar Migraciones de Entity Framework

```bash
cd SisuGrb.RoomReservations.API

# Crear migración inicial
dotnet ef migrations add InitialCreate --project ../SisuGrb.RoomReservations.Data

# Aplicar migración a la base de datos
dotnet ef database update --project ../SisuGrb.RoomReservations.Data
```

### Paso 7: Ejecutar el Proyecto

```bash
cd SisuGrb.RoomReservations.API
dotnet run
```

Abre tu navegador en: `http://localhost:5000/swagger`

## 🔐 Configurar Windows Authentication

### En desarrollo (IIS Express):

Edita `launchSettings.json`:

```json
{
  "profiles": {
    "SisuGrb.RoomReservations.API": {
      "commandName": "Project",
      "launchBrowser": true,
      "launchUrl": "swagger",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      },
      "applicationUrl": "http://localhost:5000",
      "windowsAuthentication": true,
      "anonymousAuthentication": false
    }
  }
}
```

## 📚 Próximos Pasos

1. ✅ Backend API funcionando
2. ⏳ Probar endpoints con Postman
3. ⏳ Conectar frontend React
4. ⏳ Configurar CORS
5. ⏳ Deploy a producción

## 🐛 Troubleshooting

### Error: "Cannot connect to SQL Server"
- Verifica que SQL Server Express esté corriendo
- Revisa la cadena de conexión en `appsettings.json`

### Error: "Windows Authentication failed"
- Asegúrate de que `windowsAuthentication: true` en `launchSettings.json`
- Verifica que tu usuario Windows esté en la base de datos

### Error: "Port 5000 already in use"
- Cambia el puerto en `applicationUrl` en `launchSettings.json`
