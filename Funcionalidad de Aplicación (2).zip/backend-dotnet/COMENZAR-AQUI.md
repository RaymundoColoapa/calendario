# 🚀 GUÍA RÁPIDA: Comenzar con la Migración

## ✅ Paso 1: Preparar SQL Server Express

### 1.1 Verificar que SQL Server Express esté instalado
```powershell
# Abrir PowerShell como Administrador y ejecutar:
Get-Service | Where-Object {$_.Name -like "*SQL*"}
```

Si ves servicios como `MSSQL$SQLEXPRESS` o `SQLBrowser`, SQL Server está instalado.

### 1.2 Instalar SQL Server Express (si no lo tienes)
1. Descargar: https://www.microsoft.com/es-es/sql-server/sql-server-downloads
2. Elegir **Express Edition** (gratuita)
3. Durante la instalación, elegir **Basic**
4. Anotar el nombre de la instancia (usualmente: `localhost\SQLEXPRESS`)

### 1.3 Instalar SQL Server Management Studio (SSMS)
1. Descargar: https://aka.ms/ssmsfullsetup
2. Instalar con opciones por defecto

---

## ✅ Paso 2: Crear la Base de Datos

### 2.1 Abrir SQL Server Management Studio
1. Conectarse a: `localhost\SQLEXPRESS`
2. Tipo de autenticación: **Windows Authentication**

### 2.2 Ejecutar el Script SQL
1. En SSMS, ir a **File → Open → File...**
2. Navegar a: `/backend-dotnet/SQL/01-create-database.sql`
3. Presionar **F5** o click en **Execute**
4. Verificar que se ejecute sin errores

✅ **Resultado esperado:** Verás un mensaje que dice "✅ ¡Base de datos creada exitosamente!" con un resumen de tablas.

---

## ✅ Paso 3: Crear el Proyecto .NET

### 3.1 Abrir Visual Studio 2022
1. Crear nuevo proyecto: **ASP.NET Core Web API**
2. Nombre del proyecto: `SisuGrb.RoomReservations.API`
3. Framework: **.NET 8.0**
4. Desmarcar "Use controllers" si usa minimal APIs (nosotros usamos controllers)
5. **Marcar**: "Enable OpenAPI support" (Swagger)

### 3.2 Agregar Proyectos Class Library
1. Click derecho en la Solución → **Add → New Project**
2. Elegir **Class Library** (.NET 8)
3. Nombre: `SisuGrb.RoomReservations.Core`
4. Repetir para crear: `SisuGrb.RoomReservations.Data`

### 3.3 Copiar los Archivos
Desde este repositorio (`/backend-dotnet`), copia:

| Desde | Hacia |
|-------|-------|
| `/Models/*.cs` | `SisuGrb.RoomReservations.Core/Models/` |
| `/Data/AppDbContext.cs` | `SisuGrb.RoomReservations.Data/` |
| `/Controllers/*.cs` | `SisuGrb.RoomReservations.API/Controllers/` |
| `/Program.cs` | `SisuGrb.RoomReservations.API/` (reemplazar) |
| `/appsettings.json` | `SisuGrb.RoomReservations.API/` (reemplazar) |

---

## ✅ Paso 4: Instalar Paquetes NuGet

### 4.1 En el proyecto API:
```bash
Install-Package Microsoft.EntityFrameworkCore.SqlServer
Install-Package Microsoft.EntityFrameworkCore.Tools
Install-Package Microsoft.AspNetCore.Authentication.Negotiate
```

### 4.2 En el proyecto Data:
```bash
Install-Package Microsoft.EntityFrameworkCore.SqlServer
Install-Package Microsoft.EntityFrameworkCore.Tools
```

---

## ✅ Paso 5: Configurar Connection String

Edita `appsettings.json` en el proyecto API:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=SisuGrbRoomReservations;Integrated Security=true;TrustServerCertificate=True;"
  }
}
```

⚠️ **Importante:** Si tu instancia de SQL Server tiene otro nombre, reemplaza `localhost\\SQLEXPRESS`.

---

## ✅ Paso 6: Probar la Conexión

### 6.1 Configurar Windows Authentication en launchSettings.json

En el proyecto API, edita `Properties/launchSettings.json`:

```json
{
  "profiles": {
    "SisuGrb.RoomReservations.API": {
      "commandName": "Project",
      "launchBrowser": true,
      "launchUrl": "swagger",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development"
      },
      "applicationUrl": "http://localhost:5000",
      "windowsAuthentication": true,
      "anonymousAuthentication": false
    }
  }
}
```

### 6.2 Ejecutar el Proyecto
1. Presiona **F5** en Visual Studio
2. Se abrirá Swagger en el navegador: `http://localhost:5000/swagger`

### 6.3 Probar el Endpoint
1. En Swagger, busca `GET /api/users/current`
2. Click en **Try it out** → **Execute**
3. Deberías ver tu información de usuario Windows

✅ **Si funciona:** ¡Tu backend está listo!
❌ **Si da error:** Revisa que tu usuario Windows esté en la tabla `Users` de la base de datos.

---

## ✅ Paso 7: Conectar el Frontend React

### 7.1 Crear servicio API en React

Crea el archivo `/src/app/services/api.ts`:

```typescript
const API_BASE_URL = 'http://localhost:5000/api';

export const api = {
  getCurrentUser: async () => {
    const response = await fetch(`${API_BASE_URL}/users/current`, {
      credentials: 'include', // IMPORTANTE para Windows Auth
    });
    
    if (!response.ok) {
      throw new Error('No autenticado');
    }
    
    return response.json();
  },

  getRooms: async () => {
    const response = await fetch(`${API_BASE_URL}/rooms`, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener salas');
    }
    
    return response.json();
  },

  getUsers: async () => {
    const response = await fetch(`${API_BASE_URL}/users`, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Error al obtener usuarios');
    }
    
    return response.json();
  },
};
```

### 7.2 Actualizar App.tsx

Reemplaza la carga de datos mockeados por llamadas API:

```typescript
useEffect(() => {
  const loadData = async () => {
    try {
      // Cargar usuario actual
      const user = await api.getCurrentUser();
      setCurrentUser(user);
      setIsAuthenticated(true);

      // Cargar salas
      const roomsData = await api.getRooms();
      setRooms(roomsData);

      // Cargar usuarios para autocompletado
      const usersData = await api.getUsers();
      setTeamMembers(usersData);

    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al cargar datos del servidor');
    }
  };

  loadData();
}, []);
```

---

## ✅ Paso 8: Probar el Sistema Completo

1. **Backend ejecutándose:** Visual Studio con F5
2. **Frontend ejecutándose:** Terminal con `npm run dev`
3. Abre el navegador en: `http://localhost:5173`
4. **¡Deberías ver tu usuario Windows automáticamente!**

---

## 🎯 Próximos Pasos (Opcional)

Una vez que todo funcione:

1. ✅ Crear endpoints para Reservations (POST, DELETE, GET)
2. ✅ Implementar validaciones de horario y conflictos
3. ✅ Agregar stored procedures para lógica compleja
4. ✅ Configurar deployment en IIS
5. ✅ Agregar auditoría y logs

---

## 🐛 Troubleshooting Común

### Error: "Cannot connect to SQL Server"
```
Solución:
1. Verifica que SQL Server esté corriendo
2. Abre "SQL Server Configuration Manager"
3. Verifica que "SQL Server (SQLEXPRESS)" esté Started
4. Verifica que TCP/IP esté habilitado en "Protocols"
```

### Error: "Windows Authentication failed"
```
Solución:
1. Asegúrate de que windowsAuthentication: true en launchSettings.json
2. Verifica que tu usuario Windows (DOMINIO\usuario) esté en la tabla Users
3. Ejecuta en SSMS:
   SELECT * FROM Users WHERE WindowsUsername LIKE '%tu_usuario%'
```

### Error: "CORS policy error"
```
Solución:
1. Verifica que Program.cs tenga configurado CORS
2. Asegúrate de que app.UseCors("AllowFrontend") esté antes de app.UseAuthorization()
3. Verifica que el puerto del frontend (5173) esté en la política CORS
```

### Error: "Port 5000 already in use"
```
Solución:
1. Cambia el puerto en launchSettings.json
2. O detén el proceso que usa el puerto 5000:
   netstat -ano | findstr :5000
   taskkill /PID [numero_pid] /F
```

---

## 📞 ¿Necesitas Ayuda?

Si encuentras algún problema:
1. Revisa los logs en Visual Studio (Output window)
2. Revisa la consola del navegador (F12)
3. Verifica que todos los servicios estén corriendo

**¡Buena suerte con la migración! 🚀**
