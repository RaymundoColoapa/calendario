-- ============================================================================
-- Script de Creación de Base de Datos
-- Sistema de Reservas de Salas - SISU GRB
-- SQL Server Express
-- ============================================================================

USE master;
GO

-- Crear base de datos si no existe
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'SisuGrbRoomReservations')
BEGIN
    CREATE DATABASE SisuGrbRoomReservations;
    PRINT 'Base de datos SisuGrbRoomReservations creada exitosamente.';
END
GO

USE SisuGrbRoomReservations;
GO

-- ============================================================================
-- TABLAS PRINCIPALES
-- ============================================================================

-- 1. Teams (Equipos/Departamentos)
CREATE TABLE Teams (
    TeamId INT IDENTITY(1,1) PRIMARY KEY,
    TeamName NVARCHAR(100) NOT NULL UNIQUE,
    Description NVARCHAR(500),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    IsActive BIT DEFAULT 1
);

-- 2. Users (Usuarios/Miembros del Equipo)
CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200) NOT NULL,
    Email NVARCHAR(200) NOT NULL UNIQUE,
    WindowsUsername NVARCHAR(200) NOT NULL,
    TeamId INT NOT NULL,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    CONSTRAINT FK_Users_Teams FOREIGN KEY (TeamId) REFERENCES Teams(TeamId)
);

-- Índices para búsqueda rápida
CREATE INDEX IX_Users_Email ON Users(Email);
CREATE INDEX IX_Users_TeamId ON Users(TeamId);
CREATE UNIQUE INDEX IX_Users_WindowsUsername ON Users(WindowsUsername);

-- 3. Rooms (Salas de Juntas)
CREATE TABLE Rooms (
    RoomId INT IDENTITY(1,1) PRIMARY KEY,
    RoomName NVARCHAR(100) NOT NULL,
    Location NVARCHAR(100) NOT NULL,
    Capacity INT NOT NULL,
    Floor INT NOT NULL,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE()
);

-- 4. RoomAmenities (Servicios de las Salas)
CREATE TABLE RoomAmenities (
    AmenityId INT IDENTITY(1,1) PRIMARY KEY,
    RoomId INT NOT NULL,
    AmenityName NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_RoomAmenities_Rooms FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId)
);

-- 5. RoomStatus (Estados de las Salas)
CREATE TABLE RoomStatus (
    StatusId INT IDENTITY(1,1) PRIMARY KEY,
    StatusName NVARCHAR(50) NOT NULL UNIQUE -- 'Available', 'Occupied', 'Maintenance'
);

-- 6. RoomCurrentStatus (Estado Actual de cada Sala)
CREATE TABLE RoomCurrentStatus (
    RoomId INT PRIMARY KEY,
    StatusId INT NOT NULL,
    LastUpdated DATETIME2 DEFAULT GETDATE(),
    UpdatedBy INT, -- UserId que cambió el estado
    MaintenanceStartTime TIME,
    MaintenanceEndTime TIME,
    CONSTRAINT FK_RoomCurrentStatus_Rooms FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId),
    CONSTRAINT FK_RoomCurrentStatus_Status FOREIGN KEY (StatusId) REFERENCES RoomStatus(StatusId),
    CONSTRAINT FK_RoomCurrentStatus_User FOREIGN KEY (UpdatedBy) REFERENCES Users(UserId)
);

-- 7. Reservations (Reservas)
CREATE TABLE Reservations (
    ReservationId INT IDENTITY(1,1) PRIMARY KEY,
    RoomId INT NOT NULL,
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000),
    ReservationDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    OrganizerId INT NOT NULL, -- Usuario que organiza
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    CreatedBy INT NOT NULL, -- Usuario que creó la reserva
    IsCancelled BIT DEFAULT 0,
    CancelledAt DATETIME2,
    CancelledBy INT,
    CONSTRAINT FK_Reservations_Rooms FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId),
    CONSTRAINT FK_Reservations_Organizer FOREIGN KEY (OrganizerId) REFERENCES Users(UserId),
    CONSTRAINT FK_Reservations_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
    CONSTRAINT FK_Reservations_CancelledBy FOREIGN KEY (CancelledBy) REFERENCES Users(UserId),
    CONSTRAINT CHK_Reservations_Time CHECK (StartTime < EndTime)
);

-- Índices para mejorar consultas
CREATE INDEX IX_Reservations_RoomDate ON Reservations(RoomId, ReservationDate);
CREATE INDEX IX_Reservations_Organizer ON Reservations(OrganizerId);

-- 8. ReservationAttendees (Asistentes a las Reuniones)
CREATE TABLE ReservationAttendees (
    AttendeeId INT IDENTITY(1,1) PRIMARY KEY,
    ReservationId INT NOT NULL,
    UserId INT NOT NULL,
    CONSTRAINT FK_ReservationAttendees_Reservation FOREIGN KEY (ReservationId) REFERENCES Reservations(ReservationId),
    CONSTRAINT FK_ReservationAttendees_User FOREIGN KEY (UserId) REFERENCES Users(UserId),
    CONSTRAINT UQ_ReservationAttendees UNIQUE(ReservationId, UserId)
);

-- 9. ServiceTypes (Tipos de Servicios)
CREATE TABLE ServiceTypes (
    ServiceTypeId INT IDENTITY(1,1) PRIMARY KEY,
    ServiceName NVARCHAR(100) NOT NULL UNIQUE
);

-- 10. ReservationServices (Servicios solicitados por Reserva)
CREATE TABLE ReservationServices (
    ReservationServiceId INT IDENTITY(1,1) PRIMARY KEY,
    ReservationId INT NOT NULL,
    ServiceTypeId INT NOT NULL,
    CONSTRAINT FK_ReservationServices_Reservation FOREIGN KEY (ReservationId) REFERENCES Reservations(ReservationId),
    CONSTRAINT FK_ReservationServices_ServiceType FOREIGN KEY (ServiceTypeId) REFERENCES ServiceTypes(ServiceTypeId),
    CONSTRAINT UQ_ReservationServices UNIQUE(ReservationId, ServiceTypeId)
);

PRINT 'Todas las tablas creadas exitosamente.';
GO

-- ============================================================================
-- DATOS INICIALES (SEED DATA)
-- ============================================================================

-- Teams
INSERT INTO Teams (TeamName, Description) VALUES 
    ('Desarrollo', 'Equipo de desarrollo de software'),
    ('Marketing', 'Equipo de marketing y comunicación'),
    ('Ventas', 'Equipo de ventas'),
    ('Recursos Humanos', 'Recursos humanos'),
    ('Diseño', 'Equipo de diseño gráfico y UX'),
    ('Operaciones', 'Operaciones y logística'),
    ('Finanzas', 'Finanzas y contabilidad'),
    ('TI', 'Tecnologías de la información');

PRINT 'Teams insertados.';

-- Users
INSERT INTO Users (FullName, Email, WindowsUsername, TeamId) VALUES 
    ('María González', 'maria.gonzalez@sisugrb.com', 'SISUGRB\mgonzalez', 1),
    ('Juan Pérez', 'juan.perez@sisugrb.com', 'SISUGRB\jperez', 1),
    ('Ana Rodríguez', 'ana.rodriguez@sisugrb.com', 'SISUGRB\arodriguez', 2),
    ('Carlos Méndez', 'carlos.mendez@sisugrb.com', 'SISUGRB\cmendez', 3),
    ('Laura Martínez', 'laura.martinez@sisugrb.com', 'SISUGRB\lmartinez', 4),
    ('Pedro Gómez', 'pedro.gomez@sisugrb.com', 'SISUGRB\pgomez', 1),
    ('Sofía López', 'sofia.lopez@sisugrb.com', 'SISUGRB\slopez', 5),
    ('Diego Torres', 'diego.torres@sisugrb.com', 'SISUGRB\dtorres', 6),
    ('Carmen Ruiz', 'carmen.ruiz@sisugrb.com', 'SISUGRB\cruiz', 7),
    ('Miguel Ángel Sánchez', 'miguel.sanchez@sisugrb.com', 'SISUGRB\msanchez', 8),
    ('Isabel Fernández', 'isabel.fernandez@sisugrb.com', 'SISUGRB\ifernandez', 2),
    ('Roberto Jiménez', 'roberto.jimenez@sisugrb.com', 'SISUGRB\rjimenez', 3),
    ('Patricia Morales', 'patricia.morales@sisugrb.com', 'SISUGRB\pmorales', 4),
    ('Fernando Castro', 'fernando.castro@sisugrb.com', 'SISUGRB\fcastro', 6),
    ('Gabriela Ortiz', 'gabriela.ortiz@sisugrb.com', 'SISUGRB\gortiz', 5),
    ('Andrés Vargas', 'andres.vargas@sisugrb.com', 'SISUGRB\avargas', 8),
    ('Valentina Herrera', 'valentina.herrera@sisugrb.com', 'SISUGRB\vherrera', 2),
    ('Ricardo Ramírez', 'ricardo.ramirez@sisugrb.com', 'SISUGRB\rramirez', 7),
    ('Daniela Silva', 'daniela.silva@sisugrb.com', 'SISUGRB\dsilva', 3),
    ('Javier Medina', 'javier.medina@sisugrb.com', 'SISUGRB\jmedina', 1);

PRINT 'Users insertados.';

-- Rooms
INSERT INTO Rooms (RoomName, Location, Capacity, Floor) VALUES 
    ('Sala de Juntas Piso 1', 'Piso 1', 10, 1),
    ('Sala de Juntas Piso 2', 'Piso 2', 10, 2),
    ('Sala de Juntas Piso 3', 'Piso 3 - Capacitación', 30, 3);

PRINT 'Rooms insertados.';

-- Room Status
INSERT INTO RoomStatus (StatusName) VALUES 
    ('Available'), 
    ('Occupied'), 
    ('Maintenance');

PRINT 'RoomStatus insertados.';

-- Room Current Status (todas disponibles inicialmente)
INSERT INTO RoomCurrentStatus (RoomId, StatusId) VALUES 
    (1, 1),
    (2, 1),
    (3, 1);

PRINT 'RoomCurrentStatus insertados.';

-- Room Amenities
INSERT INTO RoomAmenities (RoomId, AmenityName) VALUES 
    -- Piso 1
    (1, 'Cafés'),
    (1, 'Aguas'),
    (1, 'Galletas'),
    (1, 'Refrescos'),
    (1, 'IdeaShare'),
    -- Piso 2
    (2, 'Cafés'),
    (2, 'Aguas'),
    (2, 'Galletas'),
    (2, 'Refrescos'),
    (2, 'IdeaShare'),
    -- Piso 3
    (3, 'Cafés'),
    (3, 'Aguas'),
    (3, 'Galletas'),
    (3, 'Refrescos'),
    (3, 'IdeaShare');

PRINT 'RoomAmenities insertados.';

-- Service Types
INSERT INTO ServiceTypes (ServiceName) VALUES 
    ('Cafés'), 
    ('Aguas'), 
    ('Galletas'), 
    ('Refrescos'), 
    ('IdeaShare');

PRINT 'ServiceTypes insertados.';

PRINT '';
PRINT '✅ ¡Base de datos creada exitosamente!';
PRINT '';
PRINT '📊 Resumen:';
SELECT 'Teams' AS Tabla, COUNT(*) AS Total FROM Teams
UNION ALL
SELECT 'Users', COUNT(*) FROM Users
UNION ALL
SELECT 'Rooms', COUNT(*) FROM Rooms
UNION ALL
SELECT 'RoomStatus', COUNT(*) FROM RoomStatus
UNION ALL
SELECT 'RoomAmenities', COUNT(*) FROM RoomAmenities
UNION ALL
SELECT 'ServiceTypes', COUNT(*) FROM ServiceTypes;

GO
