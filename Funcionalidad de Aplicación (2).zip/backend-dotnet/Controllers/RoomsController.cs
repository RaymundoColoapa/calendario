using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SisuGrb.RoomReservations.Data;

namespace SisuGrb.RoomReservations.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RoomsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public RoomsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/rooms
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetRooms()
        {
            var rooms = await _context.Rooms
                .Include(r => r.Amenities)
                .Include(r => r.CurrentStatus)
                    .ThenInclude(cs => cs!.Status)
                .Where(r => r.IsActive)
                .Select(r => new
                {
                    id = r.RoomId.ToString(),
                    name = r.RoomName,
                    location = r.Location,
                    capacity = r.Capacity,
                    status = r.CurrentStatus != null ? r.CurrentStatus.Status.StatusName.ToLower() : "available",
                    amenities = r.Amenities.Select(a => a.AmenityName).ToList()
                })
                .ToListAsync();

            return Ok(rooms);
        }

        // GET: api/rooms/5
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetRoom(int id)
        {
            var room = await _context.Rooms
                .Include(r => r.Amenities)
                .Include(r => r.CurrentStatus)
                    .ThenInclude(cs => cs!.Status)
                .FirstOrDefaultAsync(r => r.RoomId == id);

            if (room == null)
            {
                return NotFound();
            }

            return Ok(new
            {
                id = room.RoomId.ToString(),
                name = room.RoomName,
                location = room.Location,
                capacity = room.Capacity,
                status = room.CurrentStatus != null ? room.CurrentStatus.Status.StatusName.ToLower() : "available",
                amenities = room.Amenities.Select(a => a.AmenityName).ToList()
            });
        }

        // PUT: api/rooms/5/status
        // Cambiar el estado de una sala (available, occupied, maintenance)
        [HttpPut("{id}/status")]
        public async Task<IActionResult> UpdateRoomStatus(int id, [FromBody] UpdateStatusRequest request)
        {
            var windowsUsername = User.Identity?.Name;
            if (string.IsNullOrEmpty(windowsUsername))
                return Unauthorized();

            var currentUser = await _context.Users
                .FirstOrDefaultAsync(u => u.WindowsUsername.ToLower() == windowsUsername.ToLower());

            if (currentUser == null)
                return NotFound("Usuario no encontrado");

            var room = await _context.Rooms
                .Include(r => r.CurrentStatus)
                .FirstOrDefaultAsync(r => r.RoomId == id);

            if (room == null)
                return NotFound("Sala no encontrada");

            // Buscar el StatusId por nombre
            var status = await _context.RoomStatuses
                .FirstOrDefaultAsync(s => s.StatusName.ToLower() == request.Status.ToLower());

            if (status == null)
                return BadRequest("Estado inválido. Valores permitidos: available, occupied, maintenance");

            // Actualizar o crear el estado actual de la sala
            if (room.CurrentStatus == null)
            {
                var newStatus = new SisuGrb.RoomReservations.Core.Models.RoomCurrentStatus
                {
                    RoomId = id,
                    StatusId = status.StatusId,
                    UpdatedBy = currentUser.UserId,
                    LastUpdated = DateTime.Now
                };
                _context.RoomCurrentStatuses.Add(newStatus);
            }
            else
            {
                room.CurrentStatus.StatusId = status.StatusId;
                room.CurrentStatus.UpdatedBy = currentUser.UserId;
                room.CurrentStatus.LastUpdated = DateTime.Now;
            }

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }

    public class UpdateStatusRequest
    {
        public string Status { get; set; } = string.Empty; // "available", "occupied", "maintenance"
    }
}
