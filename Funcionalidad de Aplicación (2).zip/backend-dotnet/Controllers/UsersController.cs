using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SisuGrb.RoomReservations.Data;

namespace SisuGrb.RoomReservations.API.Controllers
{
    [Authorize] // Requiere Windows Authentication
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UsersController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/users/current
        // Obtiene el usuario actual basado en Windows Authentication
        [HttpGet("current")]
        public async Task<ActionResult<object>> GetCurrentUser()
        {
            // Obtener el username de Windows automáticamente
            var windowsUsername = User.Identity?.Name; // Ej: "SISUGRB\\mgonzalez"

            if (string.IsNullOrEmpty(windowsUsername))
            {
                return Unauthorized(new { message = "No se pudo detectar el usuario de Windows" });
            }

            // Buscar el usuario en la base de datos
            var user = await _context.Users
                .Include(u => u.Team)
                .FirstOrDefaultAsync(u => u.WindowsUsername.ToLower() == windowsUsername.ToLower());

            if (user == null)
            {
                return NotFound(new
                {
                    message = "Usuario no encontrado en el sistema",
                    windowsUsername = windowsUsername,
                    hint = "Asegúrate de que el usuario esté registrado en la base de datos"
                });
            }

            if (!user.IsActive)
            {
                return Unauthorized(new { message = "El usuario está inactivo" });
            }

            // Retornar el usuario en formato compatible con el frontend
            return Ok(new
            {
                id = user.UserId.ToString(),
                name = user.FullName,
                email = user.Email,
                windowsUsername = user.WindowsUsername,
                team = user.Team.TeamName
            });
        }

        // GET: api/users
        // Obtiene todos los usuarios (para el autocompletado)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetUsers()
        {
            var users = await _context.Users
                .Include(u => u.Team)
                .Where(u => u.IsActive)
                .OrderBy(u => u.FullName)
                .Select(u => new
                {
                    id = u.UserId.ToString(),
                    name = u.FullName,
                    email = u.Email,
                    windowsUsername = u.WindowsUsername,
                    team = u.Team.TeamName
                })
                .ToListAsync();

            return Ok(users);
        }

        // GET: api/users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetUser(int id)
        {
            var user = await _context.Users
                .Include(u => u.Team)
                .FirstOrDefaultAsync(u => u.UserId == id);

            if (user == null)
            {
                return NotFound();
            }

            return Ok(new
            {
                id = user.UserId.ToString(),
                name = user.FullName,
                email = user.Email,
                windowsUsername = user.WindowsUsername,
                team = user.Team.TeamName
            });
        }
    }
}
