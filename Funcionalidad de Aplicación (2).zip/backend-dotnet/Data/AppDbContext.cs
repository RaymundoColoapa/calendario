using Microsoft.EntityFrameworkCore;
using SisuGrb.RoomReservations.Core.Models;

namespace SisuGrb.RoomReservations.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // DbSets
        public DbSet<Team> Teams { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<RoomAmenity> RoomAmenities { get; set; }
        public DbSet<RoomStatus> RoomStatuses { get; set; }
        public DbSet<RoomCurrentStatus> RoomCurrentStatuses { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<ReservationAttendee> ReservationAttendees { get; set; }
        public DbSet<ServiceType> ServiceTypes { get; set; }
        public DbSet<ReservationService> ReservationServices { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configurar índices únicos
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasIndex(u => u.WindowsUsername)
                .IsUnique();

            modelBuilder.Entity<Team>()
                .HasIndex(t => t.TeamName)
                .IsUnique();

            modelBuilder.Entity<RoomStatus>()
                .HasIndex(rs => rs.StatusName)
                .IsUnique();

            modelBuilder.Entity<ServiceType>()
                .HasIndex(st => st.ServiceName)
                .IsUnique();

            // Configurar relación de Reservation con User (múltiples FK)
            modelBuilder.Entity<Reservation>()
                .HasOne(r => r.Organizer)
                .WithMany(u => u.OrganizedReservations)
                .HasForeignKey(r => r.OrganizerId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Reservation>()
                .HasOne(r => r.Creator)
                .WithMany()
                .HasForeignKey(r => r.CreatedBy)
                .OnDelete(DeleteBehavior.Restrict);

            // Configurar restricciones únicas
            modelBuilder.Entity<ReservationAttendee>()
                .HasIndex(ra => new { ra.ReservationId, ra.UserId })
                .IsUnique();

            modelBuilder.Entity<ReservationService>()
                .HasIndex(rs => new { rs.ReservationId, rs.ServiceTypeId })
                .IsUnique();

            // Seed data inicial
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Teams
            modelBuilder.Entity<Team>().HasData(
                new Team { TeamId = 1, TeamName = "Desarrollo", Description = "Equipo de desarrollo de software" },
                new Team { TeamId = 2, TeamName = "Marketing", Description = "Equipo de marketing y comunicación" },
                new Team { TeamId = 3, TeamName = "Ventas", Description = "Equipo de ventas" },
                new Team { TeamId = 4, TeamName = "Recursos Humanos", Description = "Recursos humanos" },
                new Team { TeamId = 5, TeamName = "Diseño", Description = "Equipo de diseño gráfico y UX" },
                new Team { TeamId = 6, TeamName = "Operaciones", Description = "Operaciones y logística" },
                new Team { TeamId = 7, TeamName = "Finanzas", Description = "Finanzas y contabilidad" },
                new Team { TeamId = 8, TeamName = "TI", Description = "Tecnologías de la información" }
            );

            // Users
            modelBuilder.Entity<User>().HasData(
                new User { UserId = 1, FullName = "María González", Email = "maria.gonzalez@sisugrb.com", WindowsUsername = "SISUGRB\\mgonzalez", TeamId = 1 },
                new User { UserId = 2, FullName = "Juan Pérez", Email = "juan.perez@sisugrb.com", WindowsUsername = "SISUGRB\\jperez", TeamId = 1 },
                new User { UserId = 3, FullName = "Ana Rodríguez", Email = "ana.rodriguez@sisugrb.com", WindowsUsername = "SISUGRB\\arodriguez", TeamId = 2 },
                new User { UserId = 4, FullName = "Carlos Méndez", Email = "carlos.mendez@sisugrb.com", WindowsUsername = "SISUGRB\\cmendez", TeamId = 3 },
                new User { UserId = 5, FullName = "Laura Martínez", Email = "laura.martinez@sisugrb.com", WindowsUsername = "SISUGRB\\lmartinez", TeamId = 4 },
                new User { UserId = 6, FullName = "Pedro Gómez", Email = "pedro.gomez@sisugrb.com", WindowsUsername = "SISUGRB\\pgomez", TeamId = 1 },
                new User { UserId = 7, FullName = "Sofía López", Email = "sofia.lopez@sisugrb.com", WindowsUsername = "SISUGRB\\slopez", TeamId = 5 },
                new User { UserId = 8, FullName = "Diego Torres", Email = "diego.torres@sisugrb.com", WindowsUsername = "SISUGRB\\dtorres", TeamId = 6 },
                new User { UserId = 9, FullName = "Carmen Ruiz", Email = "carmen.ruiz@sisugrb.com", WindowsUsername = "SISUGRB\\cruiz", TeamId = 7 },
                new User { UserId = 10, FullName = "Miguel Ángel Sánchez", Email = "miguel.sanchez@sisugrb.com", WindowsUsername = "SISUGRB\\msanchez", TeamId = 8 }
            );

            // Rooms
            modelBuilder.Entity<Room>().HasData(
                new Room { RoomId = 1, RoomName = "Sala de Juntas Piso 1", Location = "Piso 1", Capacity = 10, Floor = 1 },
                new Room { RoomId = 2, RoomName = "Sala de Juntas Piso 2", Location = "Piso 2", Capacity = 10, Floor = 2 },
                new Room { RoomId = 3, RoomName = "Sala de Juntas Piso 3", Location = "Piso 3 - Capacitación", Capacity = 30, Floor = 3 }
            );

            // Room Status
            modelBuilder.Entity<RoomStatus>().HasData(
                new RoomStatus { StatusId = 1, StatusName = "Available" },
                new RoomStatus { StatusId = 2, StatusName = "Occupied" },
                new RoomStatus { StatusId = 3, StatusName = "Maintenance" }
            );

            // Room Current Status (todas disponibles inicialmente)
            modelBuilder.Entity<RoomCurrentStatus>().HasData(
                new RoomCurrentStatus { RoomId = 1, StatusId = 1, LastUpdated = DateTime.Now },
                new RoomCurrentStatus { RoomId = 2, StatusId = 1, LastUpdated = DateTime.Now },
                new RoomCurrentStatus { RoomId = 3, StatusId = 1, LastUpdated = DateTime.Now }
            );

            // Room Amenities
            modelBuilder.Entity<RoomAmenity>().HasData(
                // Piso 1
                new RoomAmenity { AmenityId = 1, RoomId = 1, AmenityName = "Cafés" },
                new RoomAmenity { AmenityId = 2, RoomId = 1, AmenityName = "Aguas" },
                new RoomAmenity { AmenityId = 3, RoomId = 1, AmenityName = "Galletas" },
                new RoomAmenity { AmenityId = 4, RoomId = 1, AmenityName = "Refrescos" },
                new RoomAmenity { AmenityId = 5, RoomId = 1, AmenityName = "IdeaShare" },
                // Piso 2
                new RoomAmenity { AmenityId = 6, RoomId = 2, AmenityName = "Cafés" },
                new RoomAmenity { AmenityId = 7, RoomId = 2, AmenityName = "Aguas" },
                new RoomAmenity { AmenityId = 8, RoomId = 2, AmenityName = "Galletas" },
                new RoomAmenity { AmenityId = 9, RoomId = 2, AmenityName = "Refrescos" },
                new RoomAmenity { AmenityId = 10, RoomId = 2, AmenityName = "IdeaShare" },
                // Piso 3
                new RoomAmenity { AmenityId = 11, RoomId = 3, AmenityName = "Cafés" },
                new RoomAmenity { AmenityId = 12, RoomId = 3, AmenityName = "Aguas" },
                new RoomAmenity { AmenityId = 13, RoomId = 3, AmenityName = "Galletas" },
                new RoomAmenity { AmenityId = 14, RoomId = 3, AmenityName = "Refrescos" },
                new RoomAmenity { AmenityId = 15, RoomId = 3, AmenityName = "IdeaShare" }
            );

            // Service Types
            modelBuilder.Entity<ServiceType>().HasData(
                new ServiceType { ServiceTypeId = 1, ServiceName = "Cafés" },
                new ServiceType { ServiceTypeId = 2, ServiceName = "Aguas" },
                new ServiceType { ServiceTypeId = 3, ServiceName = "Galletas" },
                new ServiceType { ServiceTypeId = 4, ServiceName = "Refrescos" },
                new ServiceType { ServiceTypeId = 5, ServiceName = "IdeaShare" }
            );
        }
    }
}
