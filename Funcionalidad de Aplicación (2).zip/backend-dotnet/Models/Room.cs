using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisuGrb.RoomReservations.Core.Models
{
    [Table("Rooms")]
    public class Room
    {
        [Key]
        public int RoomId { get; set; }

        [Required]
        [StringLength(100)]
        public string RoomName { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Location { get; set; } = string.Empty;

        [Required]
        public int Capacity { get; set; }

        [Required]
        public int Floor { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // Navegación
        public virtual ICollection<RoomAmenity> Amenities { get; set; } = new List<RoomAmenity>();
        public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
        public virtual RoomCurrentStatus? CurrentStatus { get; set; }
    }
}
