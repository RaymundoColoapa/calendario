using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisuGrb.RoomReservations.Core.Models
{
    [Table("Reservations")]
    public class Reservation
    {
        [Key]
        public int ReservationId { get; set; }

        [Required]
        public int RoomId { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; } = null!;

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [StringLength(1000)]
        public string? Description { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime ReservationDate { get; set; }

        [Required]
        [Column(TypeName = "time")]
        public TimeSpan StartTime { get; set; }

        [Required]
        [Column(TypeName = "time")]
        public TimeSpan EndTime { get; set; }

        [Required]
        public int OrganizerId { get; set; }

        [ForeignKey("OrganizerId")]
        public virtual User Organizer { get; set; } = null!;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Required]
        public int CreatedBy { get; set; }

        [ForeignKey("CreatedBy")]
        public virtual User Creator { get; set; } = null!;

        public bool IsCancelled { get; set; } = false;

        public DateTime? CancelledAt { get; set; }

        public int? CancelledBy { get; set; }

        // Navegación
        public virtual ICollection<ReservationAttendee> Attendees { get; set; } = new List<ReservationAttendee>();
        public virtual ICollection<ReservationService> Services { get; set; } = new List<ReservationService>();
    }
}
