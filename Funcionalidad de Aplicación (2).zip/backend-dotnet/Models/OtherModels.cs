using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisuGrb.RoomReservations.Core.Models
{
    [Table("RoomAmenities")]
    public class RoomAmenity
    {
        [Key]
        public int AmenityId { get; set; }

        [Required]
        public int RoomId { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; } = null!;

        [Required]
        [StringLength(100)]
        public string AmenityName { get; set; } = string.Empty;
    }

    [Table("RoomStatus")]
    public class RoomStatus
    {
        [Key]
        public int StatusId { get; set; }

        [Required]
        [StringLength(50)]
        public string StatusName { get; set; } = string.Empty; // 'Available', 'Occupied', 'Maintenance'
    }

    [Table("RoomCurrentStatus")]
    public class RoomCurrentStatus
    {
        [Key]
        public int RoomId { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; } = null!;

        [Required]
        public int StatusId { get; set; }

        [ForeignKey("StatusId")]
        public virtual RoomStatus Status { get; set; } = null!;

        public DateTime LastUpdated { get; set; } = DateTime.Now;

        public int? UpdatedBy { get; set; }

        [ForeignKey("UpdatedBy")]
        public virtual User? UpdatedByUser { get; set; }

        [Column(TypeName = "time")]
        public TimeSpan? MaintenanceStartTime { get; set; }

        [Column(TypeName = "time")]
        public TimeSpan? MaintenanceEndTime { get; set; }
    }

    [Table("ReservationAttendees")]
    public class ReservationAttendee
    {
        [Key]
        public int AttendeeId { get; set; }

        [Required]
        public int ReservationId { get; set; }

        [ForeignKey("ReservationId")]
        public virtual Reservation Reservation { get; set; } = null!;

        [Required]
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; } = null!;
    }

    [Table("ServiceTypes")]
    public class ServiceType
    {
        [Key]
        public int ServiceTypeId { get; set; }

        [Required]
        [StringLength(100)]
        public string ServiceName { get; set; } = string.Empty;

        // Navegación
        public virtual ICollection<ReservationService> ReservationServices { get; set; } = new List<ReservationService>();
    }

    [Table("ReservationServices")]
    public class ReservationService
    {
        [Key]
        public int ReservationServiceId { get; set; }

        [Required]
        public int ReservationId { get; set; }

        [ForeignKey("ReservationId")]
        public virtual Reservation Reservation { get; set; } = null!;

        [Required]
        public int ServiceTypeId { get; set; }

        [ForeignKey("ServiceTypeId")]
        public virtual ServiceType ServiceType { get; set; } = null!;
    }
}
