# 🔐 SISTEMA DE AUTO-LOGIN Y USUARIOS AUTOMÁTICOS

## ✅ CAMBIOS IMPLEMENTADOS

### **1. Login Automático con Windows/Azure AD**
- ✅ La aplicación detecta automáticamente el usuario de Windows
- ✅ NO necesitas seleccionar de una lista
- ✅ Entra directamente al sistema

### **2. Auto-Registro de Usuarios**
- ✅ Si un usuario nuevo abre la aplicación por primera vez
- ✅ Se registra AUTOMÁTICAMENTE en la base de datos
- ✅ No necesitas agregar usuarios manualmente

### **3. Departamentos Configurados (7 Equipos)**
1. **Suscripción** (Azul #3B82F6)
2. **Reclamaciones** (Rojo #EF4444)
3. **Financiero** (Verde #10B981)
4. **Comercial** (Naranja #F59E0B)
5. **Operaciones** (Morado #8B5CF6)
6. **Legal** (Rosa #EC4899)
7. **Tecnología** (Índigo #6366F1)

---

## 🚀 CÓMO FUNCIONA

### **Flujo Normal (Producción con Azure AD):**

```
1. Usuario abre la app → https://sisu-grb.vercel.app
2. El servidor detecta su usuario de Windows/Azure AD
3. Busca en la base de datos:
   - ¿Existe? → Login automático ✅
   - ¿No existe? → Crea el usuario automáticamente ✅
4. Usuario entra directo al sistema
```

### **Flujo Actual (Sin Azure AD configurado):**

```
1. Usuario abre la app
2. Si no puede detectar Windows usuario automáticamente:
   → Muestra formulario simple
3. Usuario ingresa:
   - Nombre completo (Ej: Juan Pérez)
   - Usuario Windows (Ej: jperez)
   - Email (opcional)
4. Click "Ingresar al Sistema"
5. Sistema crea/busca usuario automáticamente
6. Entra directo
```

---

## 📋 INFORMACIÓN IMPORTANTE

### **¿Los usuarios se guardan?**
✅ **SÍ** - En la base de datos de Supabase

### **¿Cuántos usuarios puedo tener?**
✅ **ILIMITADOS** (hasta el límite de Supabase, que es 500 MB = miles de usuarios)

### **¿Necesito agregar usuarios manualmente?**
❌ **NO** - Se registran automáticamente cuando entran por primera vez

### **¿A qué equipo se asignan los nuevos usuarios?**
- Por defecto: **Operaciones**
- Puedes cambiar el equipo después (ver sección "Cambiar Equipo")

### **¿Puedo ver todos los usuarios registrados?**
✅ **SÍ** - Accediendo al panel de Supabase

---

## 👥 CÓMO AGREGAR/GESTIONAR USUARIOS

### **Opción 1: Auto-Registro (RECOMENDADO)**
1. Comparte la URL con el nuevo empleado
2. El empleado abre la app
3. Ingresa su nombre y usuario
4. ¡Listo! Ya está registrado

### **Opción 2: Pre-Registrar Usuarios en el Código**
Si quieres pre-registrar usuarios antes de que entren:

1. Edita `/supabase/functions/server/index.tsx`
2. Busca `INITIAL_USERS`
3. Agrega el nuevo usuario:

```typescript
{
  id: 5, // Siguiente ID disponible
  username: 'azuread\\nuevouser',
  displayName: 'Nombre Completo',
  email: 'nuevouser@sisugrb.com',
  teamId: 1, // ID del equipo (1-7)
  team: { id: 1, name: 'Suscripción', color: '#3B82F6' },
  role: 'Analista', // Puesto
  createdAt: new Date().toISOString()
}
```

4. Guarda y sube a Vercel
5. El usuario ya estará en el sistema

---

## 🔄 CÓMO CAMBIAR EQUIPO DE UN USUARIO

### **Opción 1: Desde el Panel de Supabase**
1. Ve a: https://app.supabase.com
2. Tu proyecto → Table Editor
3. Busca en `kv_store` el registro del usuario
4. Edita el campo `teamId` (1-7)
5. Actualiza el campo `team` con el nombre correcto

### **Opción 2: Crear Panel de Administración (Futuro)**
Puedes agregar un panel donde:
- Veas lista de todos los usuarios
- Cambies el equipo de cada uno
- Asignes roles especiales

---

## 🎯 DEPARTAMENTOS Y SUS IDS

| ID | Departamento | Color | Descripción |
|----|--------------|-------|-------------|
| 1 | Suscripción | Azul | Análisis y evaluación de riesgos |
| 2 | Reclamaciones | Rojo | Gestión de siniestros |
| 3 | Financiero | Verde | Contabilidad y finanzas |
| 4 | Comercial | Naranja | Ventas y desarrollo |
| 5 | Operaciones | Morado | Gestión operativa (Por defecto) |
| 6 | Legal | Rosa | Asesoría legal y compliance |
| 7 | Tecnología | Índigo | Desarrollo y sistemas |

---

## 🔧 CONFIGURAR AUTO-LOGIN REAL CON WINDOWS/AZURE AD

Para que funcione la detección automática sin que el usuario ingrese nada:

### **Opción A: Azure AD (Recomendado para Empresas)**

1. **Configura Azure AD en tu organización**
2. **En el código del servidor** (.NET o Node.js intermediario):
   ```csharp
   // Obtener usuario de Windows autenticado
   var windowsUser = User.Identity.Name; // "DOMAIN\\username"
   var displayName = User.Identity.GetDisplayName();
   var email = User.Identity.GetEmail();
   
   // Pasar al frontend via sessionStorage o cookie
   Response.Cookies.Append("windows_username", windowsUser);
   Response.Cookies.Append("windows_displayname", displayName);
   ```

3. **El frontend lee la cookie/session:**
   ```typescript
   const windowsUsername = sessionStorage.getItem('windows_username');
   // Auto-login con ese usuario
   ```

### **Opción B: Integrated Windows Authentication (IWA)**
Si usas IIS en tu red corporativa:
1. Habilita IWA en IIS
2. El navegador pasa automáticamente las credenciales
3. El servidor las captura y las envía al frontend

### **Opción C: PWA Instalada (Para apps instaladas)**
Si la aplicación está instalada como PWA:
1. Puedes acceder a APIs del sistema operativo
2. Detectar usuario de Windows directamente

---

## 📊 VER USUARIOS EN SUPABASE

### **Paso 1: Acceder al Panel**
1. Ve a: https://app.supabase.com
2. Login con tu cuenta
3. Selecciona tu proyecto

### **Paso 2: Ver Usuarios**
1. Click en "Table Editor" (izquierda)
2. En el filtro, busca: `user:`
3. Verás todos los usuarios registrados:
   - ID
   - Nombre
   - Username (Windows)
   - Email
   - Equipo
   - Fecha de creación

### **Paso 3: Editar Usuario**
1. Click en el registro del usuario
2. Edita los campos que necesites
3. Click "Save"

---

## 🎉 BENEFICIOS DEL NUEVO SISTEMA

### ✅ **Para Usuarios:**
- No necesitan registro previo
- Entran directamente (después de primera vez)
- No memorizan contraseñas
- Usa su usuario de Windows

### ✅ **Para TI/Administradores:**
- No agregas usuarios manualmente
- Se registran automáticamente
- Menos trabajo de mantenimiento
- Base de datos crece orgánicamente

### ✅ **Para la Empresa:**
- Menos soporte técnico
- Adopción más rápida
- Sincronizado con Active Directory
- Control centralizado

---

## 🔒 SEGURIDAD

### **¿Es seguro el auto-registro?**
✅ **SÍ**, porque:
- Solo funciona en tu red corporativa
- Usa autenticación de Windows/Azure AD
- Los usuarios deben estar autenticados en tu dominio
- No pueden registrarse usuarios externos

### **¿Puedo limitar quién se registra?**
✅ **SÍ**, puedes agregar validación:
- Solo emails con dominio @sisugrb.com
- Solo usuarios en Active Directory
- Lista blanca de usuarios permitidos

---

## 📝 EJEMPLO COMPLETO

### **Escenario: María es nueva en la empresa**

**Día 1:**
1. TI le da su laptop con Windows configurado
2. Usuario de Windows: `azuread\mmartinez`
3. Le comparten la URL: `https://sisu-grb.vercel.app`

**María abre la app:**
1. Sistema detecta: `azuread\mmartinez`
2. Busca en base de datos → No existe
3. Muestra formulario simple
4. María ingresa:
   - Nombre: "María Martínez"
   - Usuario: "mmartinez"
   - Email: "mmartinez@sisugrb.com"
5. Click "Ingresar"
6. Sistema crea usuario automáticamente:
   - ID: 5 (siguiente disponible)
   - Equipo: Operaciones (por defecto)
   - Rol: Usuario
7. María entra directo al sistema ✅

**Día 2 en adelante:**
1. María abre la app
2. Sistema detecta `azuread\mmartinez`
3. Busca en base de datos → SÍ existe
4. Login automático
5. Entra directo sin formulario ✅

---

## 🚀 PRÓXIMOS PASOS

1. **Prueba el sistema:**
   - Ingresa con diferentes nombres de usuario
   - Verifica que se crean automáticamente

2. **Comparte con tu equipo:**
   - Envía la URL a 2-3 personas
   - Pídeles que prueben el auto-registro

3. **Verifica en Supabase:**
   - Entra al panel
   - Confirma que los usuarios se están guardando

4. **Opcional - Configurar Azure AD:**
   - Sigue las instrucciones arriba
   - Para login 100% automático sin formulario

---

## 📞 ¿PREGUNTAS?

**P: ¿Puedo cambiar el equipo por defecto (Operaciones)?**
R: Sí, edita `defaultTeam` en el servidor (línea ~200)

**P: ¿Puedo hacer que se asigne el equipo automáticamente?**
R: Sí, puedes agregar lógica basada en el email o departamento

**P: ¿Los usuarios antiguos siguen funcionando?**
R: Sí, los 4 usuarios iniciales siguen en la base de datos

**P: ¿Puedo eliminar un usuario?**
R: Sí, desde el panel de Supabase o agregando endpoint de eliminación

---

¡El sistema está listo para recibir usuarios ilimitados! 🎉
