# ✅ CHECKLIST DE INSTALACIÓN - SISU GRB

Usa este documento para hacer seguimiento de tu progreso en la instalación.

---

## 📦 FASE 1: PREPARACIÓN

### 1.1 Software Base

- [ ] **Windows 10/11** instalado
- [ ] Tienes permisos de **Administrador**
- [ ] Al menos **5 GB** de espacio libre
- [ ] Conexión a **internet** (para descargas)

### 1.2 Descargas

- [ ] **Visual Studio 2022** descargado
  - Link: https://visualstudio.microsoft.com/es/downloads/
  - Versión: Community (gratuita)
  
- [ ] **SQL Server Express 2022** descargado
  - Link: https://www.microsoft.com/es-es/sql-server/sql-server-downloads
  - Versión: Express Edition
  
- [ ] **SQL Server Management Studio (SSMS)** descargado
  - Link: https://aka.ms/ssmsfullsetup
  
- [ ] **Node.js** descargado
  - Link: https://nodejs.org/
  - Versión: LTS (18 o superior)

---

## 🗄️ FASE 2: SQL SERVER

### 2.1 Instalación

- [ ] SQL Server Express instalado
- [ ] Anotado el nombre de instancia: `____________________________`
  - Ejemplo: `DESKTOP-ABC123\SQLEXPRESS`
- [ ] Servicio SQL Server corriendo (verificado en services.msc)
- [ ] SSMS instalado correctamente

### 2.2 Conexión

- [ ] SSMS abierto
- [ ] Conectado a: `localhost\SQLEXPRESS` (o tu instancia)
- [ ] Autenticación de Windows funciona
- [ ] Puedes ver la lista de bases de datos

### 2.3 Base de Datos

- [ ] Script SQL ejecutado: `/backend-dotnet/SQL/01-create-database.sql`
- [ ] Base de datos `SisuGrbRoomReservations` creada
- [ ] Tablas creadas:
  - [ ] `Teams`
  - [ ] `Users`
  - [ ] `Rooms`
  - [ ] `Reservations`
- [ ] Datos iniciales cargados:
  - [ ] 4 equipos insertados
  - [ ] 3 salas insertadas

### 2.4 Usuario de Windows

- [ ] Ejecutado `whoami` en CMD
- [ ] Usuario de Windows anotado: `SISUGRB\____________________`
- [ ] Usuario insertado en tabla `Users`
- [ ] Verificado con: `SELECT * FROM Users WHERE WindowsUsername LIKE '%tunombre%'`

---

## 💻 FASE 3: VISUAL STUDIO Y BACKEND

### 3.1 Instalación de Visual Studio

- [ ] Visual Studio 2022 instalado
- [ ] Workload seleccionado: **"ASP.NET and web development"**
- [ ] .NET 8.0 SDK instalado

### 3.2 Proyecto Backend

- [ ] Proyecto creado: **ASP.NET Core Web API**
- [ ] Nombre del proyecto: `SisuGrb.RoomReservations`
- [ ] Ubicación anotada: `_______________________________________`
- [ ] Framework: **.NET 8.0**
- [ ] OpenAPI support habilitado

### 3.3 Archivos Copiados

- [ ] Carpeta `Controllers/` copiada
  - [ ] `UsersController.cs`
  - [ ] `RoomsController.cs`
- [ ] Carpeta `Models/` copiada
  - [ ] `User.cs`
  - [ ] `Team.cs`
  - [ ] `Room.cs`
  - [ ] `Reservation.cs`
  - [ ] `OtherModels.cs`
- [ ] Carpeta `Data/` copiada
  - [ ] `AppDbContext.cs`
- [ ] Archivo `Program.cs` reemplazado
- [ ] Archivo `appsettings.json` actualizado

### 3.4 Paquetes NuGet

- [ ] Instalado: `Microsoft.EntityFrameworkCore.SqlServer` v8.0.0
- [ ] Instalado: `Microsoft.EntityFrameworkCore.Tools` v8.0.0
- [ ] Instalado: `Microsoft.AspNetCore.Authentication.Negotiate` v8.0.0

### 3.5 Configuración

- [ ] `appsettings.json` configurado con connection string correcto
- [ ] Nombre de instancia SQL verificado en connection string
- [ ] `launchSettings.json` configurado para puerto 5000
- [ ] CORS configurado para `http://localhost:5173`

### 3.6 Prueba del Backend

- [ ] Presionado F5 en Visual Studio
- [ ] Backend inicia sin errores
- [ ] Swagger abre en navegador: `http://localhost:5000/swagger`
- [ ] Endpoint probado: **GET /api/users/current**
- [ ] Respuesta muestra mi información de usuario ✅

**Respuesta esperada:**
```json
{
  "id": 1,
  "windowsUsername": "SISUGRB\\tunombre",
  "displayName": "Tu Nombre",
  "email": "tu@email.com",
  "teamId": 1,
  "team": {
    "id": 1,
    "name": "Desarrollo",
    "color": "#3B82F6"
  },
  "isActive": true
}
```

---

## ⚛️ FASE 4: FRONTEND REACT

### 4.1 Node.js

- [ ] Node.js instalado
- [ ] Verificado con: `node --version`
- [ ] Versión instalada: `_____________`

### 4.2 Dependencias

- [ ] Navegado a la carpeta del proyecto en terminal
- [ ] Ejecutado: `npm install`
- [ ] Instalación completada sin errores
- [ ] Carpeta `node_modules/` creada

### 4.3 Archivos Verificados

- [ ] Archivo `/src/app/services/api.ts` existe
- [ ] Variable `API_BASE_URL` configurada: `http://localhost:5000/api`
- [ ] Archivo `package.json` existe
- [ ] Archivo `vite.config.ts` existe

### 4.4 Prueba del Frontend

- [ ] Ejecutado: `npm run dev`
- [ ] Frontend inicia sin errores
- [ ] Terminal muestra: `Local: http://localhost:5173/`
- [ ] Navegador abre automáticamente

---

## 🔗 FASE 5: INTEGRACIÓN COMPLETA

### 5.1 Conexión Frontend ↔ Backend

- [ ] Backend corriendo en Visual Studio (F5)
- [ ] Frontend corriendo en terminal (npm run dev)
- [ ] Navegador abierto en: `http://localhost:5173`

### 5.2 Verificación de Autenticación

- [ ] La app detecta mi usuario de Windows automáticamente
- [ ] Nombre mostrado en la esquina superior derecha
- [ ] Equipo mostrado correctamente
- [ ] No aparece pantalla de login manual

### 5.3 Funcionalidad de Salas

- [ ] Se muestran las 3 salas:
  - [ ] Piso 1 (Capacidad: 10)
  - [ ] Piso 2 (Capacidad: 10)
  - [ ] Piso 3 (Capacidad: 30)
- [ ] Los estados se muestran correctamente
- [ ] Puedo cambiar el estado de una sala manualmente
- [ ] El cambio se persiste (no se pierde al refrescar)

### 5.4 Funcionalidad de Reservas

- [ ] Puedo hacer click en "Reservar" en una sala
- [ ] Se abre el formulario de reserva
- [ ] Puedo seleccionar horario
- [ ] Puedo escribir un propósito
- [ ] Al confirmar, la reserva se crea
- [ ] La reserva aparece en "Reservas de Hoy"
- [ ] Mi nombre aparece como organizador

### 5.5 Cancelación de Reservas

- [ ] Puedo ver el botón X en mis propias reservas
- [ ] No veo el botón X en reservas de otros usuarios
- [ ] Al cancelar, aparece confirmación
- [ ] Al confirmar, la reserva se elimina
- [ ] La sala vuelve a estado "Libre"

### 5.6 Persistencia de Datos

- [ ] Creo una reserva
- [ ] Refresco el navegador (F5)
- [ ] La reserva sigue ahí ✅
- [ ] Cierro el navegador completamente
- [ ] Vuelvo a abrir `http://localhost:5173`
- [ ] La reserva SIGUE ahí ✅✅

---

## 🚀 FASE 6: AUTOMATIZACIÓN (OPCIONAL)

### 6.1 Script de Inicio

- [ ] Archivo `start-sisugrb-local.bat` ubicado en la raíz del proyecto
- [ ] Editado `BACKEND_PATH` con la ruta correcta (si es necesario)
- [ ] Doble click en el archivo .bat
- [ ] SQL Server inicia automáticamente
- [ ] Frontend inicia automáticamente
- [ ] Navegador se abre automáticamente

---

## 🎯 VERIFICACIÓN FINAL

### Checklist de Producción

- [ ] **Backend**: ✅ Funciona
- [ ] **Frontend**: ✅ Funciona
- [ ] **SQL Server**: ✅ Corriendo
- [ ] **Windows Auth**: ✅ Detecta usuario automáticamente
- [ ] **Crear Reserva**: ✅ Funciona
- [ ] **Cancelar Reserva**: ✅ Funciona (solo organizador)
- [ ] **Persistencia**: ✅ Datos se guardan en SQL Server
- [ ] **Cambiar Estado**: ✅ Estados de sala se actualizan
- [ ] **Validaciones**: ✅ Horario de operación validado
- [ ] **Sin Errores**: ✅ Consola del navegador sin errores rojos

---

## 📊 RESULTADO

### ¿Todo marcado? 🎉

Si tienes TODOS los checkboxes marcados, ¡felicidades!

**Tu sistema SISU GRB está completamente funcional.**

### Próximos Pasos:

1. **Agregar más usuarios** a la tabla `Users` (todos los empleados)
2. **Probar con múltiples usuarios** (si tienes acceso a otras cuentas Windows)
3. **Configurar backups** automáticos de SQL Server
4. **Documentar** usuarios y responsables
5. **Capacitar** al equipo en el uso del sistema

---

## 🐛 Si Algo No Funciona

### Recursos de Ayuda

| Si falla... | Consulta... |
|-------------|-------------|
| ❌ SQL Server | `PASOS-INSTALACION-ESCRITORIO.md` → Sección "Troubleshooting" |
| ❌ Backend .NET | `backend-dotnet/COMENZAR-AQUI.md` → Sección "Debugging" |
| ❌ Frontend React | Consola del navegador (F12) → Ver errores |
| ❌ Autenticación | `PASOS-INSTALACION-ESCRITORIO.md` → "Windows Authentication failed" |
| ❌ CORS | `backend-dotnet/COMENZAR-AQUI.md` → "CORS policy error" |

---

## 📝 Notas Personales

Usa este espacio para anotar observaciones o cambios específicos de tu instalación:

```
Nombre de instancia SQL Server:
_____________________________________________________________

Ruta del proyecto Backend:
_____________________________________________________________

Puerto Backend (si cambiaste):
_____________________________________________________________

Usuarios agregados a la base de datos:
1. ___________________________________________________________
2. ___________________________________________________________
3. ___________________________________________________________

Fecha de instalación completada:
_____________________________________________________________

Persona responsable:
_____________________________________________________________

Observaciones:
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
```

---

## 🎓 Capacitación de Usuarios

### Checklist de Training

- [ ] Manual de usuario creado
- [ ] Sesión de capacitación programada
- [ ] Usuarios conocen cómo:
  - [ ] Reservar una sala
  - [ ] Cancelar su propia reserva
  - [ ] Ver el estado de las salas
  - [ ] Cambiar estado a mantenimiento (si aplica)
- [ ] Responsable de soporte técnico asignado

---

**¡Éxito con tu instalación! 🚀**

*Sistema SISU GRB - Gestión de Salas de Juntas*
